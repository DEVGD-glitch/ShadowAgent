"""tools/registry.py — Central tool registry and dynamic registration.

Provides the :class:`ToolRegistry` singleton and the :func:`register_tool`
decorator for adding tools at runtime.  Tools can come from:

1. **Builtin tools** — the classic ``do_*`` methods on ``GenericAgentHandler``
2. **Registered tools** — functions decorated with ``@register_tool(...)``
3. **Plugin tools** — auto-discovered from the ``plugins/tools/`` directory
4. **MCP tools** — discovered from connected MCP servers (see ``mcp/``)

The registry merges all sources into a unified schema that is injected into
the LLM's ``tools`` parameter.
"""

from __future__ import annotations

import importlib
import json
import logging
import os
import sys
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("tools.registry")

# ══════════════════════════════════════════════════════════════════════════════
#  ToolDefinition
# ══════════════════════════════════════════════════════════════════════════════


@dataclass
class ToolDefinition:
    """Complete specification for a single tool.

    Attributes
    ----------
    name : str
        Tool name as seen by the LLM (e.g. ``"web_search"``).
    description : str
        Human-readable description included in the tool schema.
    parameters : dict
        JSON Schema for the tool's input parameters.
    handler : Callable
        The function to call when this tool is invoked.  Must accept
        ``(args: dict, response: Any)`` and return a ``StepOutcome``-compatible
        value (or yield strings as a generator and return a StepOutcome).
    category : str
        Logical grouping (``"file"``, ``"web"``, ``"code"``, ``"memory"``,
        ``"search"``, ``"integration"``, ``"custom"``).
    requires_confirmation : bool
        If ``True``, the frontend must confirm before executing.
    examples : list[dict]
        Example invocations for documentation / few-shot prompting.
    version : str
        Semantic version of the tool definition.
    source : str
        Origin — ``"builtin"``, ``"plugin"``, ``"mcp"``, or ``"dynamic"``.
    """

    name: str
    description: str
    parameters: dict
    handler: Callable
    category: str = "custom"
    requires_confirmation: bool = False
    examples: list[dict] = field(default_factory=list)
    version: str = "1.0.0"
    source: str = "dynamic"

    def to_openai_schema(self) -> dict:
        """Convert to OpenAI function-calling tool schema format.

        Returns
        -------
        dict
            Schema dict with ``"type"``, ``"function"`` keys.
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


# ══════════════════════════════════════════════════════════════════════════════
#  ToolRegistry
# ══════════════════════════════════════════════════════════════════════════════


class ToolRegistry:
    """Central registry that tracks all available tools.

    The registry is a singleton — use :func:`get_registry` to obtain the
    global instance.  It supports:

    * Registering tools via :meth:`register` or the :func:`register_tool`
      decorator.
    * Unregistering tools at runtime.
    * Merging builtin ``do_*`` tools with dynamically registered ones.
    * Producing a combined OpenAI-compatible tool schema list.
    * Auto-discovering plugins from the ``plugins/tools/`` directory.
    """

    def __init__(self) -> None:
        self._tools: Dict[str, ToolDefinition] = {}
        self._disabled: set[str] = set()
        self._categories: Dict[str, set[str]] = {}

    # ── Registration ───────────────────────────────────────────────────────

    def register(
        self,
        name: str,
        handler: Callable,
        description: str = "",
        parameters: Optional[dict] = None,
        category: str = "custom",
        requires_confirmation: bool = False,
        examples: Optional[list[dict]] = None,
        version: str = "1.0.0",
        source: str = "dynamic",
        override: bool = False,
    ) -> ToolDefinition:
        """Register a tool in the registry.

        Parameters
        ----------
        name : str
            Unique tool name.
        handler : Callable
            The function to invoke.
        description : str
            LLM-visible description.
        parameters : dict | None
            JSON Schema for inputs.  Defaults to ``{"type": "object", "properties": {}}``.
        category : str
            Tool category for grouping.
        requires_confirmation : bool
            Whether the frontend must confirm execution.
        examples : list[dict] | None
            Example invocations.
        version : str
            Semantic version.
        source : str
            Origin of the tool.
        override : bool
            If ``True``, silently replace an existing tool with the same name.

        Returns
        -------
        ToolDefinition
            The registered definition.

        Raises
        ------
        ValueError
            If a tool with the same name already exists and *override* is
            ``False``.
        """
        if name in self._tools and not override:
            raise ValueError(
                f"Tool '{name}' already registered. Use override=True to replace."
            )

        if parameters is None:
            parameters = {"type": "object", "properties": {}}

        tool_def = ToolDefinition(
            name=name,
            description=description,
            parameters=parameters,
            handler=handler,
            category=category,
            requires_confirmation=requires_confirmation,
            examples=examples or [],
            version=version,
            source=source,
        )

        self._tools[name] = tool_def
        # Remove from disabled set if re-registering
        self._disabled.discard(name)

        # Update category index
        cat = self._categories.setdefault(category, set())
        cat.add(name)

        logger.debug("Registered tool: %s [%s] from %s", name, category, source)
        return tool_def

    def unregister(self, name: str) -> Optional[ToolDefinition]:
        """Remove a tool from the registry.

        Parameters
        ----------
        name : str
            The tool name to remove.

        Returns
        -------
        ToolDefinition | None
            The removed definition, or ``None`` if not found.
        """
        tool = self._tools.pop(name, None)
        if tool is None:
            return None

        # Clean up category index
        cat_tools = self._categories.get(tool.category)
        if cat_tools is not None:
            cat_tools.discard(name)
            if not cat_tools:
                del self._categories[tool.category]

        self._disabled.discard(name)
        logger.debug("Unregistered tool: %s", name)
        return tool

    def enable(self, name: str) -> None:
        """Re-enable a previously disabled tool."""
        self._disabled.discard(name)

    def disable(self, name: str) -> None:
        """Disable a tool without removing it from the registry."""
        if name in self._tools:
            self._disabled.add(name)

    # ── Query ──────────────────────────────────────────────────────────────

    def get(self, name: str) -> Optional[ToolDefinition]:
        """Look up a tool by name (returns ``None`` if not found or disabled)."""
        if name in self._disabled:
            return None
        return self._tools.get(name)

    def __contains__(self, name: str) -> bool:
        return name in self._tools and name not in self._disabled

    def __len__(self) -> int:
        return len(self._tools) - len(self._disabled)

    @property
    def tool_names(self) -> list[str]:
        """Return sorted list of active (non-disabled) tool names."""
        return sorted(n for n in self._tools if n not in self._disabled)

    @property
    def all_tool_names(self) -> list[str]:
        """Return sorted list of all registered tool names (including disabled)."""
        return sorted(self._tools.keys())

    def list_tools(self, category: Optional[str] = None) -> list[ToolDefinition]:
        """Return active tool definitions, optionally filtered by category."""
        tools = []
        for name, tool in self._tools.items():
            if name in self._disabled:
                continue
            if category and tool.category != category:
                continue
            tools.append(tool)
        return sorted(tools, key=lambda t: t.name)

    def list_categories(self) -> dict[str, int]:
        """Return a mapping of category name → count of active tools."""
        result: Dict[str, int] = {}
        for name, tool in self._tools.items():
            if name in self._disabled:
                continue
            result[tool.category] = result.get(tool.category, 0) + 1
        return result

    # ── Schema generation ──────────────────────────────────────────────────

    def get_openai_schemas(self, category: Optional[str] = None) -> list[dict]:
        """Return OpenAI-compatible tool schemas for all active tools.

        Parameters
        ----------
        category : str | None
            If set, only include tools from this category.

        Returns
        -------
        list[dict]
            List of ``{"type": "function", "function": {...}}`` dicts.
        """
        schemas = []
        for tool in self.list_tools(category=category):
            schemas.append(tool.to_openai_schema())
        return schemas

    def merge_builtin_schemas(self, builtin_schemas: list[dict]) -> list[dict]:
        """Merge builtin tool schemas with registered plugin schemas.

        Builtin schemas have priority — registered tools with the same name
        are skipped (unless they were registered with ``override=True``).

        Parameters
        ----------
        builtin_schemas : list[dict]
            The original schemas from ``assets/tools_schema.json``.

        Returns
        -------
        list[dict]
            Combined schema list with no duplicates.
        """
        builtin_names = set()
        result = list(builtin_schemas)
        for schema in builtin_schemas:
            func = schema.get("function", {})
            builtin_names.add(func.get("name", ""))

        # Add registered tools that don't clash with builtins
        for tool in self.list_tools():
            if tool.name not in builtin_names:
                result.append(tool.to_openai_schema())

        return result

    # ── Dispatch ───────────────────────────────────────────────────────────

    def dispatch(
        self, name: str, args: dict, response: Any
    ) -> Optional[Any]:
        """Dispatch a tool call to its registered handler.

        Parameters
        ----------
        name : str
            Tool name.
        args : dict
            Tool arguments.
        response : Any
            The LLM response object.

        Returns
        -------
        Any
            The handler's return value, or ``None`` if the tool is not
            found in the registry.
        """
        tool = self.get(name)
        if tool is None:
            return None
        return tool.handler(args, response)

    # ── Plugin auto-discovery ──────────────────────────────────────────────

    def load_plugins(self, plugin_dir: Optional[str] = None) -> int:
        """Auto-discover and load tool plugins from a directory.

        Each plugin is a Python file (or package) that calls
        ``register_tool(...)`` at import time.  Files starting with ``_``
        are skipped.

        Parameters
        ----------
        plugin_dir : str | None
            Directory to scan.  Defaults to ``plugins/tools/`` under the
            project root.

        Returns
        -------
        int
            Number of plugins successfully loaded.
        """
        if plugin_dir is None:
            plugin_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "plugins",
                "tools",
            )

        if not os.path.isdir(plugin_dir):
            logger.debug("Plugin directory not found: %s", plugin_dir)
            return 0

        loaded = 0
        for fname in sorted(os.listdir(plugin_dir)):
            if fname.startswith("_"):
                continue

            fpath = os.path.join(plugin_dir, fname)

            if fname.endswith(".py"):
                module_name = f"_ga_plugin_{fname[:-3]}"
                try:
                    spec = importlib.util.spec_from_file_location(module_name, fpath)
                    if spec and spec.loader:
                        mod = importlib.util.module_from_spec(spec)
                        sys.modules[module_name] = mod
                        spec.loader.exec_module(mod)
                        loaded += 1
                        logger.info("Loaded tool plugin: %s", fname)
                except Exception:
                    logger.warning("Failed to load plugin %s: %s", fname, traceback.format_exc())

            elif os.path.isdir(fpath) and os.path.isfile(os.path.join(fpath, "__init__.py")):
                module_name = f"_ga_plugin_{fname}"
                try:
                    spec = importlib.util.spec_from_file_location(
                        module_name, os.path.join(fpath, "__init__.py"),
                        submodule_search_locations=[fpath],
                    )
                    if spec and spec.loader:
                        mod = importlib.util.module_from_spec(spec)
                        sys.modules[module_name] = mod
                        spec.loader.exec_module(mod)
                        loaded += 1
                        logger.info("Loaded tool plugin package: %s", fname)
                except Exception:
                    logger.warning("Failed to load plugin package %s: %s", fname, traceback.format_exc())

        return loaded

    # ── Export / introspection ─────────────────────────────────────────────

    def to_dict(self) -> dict:
        """Serialize the registry state for debugging / inspection."""
        return {
            "tools": {
                name: {
                    "name": t.name,
                    "category": t.category,
                    "source": t.source,
                    "version": t.version,
                    "description": t.description[:100],
                    "requires_confirmation": t.requires_confirmation,
                    "disabled": name in self._disabled,
                }
                for name, t in self._tools.items()
            },
            "categories": {k: sorted(v) for k, v in self._categories.items()},
            "total_active": len(self),
            "total_disabled": len(self._disabled),
        }

    def __repr__(self) -> str:
        return f"ToolRegistry(tools={len(self)}, disabled={len(self._disabled)})"


# ══════════════════════════════════════════════════════════════════════════════
#  Global singleton + decorator
# ══════════════════════════════════════════════════════════════════════════════

_registry = ToolRegistry()


def get_registry() -> ToolRegistry:
    """Return the global :class:`ToolRegistry` singleton."""
    return _registry


def register_tool(
    name: Optional[str] = None,
    description: str = "",
    parameters: Optional[dict] = None,
    category: str = "custom",
    requires_confirmation: bool = False,
    examples: Optional[list[dict]] = None,
    version: str = "1.0.0",
    source: str = "dynamic",
    override: bool = False,
    handler: Optional[Callable] = None,
) -> Any:
    """Register a function as a tool.

    Can be used in three ways:

    1. **Decorator with arguments**::

        @register_tool(
            name="my_tool",
            description="Does something cool",
            parameters={"type": "object", "properties": {...}},
        )
        def handle_my_tool(args, response):
            ...

    2. **Decorator without arguments** (uses function name minus ``do_`` prefix)::

        @register_tool
        def do_my_tool(args, response):
            ...

    3. **Direct call** with explicit handler (used by plugin files)::

        register_tool(
            name="my_tool",
            handler=my_handler_fn,
            description="Does something cool",
        )

    Parameters
    ----------
    name : str | None
        Tool name.  Defaults to the function name with ``do_`` prefix stripped.
    description : str
        LLM-visible description.  Defaults to the function's docstring.
    parameters : dict | None
        JSON Schema for inputs.
    category : str
        Tool category for grouping.
    requires_confirmation : bool
        Whether the frontend must confirm execution.
    examples : list[dict] | None
        Example invocations.
    version : str
        Semantic version.
    source : str
        Origin of the tool.
    override : bool
        If ``True``, silently replace an existing tool with the same name.
    handler : Callable | None
        Explicit handler function.  When provided, the tool is registered
        immediately without the decorator pattern.
    """

    # Mode 3: Direct call with explicit handler
    if handler is not None:
        tool_name = name or handler.__name__
        if tool_name.startswith("do_"):
            tool_name = tool_name[3:]
        tool_desc = description or (handler.__doc__ or "").strip().split("\n")[0] or f"Tool: {tool_name}"
        get_registry().register(
            name=tool_name,
            handler=handler,
            description=tool_desc,
            parameters=parameters,
            category=category,
            requires_confirmation=requires_confirmation,
            examples=examples,
            version=version,
            source=source,
            override=override,
        )
        return handler

    def decorator(fn: Callable) -> Callable:
        tool_name = name
        if tool_name is None:
            tool_name = fn.__name__
            if tool_name.startswith("do_"):
                tool_name = tool_name[3:]

        tool_desc = description or (fn.__doc__ or "").strip().split("\n")[0]
        if not tool_desc:
            tool_desc = f"Tool: {tool_name}"

        get_registry().register(
            name=tool_name,
            handler=fn,
            description=tool_desc,
            parameters=parameters,
            category=category,
            requires_confirmation=requires_confirmation,
            examples=examples,
            version=version,
            source=source,
            override=override,
        )
        return fn

    # Support @register_tool without parentheses
    if callable(name):
        fn = name
        name = None
        return decorator(fn)

    return decorator


# ══════════════════════════════════════════════════════════════════════════════
#  Schema utilities
# ══════════════════════════════════════════════════════════════════════════════


def tool_schema_to_openai(name: str, description: str, parameters: dict) -> dict:
    """Create a single OpenAI function-calling tool schema.

    Parameters
    ----------
    name : str
        Tool name.
    description : str
        Tool description.
    parameters : dict
        JSON Schema for the tool's input.

    Returns
    -------
    dict
        Schema dict with ``"type": "function"`` and ``"function"`` keys.
    """
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": parameters,
        },
    }
