# ══════════════════════════════════════════════════════════════════════════════
#  GenericAgent — Système d'internationalisation (i18n)
#  Remplace tous les textes hardcodés en chinois par un système de traduction
# ══════════════════════════════════════════════════════════════════════════════
"""
Utilisation :
    from i18n import t
    
    t("error.timeout")              → "Délai d'attente dépassé"
    t("ui.new_chat")                → "Nouvelle conversation"
    t("error.no_browser_tab")       → "Aucun onglet navigateur disponible"
    
La langue est lue depuis :
    1. Variable d'environnement GA_LANG
    2. Paramètre GA_LANG dans mykey.py
    3. Défaut : "fr" (français)
"""
import os
import json

_LANG = None
_MESSAGES = {}

SUPPORTED_LANGS = ("fr", "en", "zh")
DEFAULT_LANG = "fr"

def get_lang():
    """Détermine la langue active."""
    global _LANG
    if _LANG is not None:
        return _LANG
    lang = os.environ.get("GA_LANG", "").strip().lower()
    if lang in SUPPORTED_LANGS:
        _LANG = lang
        return _LANG
    try:
        import mykey
        lang = getattr(mykey, "GA_LANG", "").strip().lower()
        if lang in SUPPORTED_LANGS:
            _LANG = lang
            return _LANG
    except ImportError:
        pass
    _LANG = DEFAULT_LANG
    return _LANG

def set_lang(lang):
    """Force la langue."""
    global _LANG, _MESSAGES
    if lang in SUPPORTED_LANGS:
        _LANG = lang
        _MESSAGES = {}
        _load_messages(lang)

def _load_messages(lang):
    """Charge les messages pour une langue donnée."""
    global _MESSAGES
    if lang in _MESSAGES:
        return _MESSAGES[lang]
    i18n_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(i18n_dir, f"{lang}.json")
    if not os.path.exists(filepath):
        filepath = os.path.join(i18n_dir, "en.json")
        if not os.path.exists(filepath):
            return {}
    try:
        with open(filepath, encoding="utf-8") as f:
            _MESSAGES[lang] = json.load(f)
    except (json.JSONDecodeError, OSError):
        _MESSAGES[lang] = {}
    return _MESSAGES[lang]

def t(key, *args, **kwargs):
    """
    Traduit une clé en texte localisé.
    Args:
        key: Clé de traduction (ex: "error.timeout")
        *args, **kwargs: Arguments pour le formatage
    Returns:
        Texte traduit, ou la clé elle-même si non trouvée
    """
    lang = get_lang()
    messages = _load_messages(lang)
    parts = key.split(".")
    value = messages
    for part in parts:
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            en_messages = _load_messages("en")
            value = en_messages
            for p in parts:
                if isinstance(value, dict) and p in value:
                    value = value[p]
                else:
                    return key
            break
    if isinstance(value, str):
        if args or kwargs:
            try:
                return value.format(*args, **kwargs)
            except (IndexError, KeyError):
                return value
        return value
    return key

translate = t
