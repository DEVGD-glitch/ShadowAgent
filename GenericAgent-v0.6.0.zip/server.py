"""server.py — FastAPI + SSE API server for GenericAgent.

Exposes the GenericAgent as a REST API with Server-Sent Events streaming,
enabling third-party integrations, web UIs, and programmatic access.

Endpoints
---------
- ``POST /chat`` — Send a message and get a streaming response (SSE)
- ``POST /chat/sync`` — Send a message and wait for the full response
- ``POST /abort`` — Abort the current task
- ``GET /models`` — List available LLM models
- ``POST /models/switch`` — Switch to a different model
- ``GET /tools`` — List available tools
- ``GET /status`` — Agent status (running, idle, etc.)
- ``GET /memory/search`` — Semantic search over agent memory (RAG)
- ``WebSocket /ws/chat`` — Full-duplex chat via WebSocket

Example
-------
::

    curl -X POST http://localhost:8765/chat \\
         -H "Content-Type: application/json" \\
         -d '{"message": "Hello, what can you do?"}'

    # Stream via SSE
    curl -N http://localhost:8765/chat \\
         -H "Content-Type: application/json" \\
         -d '{"message": "Write a hello world", "stream": true}'
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import queue
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("server")

# ══════════════════════════════════════════════════════════════════════════════
#  Lazy imports — FastAPI is optional
# ══════════════════════════════════════════════════════════════════════════════

_fastapi_available = False
try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel, Field
    _fastapi_available = True
except ImportError:
    logger.debug("FastAPI not available — API server disabled")


def is_available() -> bool:
    """Check if FastAPI is installed and the server can run."""
    return _fastapi_available


# ══════════════════════════════════════════════════════════════════════════════
#  Request/Response models
# ══════════════════════════════════════════════════════════════════════════════

if _fastapi_available:

    class ChatRequest(BaseModel):
        """Chat message request."""
        message: str = Field(..., min_length=1, max_length=50000)
        stream: bool = True
        images: Optional[List[str]] = None
        source: str = "api"

    class SwitchModelRequest(BaseModel):
        """Model switch request."""
        index: int = Field(..., ge=0)

    class MemorySearchRequest(BaseModel):
        """Memory search request."""
        query: str = Field(..., min_length=1)
        top_k: int = Field(default=5, ge=1, le=20)
        category: Optional[str] = None


# ══════════════════════════════════════════════════════════════════════════════
#  Server creation
# ══════════════════════════════════════════════════════════════════════════════


def create_app(agent: Any = None) -> Any:
    """Create and configure the FastAPI application.

    Parameters
    ----------
    agent : GenericAgent | None
        The agent instance to serve.  If ``None``, a new one is created.

    Returns
    -------
    FastAPI
        The configured application.
    """
    if not _fastapi_available:
        raise RuntimeError("FastAPI is not installed. Run: pip install fastapi uvicorn")

    app = FastAPI(
        title="GenericAgent API",
        description="REST API for GenericAgent — an AI agent with tools, memory, and reasoning",
        version="0.5.0",
    )

    # CORS — allow all origins for local development
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Agent lifecycle ───────────────────────────────────────────────────

    _agent = agent
    _agent_thread: Optional[threading.Thread] = None
    _rag_engine: Optional[Any] = None  # Shared RAGEngine instance

    @app.on_event("startup")
    async def startup() -> None:
        nonlocal _agent, _agent_thread
        if _agent is None:
            from agentmain import GenericAgent
            _agent = GenericAgent()
        if not _agent.is_running:
            _agent_thread = threading.Thread(target=_agent.run, daemon=True)
            _agent_thread.start()
        logger.info("GenericAgent API server started")

    @app.on_event("shutdown")
    async def shutdown() -> None:
        if _agent is not None:
            _agent.abort()
        logger.info("GenericAgent API server stopped")

    # ── Chat endpoint (SSE streaming) ─────────────────────────────────────

    @app.post("/chat")
    async def chat(request: ChatRequest) -> Any:
        """Send a message and receive a streaming response via SSE."""
        if _agent is None:
            raise HTTPException(status_code=503, detail="Agent not initialized")

        display_queue = _agent.put_task(
            query=request.message,
            source=request.source,
            images=request.images,
        )

        if request.stream:
            return StreamingResponse(
                _stream_queue(display_queue),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )
        else:
            # Synchronous — collect full response
            result = _collect_response(display_queue)
            return JSONResponse(content={"response": result})

    @app.post("/chat/sync")
    async def chat_sync(request: ChatRequest) -> Any:
        """Send a message and wait for the complete response."""
        if _agent is None:
            raise HTTPException(status_code=503, detail="Agent not initialized")

        request.stream = False
        return await chat(request)

    # ── Abort ─────────────────────────────────────────────────────────────

    @app.post("/abort")
    async def abort() -> Any:
        """Abort the current task."""
        if _agent is not None:
            _agent.abort()
        return {"status": "aborted"}

    # ── Models ────────────────────────────────────────────────────────────

    @app.get("/models")
    async def list_models() -> Any:
        """List available LLM models."""
        if _agent is None:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        models = _agent.list_llms()
        return {
            "models": [
                {"index": i, "name": name, "active": active}
                for i, name, active in models
            ]
        }

    @app.post("/models/switch")
    async def switch_model(request: SwitchModelRequest) -> Any:
        """Switch to a different LLM model."""
        if _agent is None:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        try:
            _agent.next_llm(request.index)
            name = _agent.get_llm_name(model=True)
            return {"status": "switched", "model": name}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc))

    # ── Tools ─────────────────────────────────────────────────────────────

    @app.get("/tools")
    async def list_tools() -> Any:
        """List available tools."""
        try:
            from tools import get_registry
            registry = get_registry()
            return {
                "tools": [
                    {
                        "name": t.name,
                        "description": t.description,
                        "category": t.category,
                        "source": t.source,
                        "requires_confirmation": t.requires_confirmation,
                    }
                    for t in registry.list_tools()
                ]
            }
        except ImportError:
            return {"tools": []}

    # ── Status ────────────────────────────────────────────────────────────

    @app.get("/status")
    async def status() -> Any:
        """Get agent status."""
        if _agent is None:
            return {"status": "not_initialized"}

        return {
            "status": "running" if _agent.is_running else "idle",
            "model": _agent.get_llm_name(model=True) if _agent.is_running else None,
        }

    # ── Memory search (RAG) ──────────────────────────────────────────────

    @app.post("/memory/search")
    async def memory_search(request: MemorySearchRequest) -> Any:
        """Search agent memory using semantic similarity."""
        nonlocal _rag_engine
        try:
            from memory.vector import RAGEngine

            # Reuse shared RAGEngine instance instead of creating per-request
            if _rag_engine is None:
                store_path = os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "memory",
                    "vector_store.json",
                )
                _rag_engine = RAGEngine(store_path=store_path)

            results = _rag_engine.search(
                request.query, top_k=request.top_k, category=request.category
            )

            return {
                "results": [
                    {
                        "text": doc.text[:500],
                        "score": round(score, 4),
                        "source": doc.metadata.get("source", ""),
                        "category": doc.metadata.get("category", ""),
                    }
                    for doc, score in results
                ]
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc))

    # ── MCP status ────────────────────────────────────────────────────────

    @app.get("/mcp/status")
    async def mcp_status() -> Any:
        """Get MCP server connection status."""
        if _agent is not None and hasattr(_agent, "_mcp_client"):
            try:
                return {"servers": _agent._mcp_client.get_status()}
            except Exception:
                pass
        return {"servers": {}}

    # ── WebSocket ─────────────────────────────────────────────────────────

    @app.websocket("/ws/chat")
    async def websocket_chat(websocket: Any) -> None:
        """Full-duplex chat via WebSocket."""
        await websocket.accept()
        try:
            while True:
                data = await websocket.receive_text()
                try:
                    msg = json.loads(data)
                    message = msg.get("message", data)
                except json.JSONDecodeError:
                    message = data

                if _agent is None:
                    await websocket.send_json({"error": "Agent not initialized"})
                    continue

                display_queue = _agent.put_task(query=message, source="websocket")

                # Stream responses back
                while True:
                    try:
                        item = display_queue.get(timeout=0.1)
                        if "done" in item:
                            await websocket.send_json(
                                {"type": "done", "content": item["done"]}
                            )
                            break
                        elif "next" in item:
                            await websocket.send_json(
                                {"type": "chunk", "content": item["next"]}
                            )
                    except queue.Empty:
                        await asyncio.sleep(0.05)
        except Exception:
            pass

    return app


# ══════════════════════════════════════════════════════════════════════════════
#  Streaming helpers
# ══════════════════════════════════════════════════════════════════════════════


async def _stream_queue(display_queue: queue.Queue) -> Any:
    """Yield SSE events from a display queue."""
    while True:
        try:
            item = display_queue.get(timeout=0.1)
        except queue.Empty:
            yield f": keepalive\n\n"
            await asyncio.sleep(0.05)
            continue

        if "done" in item:
            data = json.dumps({"type": "done", "content": item["done"]}, ensure_ascii=False)
            yield f"data: {data}\n\n"
            break
        elif "next" in item:
            data = json.dumps({"type": "chunk", "content": item["next"]}, ensure_ascii=False)
            yield f"data: {data}\n\n"

        await asyncio.sleep(0.01)


def _collect_response(display_queue: queue.Queue, timeout: int = 300) -> str:
    """Collect the full response from a display queue."""
    full_response = ""
    start_time = time.time()

    while time.time() - start_time < timeout:
        try:
            item = display_queue.get(timeout=1.0)
        except queue.Empty:
            continue

        if "done" in item:
            return item["done"]
        elif "next" in item:
            full_response += item["next"]

    return full_response + "\n[Timeout: response took too long]"


# ══════════════════════════════════════════════════════════════════════════════
#  Server runner
# ══════════════════════════════════════════════════════════════════════════════


def run_server(host: str = "0.0.0.0", port: int = 8765, agent: Any = None) -> None:
    """Start the API server.

    Parameters
    ----------
    host : str
        Bind address.
    port : int
        Port number.
    agent : GenericAgent | None
        The agent instance to serve.
    """
    if not _fastapi_available:
        print("Error: FastAPI is not installed. Run: pip install fastapi uvicorn")
        return

    import uvicorn

    app = create_app(agent)
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    run_server()
