"""memory/crystallization.py — Automatic skill crystallization engine for GenericAgent.

This module provides the infrastructure for automatic skill crystallization,
turning the LLM-guided, prompt-only memory update process into a robust,
code-enforced system.  It implements five key improvements:

1. **Auto-crystallization trigger** — Detects when a long task (15+ turns)
   completes and automatically injects a ``start_long_term_update`` prompt
   into the agent's done-hooks queue.

2. **L1 auto-sync** — After a new SOP is written to L3, parses the file
   and updates the L1 insight index (``global_mem_insight.txt``) automatically.

3. **Working checkpoint persistence** — Saves ``key_info`` and
   ``related_sop`` to disk so they survive crashes and restarts.

4. **RAG auto-indexing** — When a new SOP or memory file is written,
   automatically indexes it into the VectorStore for semantic search.

5. **Crystallization metrics** — Tracks how often crystallization occurs
   and what was written, for observability.

Usage
-----
This module is used automatically by :mod:`agent_loop` and :mod:`agentmain.core`.
No manual intervention is required — just import the module to enable
auto-crystallization hooks.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from logging_config import get_logger

logger = get_logger("memory.crystallization")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

#: Minimum number of turns before auto-crystallization is triggered.
CRYSTALLIZATION_MIN_TURNS = 15

#: Path to the working checkpoint file (relative to project root).
CHECKPOINT_FILE = os.path.join("temp", "_working_checkpoint.json")

#: Path to the L1 insight index file.
L1_INSIGHT_PATH = os.path.join("memory", "global_mem_insight.txt")

#: Path to the L2 global memory file.
L2_GLOBAL_MEM_PATH = os.path.join("memory", "global_mem.txt")

#: Path to the L0 memory management SOP.
L0_SOP_PATH = os.path.join("memory", "memory_management_sop.md")

#: Directory containing L3 SOPs.
L3_SOP_DIR = os.path.join("memory")

#: Maximum L1 line count (hard constraint from original design).
L1_MAX_LINES = 30

#: Crystallization event log (for metrics).
CRYSTALLIZATION_LOG = os.path.join("temp", "_crystallization_log.json")


# ---------------------------------------------------------------------------
# Crystallization Metrics
# ---------------------------------------------------------------------------

@dataclass
class CrystallizationMetrics:
    """Tracks crystallization events for observability.

    Attributes
    ----------
    total_triggers : int
        Number of times auto-crystallization was triggered.
    successful_writes : int
        Number of times a memory write actually occurred.
    l1_syncs : int
        Number of L1 auto-syncs performed.
    rag_indexed : int
        Number of documents indexed into the vector store.
    checkpoint_saves : int
        Number of working checkpoint saves to disk.
    """

    total_triggers: int = 0
    successful_writes: int = 0
    l1_syncs: int = 0
    rag_indexed: int = 0
    checkpoint_saves: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "total_triggers": self.total_triggers,
            "successful_writes": self.successful_writes,
            "l1_syncs": self.l1_syncs,
            "rag_indexed": self.rag_indexed,
            "checkpoint_saves": self.checkpoint_saves,
        }


# Global metrics instance
_metrics = CrystallizationMetrics()


def get_crystallization_metrics() -> CrystallizationMetrics:
    """Return the global crystallization metrics instance."""
    return _metrics


def reset_crystallization_metrics() -> None:
    """Reset crystallization metrics (useful for testing)."""
    global _metrics
    _metrics = CrystallizationMetrics()


# ---------------------------------------------------------------------------
# 1. Auto-Crystallization Trigger
# ---------------------------------------------------------------------------

def should_crystallize(turn: int, exit_reason: dict[str, Any]) -> bool:
    """Determine whether auto-crystallization should be triggered.

    Crystallization is triggered when:
    - The task completed normally (``CURRENT_TASK_DONE``) or exited.
    - The task ran for at least ``CRYSTALLIZATION_MIN_TURNS`` turns.
    - The exit was not caused by a user abort.

    Parameters
    ----------
    turn : int
        The current turn number (1-based).
    exit_reason : dict
        The exit reason from the agent loop.

    Returns
    -------
    bool
        True if crystallization should be triggered.
    """
    if turn < CRYSTALLIZATION_MIN_TURNS:
        return False

    result = exit_reason.get("result", "")
    if result not in ("CURRENT_TASK_DONE", "EXITED"):
        return False

    # Don't crystallize on user-initiated aborts
    data = exit_reason.get("data")
    if isinstance(data, dict) and data.get("status") == "aborted":
        return False

    return True


def get_crystallization_prompt() -> str:
    """Return the auto-crystallization prompt to inject as a done-hook.

    This prompt instructs the LLM to perform the ``start_long_term_update``
    distillation process, extracting verified experience into long-term memory.
    It is injected automatically when a long task completes.
    """
    return (
        "\n\n### [Auto-Crystallization Triggered]\n"
        "This task ran for 15+ turns and has completed. You MUST now call "
        "`start_long_term_update` to distill verified experience into long-term memory.\n"
        "Follow the L0 memory management SOP strictly:\n"
        "- Extract only **action-verified** information.\n"
        "- Environment facts → file_patch update L2, sync L1.\n"
        "- Complex task experience → write concise SOP to L3.\n"
        "- After writing to L3, L1 will be auto-synced.\n"
        "- If nothing new or verified, skip the call.\n"
    )


# ---------------------------------------------------------------------------
# 2. L1 Auto-Sync
# ---------------------------------------------------------------------------

def _find_project_root() -> str:
    """Walk up from this file to find the project root (where memory/ lives)."""
    d = os.path.dirname(os.path.abspath(__file__))
    # We're already in memory/ — project root is parent
    return os.path.dirname(d)


def auto_sync_l1(sop_name: str, sop_description: str, project_root: Optional[str] = None) -> bool:
    """Automatically update the L1 insight index after a new SOP is written.

    This function reads the current L1 file, adds a reference to the new SOP
    in the L3 section, and ensures the total line count stays within the
    ``L1_MAX_LINES`` constraint by trimming older entries if needed.

    Parameters
    ----------
    sop_name : str
        The filename of the new SOP (e.g. ``"stock_screening_sop.md"``).
    sop_description : str
        A short description of the SOP (e.g. ``"stock screening with EXPMA"``).
    project_root : str | None
        Project root path.  If ``None``, auto-detected.

    Returns
    -------
    bool
        True if L1 was updated, False if it failed or was skipped.
    """
    root = project_root or _find_project_root()
    l1_path = os.path.join(root, L1_INSIGHT_PATH)

    if not os.path.exists(l1_path):
        logger.warning("L1 insight file not found at %s", l1_path)
        return False

    try:
        with open(l1_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except (IOError, OSError) as exc:
        logger.error("Failed to read L1: %s", exc)
        return False

    # Check if this SOP is already referenced in L1
    content = "".join(lines)
    if sop_name in content:
        logger.debug("SOP %s already referenced in L1, skipping", sop_name)
        return False

    # Find the L3 section and add the new SOP reference
    new_entry = f" | {sop_name}({sop_description})"
    l3_pattern = re.compile(r"(L3:.*?)(\n)")
    match = l3_pattern.search(content)

    if match:
        # Append to existing L3 line
        l3_line = match.group(1) + new_entry
        content = content[: match.start(1)] + l3_line + content[match.end(2) - 1 :]
    else:
        # No L3 section found — add one before [RULES]
        rules_pattern = re.compile(r"\[RULES\]")
        rules_match = rules_pattern.search(content)
        if rules_match:
            l3_section = f"L3: {sop_name}({sop_description})\n\n"
            content = content[: rules_match.start()] + l3_section + content[rules_match.start() :]
        else:
            # Append at the end
            content += f"\nL3: {sop_name}({sop_description})\n"

    # Enforce L1_MAX_LINES constraint — trim oldest L3 entries if needed
    result_lines = content.split("\n")
    if len(result_lines) > L1_MAX_LINES:
        # Keep the header and [RULES] section, trim L3 entries
        logger.info("L1 exceeded %d lines, trimming older entries", L1_MAX_LINES)
        # Simple strategy: keep first 10 lines and last 20 lines
        result_lines = result_lines[:10] + result_lines[-20:]

    try:
        with open(l1_path, "w", encoding="utf-8") as f:
            f.write("\n".join(result_lines))
        _metrics.l1_syncs += 1
        logger.info("L1 auto-synced with new SOP: %s", sop_name)
        return True
    except (IOError, OSError) as exc:
        logger.error("Failed to write L1: %s", exc)
        return False


def auto_sync_l1_from_file(file_path: str, project_root: Optional[str] = None) -> bool:
    """Auto-sync L1 by reading a newly created SOP file.

    Extracts the SOP name and a short description from the file's first
    heading or first line, then calls :func:`auto_sync_l1`.

    Parameters
    ----------
    file_path : str
        Path to the new SOP file.
    project_root : str | None
        Project root path.

    Returns
    -------
    bool
        True if L1 was updated.
    """
    sop_name = os.path.basename(file_path)

    # Try to extract a description from the first heading
    description = ""
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("# "):
                    description = line[2:].strip()[:80]
                    break
                if line and not line.startswith("#") and len(line) > 10:
                    description = line[:80]
                    break
    except (IOError, OSError):
        pass

    if not description:
        # Generate description from filename
        description = sop_name.replace("_", " ").replace("-", " ").replace(".md", "").replace(".py", "")

    return auto_sync_l1(sop_name, description, project_root)


# ---------------------------------------------------------------------------
# 3. Working Checkpoint Persistence
# ---------------------------------------------------------------------------

def save_working_checkpoint(
    key_info: str,
    related_sop: str = "",
    project_root: Optional[str] = None,
) -> bool:
    """Persist the working checkpoint (key_info + related_sop) to disk.

    This ensures that working memory survives agent crashes and restarts.
    The checkpoint is saved as a JSON file in the ``temp/`` directory.

    Parameters
    ----------
    key_info : str
        The key information string from the working memory.
    related_sop : str
        The related SOP reference.
    project_root : str | None
        Project root path.

    Returns
    -------
    bool
        True if saved successfully.
    """
    root = project_root or _find_project_root()
    checkpoint_path = os.path.join(root, CHECKPOINT_FILE)

    data = {
        "key_info": key_info,
        "related_sop": related_sop,
        "timestamp": time.time(),
        "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    try:
        os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
        with open(checkpoint_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        _metrics.checkpoint_saves += 1
        logger.debug("Working checkpoint saved to %s", checkpoint_path)
        return True
    except (IOError, OSError) as exc:
        logger.error("Failed to save working checkpoint: %s", exc)
        return False


def load_working_checkpoint(project_root: Optional[str] = None) -> dict[str, Any]:
    """Load the persisted working checkpoint from disk.

    Parameters
    ----------
    project_root : str | None
        Project root path.

    Returns
    -------
    dict
        The checkpoint data, or an empty dict if not found.
    """
    root = project_root or _find_project_root()
    checkpoint_path = os.path.join(root, CHECKPOINT_FILE)

    if not os.path.exists(checkpoint_path):
        return {}

    try:
        with open(checkpoint_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        logger.debug("Working checkpoint loaded from %s", checkpoint_path)
        return data
    except (json.JSONDecodeError, IOError, OSError) as exc:
        logger.error("Failed to load working checkpoint: %s", exc)
        return {}


def clear_working_checkpoint(project_root: Optional[str] = None) -> bool:
    """Clear the persisted working checkpoint.

    Parameters
    ----------
    project_root : str | None
        Project root path.

    Returns
    -------
    bool
        True if cleared successfully.
    """
    root = project_root or _find_project_root()
    checkpoint_path = os.path.join(root, CHECKPOINT_FILE)

    try:
        if os.path.exists(checkpoint_path):
            os.remove(checkpoint_path)
        return True
    except (IOError, OSError) as exc:
        logger.error("Failed to clear working checkpoint: %s", exc)
        return False


# ---------------------------------------------------------------------------
# 4. RAG Auto-Indexing
# ---------------------------------------------------------------------------

def auto_index_to_rag(
    file_path: str,
    category: str = "sop",
    project_root: Optional[str] = None,
) -> int:
    """Automatically index a new SOP or memory file into the VectorStore.

    This function reads the file content and indexes it into the RAG engine
    for future semantic search.  If the RAG engine is not available (e.g.
    no embedding API configured), it silently returns 0.

    Uses the shared RAGEngine singleton (see :func:`get_shared_rag_engine`)
    so that the vector store and embedding model are loaded only once.

    Parameters
    ----------
    file_path : str
        Path to the file to index.
    category : str
        Category for the content (``"sop"``, ``"doc"``, ``"conversation"``).
    project_root : str | None
        Project root path.

    Returns
    -------
    int
        Number of chunks indexed, or 0 if indexing was skipped/failed.
    """
    if not os.path.exists(file_path):
        logger.warning("File not found for RAG indexing: %s", file_path)
        return 0

    try:
        root = project_root or _find_project_root()
        store_path = os.path.join(root, "memory", "vector_store.json")

        engine = get_shared_rag_engine(store_path=store_path)
        chunks = engine.index_file(file_path, category=category)
        engine.save()

        _metrics.rag_indexed += 1
        logger.info("Auto-indexed %s into RAG (%d chunks)", file_path, chunks)
        return chunks

    except ImportError:
        logger.debug("RAG engine not available, skipping auto-indexing")
        return 0
    except Exception as exc:
        logger.error("RAG auto-indexing failed for %s: %s", file_path, exc)
        return 0


def auto_index_text_to_rag(
    text: str,
    source: str = "crystallization",
    category: str = "sop",
    project_root: Optional[str] = None,
) -> int:
    """Automatically index text content into the VectorStore.

    Uses the shared RAGEngine singleton so that the vector store and
    embedding model are loaded only once.

    Parameters
    ----------
    text : str
        Text content to index.
    source : str
        Source identifier.
    category : str
        Category for the content.
    project_root : str | None
        Project root path.

    Returns
    -------
    int
        Number of chunks indexed, or 0 if indexing was skipped/failed.
    """
    if not text.strip():
        return 0

    try:
        root = project_root or _find_project_root()
        store_path = os.path.join(root, "memory", "vector_store.json")

        engine = get_shared_rag_engine(store_path=store_path)
        chunks = engine.index_text(text, source=source, category=category)
        engine.save()

        _metrics.rag_indexed += 1
        logger.info("Auto-indexed text (%d chars, %d chunks) into RAG", len(text), chunks)
        return chunks

    except ImportError:
        logger.debug("RAG engine not available, skipping auto-indexing")
        return 0
    except Exception as exc:
        logger.error("RAG text auto-indexing failed: %s", exc)
        return 0


# ---------------------------------------------------------------------------
# 5. Crystallization Event Logging
# ---------------------------------------------------------------------------

def log_crystallization_event(
    event_type: str,
    details: dict[str, Any],
    project_root: Optional[str] = None,
) -> None:
    """Log a crystallization event for metrics and debugging.

    Parameters
    ----------
    event_type : str
        Type of event (``"auto_trigger"``, ``"l1_sync"``, ``"rag_index"``,
        ``"checkpoint_save"``).
    details : dict
        Additional details about the event.
    project_root : str | None
        Project root path.
    """
    root = project_root or _find_project_root()
    log_path = os.path.join(root, CRYSTALLIZATION_LOG)

    event = {
        "timestamp": time.time(),
        "datetime": time.strftime("%Y-%m-%d %H:%M:%S"),
        "event_type": event_type,
        "details": details,
    }

    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)

        # Read existing log
        events = []
        if os.path.exists(log_path):
            with open(log_path, "r", encoding="utf-8") as f:
                events = json.load(f)

        events.append(event)

        # Keep only the last 100 events to prevent unbounded growth
        events = events[-100:]

        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(events, f, ensure_ascii=False, indent=2)

    except (IOError, OSError, json.JSONDecodeError) as exc:
        logger.error("Failed to log crystallization event: %s", exc)


# ---------------------------------------------------------------------------
# 6. Unified Crystallization Hook (for agent_loop.py)
# ---------------------------------------------------------------------------

class CrystallizationHook:
    """Hook class that integrates auto-crystallization into the agent loop.

    This class is designed to be used as a ``turn_end_callback`` supplement
    in :func:`agent_runner_loop`.  It monitors task progress and triggers
    crystallization when appropriate.

    Usage::

        from memory.crystallization import CrystallizationHook

        hook = CrystallizationHook()
        # ... in agent_runner_loop, after exit_reason is set:
        if hook.should_trigger(turn, exit_reason):
            handler._done_hooks.append(hook.get_prompt())
    """

    def __init__(self, min_turns: int = CRYSTALLIZATION_MIN_TURNS) -> None:
        self.min_turns = min_turns
        self._triggered = False

    def should_trigger(self, turn: int, exit_reason: dict[str, Any]) -> bool:
        """Check if crystallization should be triggered.

        Uses the hook's own ``min_turns`` value instead of the global
        ``CRYSTALLIZATION_MIN_TURNS``.
        """
        if self._triggered:
            return False  # Only trigger once per task
        if turn < self.min_turns:
            return False

        result = exit_reason.get("result", "")
        if result not in ("CURRENT_TASK_DONE", "EXITED"):
            return False

        # Don't crystallize on user-initiated aborts
        data = exit_reason.get("data")
        if isinstance(data, dict) and data.get("status") == "aborted":
            return False

        self._triggered = True
        _metrics.total_triggers += 1
        log_crystallization_event("auto_trigger", {
            "turn": turn,
            "exit_reason": exit_reason.get("result", ""),
        })
        return True

    def get_prompt(self) -> str:
        """Return the crystallization prompt."""
        return get_crystallization_prompt()

    def reset(self) -> None:
        """Reset the hook for a new task."""
        self._triggered = False


# ---------------------------------------------------------------------------
# 7. Shared RAG Engine Singleton
# ---------------------------------------------------------------------------

_shared_rag_engine: Optional[Any] = None
_shared_rag_lock = threading.Lock()


def get_shared_rag_engine(store_path: Optional[str] = None) -> Any:
    """Return a shared RAGEngine singleton.

    This avoids creating a new ``RAGEngine`` (and re-loading the entire
    vector store + embedding model) on every auto-index call.  The first
    call creates the instance; subsequent calls return the cached one.

    Parameters
    ----------
    store_path : str | None
        Path to the vector store JSON.  Only used on the first call.

    Returns
    -------
    RAGEngine
        The shared engine instance.
    """
    global _shared_rag_engine

    if _shared_rag_engine is not None:
        return _shared_rag_engine

    with _shared_rag_lock:
        # Double-checked locking
        if _shared_rag_engine is not None:
            return _shared_rag_engine

        from memory.vector import RAGEngine
        _shared_rag_engine = RAGEngine(store_path=store_path)
        # Load existing data if available
        _shared_rag_engine.load()
        logger.debug("Shared RAGEngine singleton created")
        return _shared_rag_engine


def reset_shared_rag_engine() -> None:
    """Reset the shared RAG engine singleton (useful for testing)."""
    global _shared_rag_engine
    with _shared_rag_lock:
        _shared_rag_engine = None


# ---------------------------------------------------------------------------
# 8. File-Write Observer (for auto L1 sync + RAG indexing)
# ---------------------------------------------------------------------------

class MemoryWriteObserver:
    """Observes file writes to the memory/ directory and auto-syncs L1 + RAG.

    This observer is called after a tool writes a file to the ``memory/``
    directory.  It checks if the file is a new SOP (L3) and automatically:
    1. Syncs L1 with the new SOP reference.
    2. Indexes the file into the RAG vector store.

    Usage in ga.py::

        from memory.crystallization import MemoryWriteObserver

        observer = MemoryWriteObserver()
        # After file_write or file_patch to memory/:
        observer.on_memory_write(file_path)
    """

    #: Patterns that indicate an L3 SOP file.
    SOP_PATTERNS = [
        re.compile(r"_sop\.md$", re.IGNORECASE),
        re.compile(r"sop[_\-]", re.IGNORECASE),
        re.compile(r"_skill\.md$", re.IGNORECASE),
        re.compile(r"skill[_\-]", re.IGNORECASE),
    ]

    #: Patterns to skip (not L3 content).
    SKIP_PATTERNS = [
        re.compile(r"global_mem_insight", re.IGNORECASE),  # L1 itself
        re.compile(r"global_mem\.txt", re.IGNORECASE),     # L2
        re.compile(r"memory_management_sop", re.IGNORECASE),  # L0
        re.compile(r"L4_raw_sessions", re.IGNORECASE),     # L4
        re.compile(r"chat_history", re.IGNORECASE),        # Chat log
        re.compile(r"vector_store\.json", re.IGNORECASE),  # Vector store
        re.compile(r"__pycache__", re.IGNORECASE),         # Python cache
    ]

    def is_sop_file(self, file_path: str) -> bool:
        """Check if a file looks like an L3 SOP file.

        Parameters
        ----------
        file_path : str
            Path to the file.

        Returns
        -------
        bool
            True if the file matches SOP patterns and isn't in the skip list.
        """
        basename = os.path.basename(file_path)

        # Skip patterns take precedence
        for pattern in self.SKIP_PATTERNS:
            if pattern.search(file_path):
                return False

        # Check SOP patterns
        for pattern in self.SOP_PATTERNS:
            if pattern.search(basename):
                return True

        # Also check if it's a .md or .py file directly in the memory/ directory
        # that isn't in a subdirectory (L3 SOPs live directly in memory/)
        dir_name = os.path.dirname(os.path.abspath(file_path))
        parent_name = os.path.basename(dir_name)
        if parent_name == "memory" and basename.endswith((".md", ".py")):
            return True

        return False

    def on_memory_write(self, file_path: str, project_root: Optional[str] = None) -> dict[str, Any]:
        """Handle a file write to the memory/ directory.

        This method is called after a tool writes a file.  If the file is
        an L3 SOP, it auto-syncs L1 and indexes the file into RAG.

        Parameters
        ----------
        file_path : str
            Path to the file that was written.
        project_root : str | None
            Project root path.

        Returns
        -------
        dict
            Summary of actions taken.
        """
        result = {"file": file_path, "l1_synced": False, "rag_indexed": 0}

        if not self.is_sop_file(file_path):
            logger.debug("File %s is not an L3 SOP, skipping observer", file_path)
            return result

        logger.info("L3 SOP detected: %s — running auto-sync and RAG indexing", file_path)

        # 1. Auto-sync L1
        try:
            result["l1_synced"] = auto_sync_l1_from_file(file_path, project_root)
        except Exception as exc:
            logger.error("L1 auto-sync failed: %s", exc)

        # 2. Auto-index into RAG
        try:
            result["rag_indexed"] = auto_index_to_rag(file_path, category="sop", project_root=project_root)
        except Exception as exc:
            logger.error("RAG auto-indexing failed: %s", exc)

        # 3. Log the event
        log_crystallization_event("memory_write_observed", {
            "file": file_path,
            "l1_synced": result["l1_synced"],
            "rag_indexed": result["rag_indexed"],
        })

        return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "CrystallizationHook",
    "CrystallizationMetrics",
    "MemoryWriteObserver",
    "auto_index_text_to_rag",
    "auto_index_to_rag",
    "auto_sync_l1",
    "auto_sync_l1_from_file",
    "clear_working_checkpoint",
    "get_crystallization_metrics",
    "get_crystallization_prompt",
    "get_shared_rag_engine",
    "load_working_checkpoint",
    "log_crystallization_event",
    "reset_crystallization_metrics",
    "reset_shared_rag_engine",
    "save_working_checkpoint",
    "should_crystallize",
]
