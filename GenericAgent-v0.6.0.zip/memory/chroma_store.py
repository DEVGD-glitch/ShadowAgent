"""Substrat memoire vectoriel inspire de ChromaDB pour GenericAgent.

Ce module fournit un magasin de vecteurs en processus avec recherche par
similarite cosinus, collections espacees par domaine de connaissance, et
filtrage de metadonnees de type SQL.  Il fonctionne en deux modes :

- **Mode natif** : si ``chromadb`` est installe, il delegue le stockage et
  la recherche a ChromaDB pour beneficier de l'index HNSW.
- **Mode fallback** : sinon, un magasin minimal base sur ``numpy`` est utilise
  (similarite cosinus brute, sans index approximatif).

Usage::

    from memory.chroma_store import ChromaMemoryStore

    store = ChromaMemoryStore()
    coll = store.get_or_create_collection("navigation")
    coll.add(
        documents=["Aller a la page d'accueil", "Cliquer sur le bouton valider"],
        metadatas=[{"category": "nav"}, {"category": "action"}],
        ids=["nav_1", "nav_2"],
    )
    results = coll.query(query_texts=["comment naviguer ?"], n_results=5)
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import uuid
from typing import Any, Callable, Optional, Sequence

from logging_config import get_logger

logger = get_logger("memory.chroma_store")

# ---------------------------------------------------------------------------
# Import conditionnel de chromadb et numpy
# ---------------------------------------------------------------------------
try:
    import chromadb  # type: ignore[import-untyped]
    _CHROMADB_AVAILABLE = True
except ImportError:
    _CHROMADB_AVAILABLE = False

try:
    import numpy as np  # type: ignore[import-untyped]
    _NUMPY_AVAILABLE = True
except ImportError:
    _NUMPY_AVAILABLE = False


# ---------------------------------------------------------------------------
# Fonctions d'embedding par defaut
# ---------------------------------------------------------------------------

def _simple_hash_embed(text: str, dim: int = 384) -> list[float]:
    """Embedding simpliste base sur le hachage, utilise comme fallback.

    Genere un vecteur de dimension *dim* a partir de *text* en utilisant
    SHA-256 par tranches.  Le resultat est normalise pour etre compatible
    avec la similarite cosinus.

    Parameters
    ----------
    text : str
        Texte a encoder.
    dim : int
        Dimension du vecteur de sortie.

    Returns
    -------
    list[float]
        Vecteur normalise de dimension *dim*.
    """
    vec: list[float] = []
    for i in range(dim):
        h = hashlib.sha256(f"{text}|{i}".encode("utf-8")).hexdigest()
        val = int(h[:8], 16) / 0xFFFFFFFF
        vec.append(val * 2.0 - 1.0)
    norm = sum(v * v for v in vec) ** 0.5
    if norm < 1e-12:
        return vec
    return [v / norm for v in vec]


def _sentence_transformer_embed(texts: list[str], model_name: str = "all-MiniLM-L6-v2") -> list[list[float]]:
    """Embedding via sentence-transformers (si disponible).

    Parameters
    ----------
    texts : list[str]
        Textes a encoder.
    model_name : str
        Nom du modele sentence-transformers.

    Returns
    -------
    list[list[float]]
        Liste de vecteurs d'embedding.

    Raises
    ------
    ImportError
        Si sentence-transformers n'est pas installe.
    """
    from sentence_transformers import SentenceTransformer  # type: ignore[import-untyped]
    _model = SentenceTransformer(model_name)
    embeddings = _model.encode(texts, convert_to_numpy=True)
    return embeddings.tolist()


# ---------------------------------------------------------------------------
# Filtrage de metadonnees
# ---------------------------------------------------------------------------

#: Operateurs de filtrage supportes.
_SUPPORTED_OPERATORS = {"$eq", "$ne", "$gt", "$gte", "$lt", "$lte", "$in", "$nin"}


def _evaluate_operator(field_value: Any, operator: str, filter_value: Any) -> bool:
    """Evaluer un operateur de filtrage sur une valeur de champ.

    Parameters
    ----------
    field_value : Any
        Valeur du champ dans le document.
    operator : str
        Operateur (par ex. ``"$gte"``).
    filter_value : Any
        Valeur de comparaison.

    Returns
    -------
    bool
        Resultat de l'evaluation.
    """
    if operator == "$eq":
        return field_value == filter_value
    if operator == "$ne":
        return field_value != filter_value
    if operator == "$gt":
        return field_value > filter_value
    if operator == "$gte":
        return field_value >= filter_value
    if operator == "$lt":
        return field_value < filter_value
    if operator == "$lte":
        return field_value <= filter_value
    if operator == "$in":
        return field_value in filter_value
    if operator == "$nin":
        return field_value not in filter_value
    logger.warning("Operateur de filtrage non reconnu : %s", operator)
    return False


def _matches_where(metadata: dict[str, Any], where: dict[str, Any]) -> bool:
    """Verifier si des metadonnees satisfont une clause ``where``.

    La clause ``where`` est un dictionnaire dont les cles sont des noms de
    champs et les valeurs sont soit des valeurs directes (egalite implicite),
    soit des dictionnaires d'operateurs.  Exemples ::

        where={"category": "tech"}
        where={"year": {"$gte": 2024}, "category": {"$in": ["tech", "sci"]}}

    Parameters
    ----------
    metadata : dict
        Metadonnees du document.
    where : dict
        Clause de filtrage.

    Returns
    -------
    bool
        ``True`` si les metadonnees satisfont la clause.
    """
    for key, condition in where.items():
        field_val = metadata.get(key)
        if field_val is None:
            return False
        if isinstance(condition, dict):
            for op, val in condition.items():
                if op not in _SUPPORTED_OPERATORS:
                    logger.warning("Operateur non supporte : %s", op)
                    return False
                if not _evaluate_operator(field_val, op, val):
                    return False
        else:
            # Egalite implicite
            if field_val != condition:
                return False
    return True


def _matches_where_document(document: str, where_document: dict[str, Any]) -> bool:
    """Verifier si un document texte satisfait une clause ``where_document``.

    Supporte ``$contains`` pour la recherche de sous-chaine.

    Parameters
    ----------
    document : str
        Contenu textuel du document.
    where_document : dict
        Clause de filtrage document (par ex. ``{"$contains": "python"}``).

    Returns
    -------
    bool
        ``True`` si le document satisfait la clause.
    """
    for op, val in where_document.items():
        if op == "$contains":
            if val not in document:
                return False
        else:
            logger.warning("Operateur where_document non supporte : %s", op)
            return False
    return True


# ---------------------------------------------------------------------------
# Cosine similarity (fallback numpy / pure-python)
# ---------------------------------------------------------------------------

def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Calculer la similarite cosinus entre deux vecteurs.

    Parameters
    ----------
    a : list[float]
        Premier vecteur.
    b : list[float]
        Second vecteur.

    Returns
    -------
    float
        Similarite cosinus dans [-1, 1].
    """
    if _NUMPY_AVAILABLE:
        na = np.array(a, dtype=np.float64)
        nb = np.array(b, dtype=np.float64)
        dot = float(np.dot(na, nb))
        norm_a = float(np.linalg.norm(na))
        norm_b = float(np.linalg.norm(nb))
    else:
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
    if norm_a < 1e-12 or norm_b < 1e-12:
        return 0.0
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# MemoryCollection (mode fallback sans chromadb)
# ---------------------------------------------------------------------------

class MemoryCollection:
    """Conteneur nomme pour embeddings, documents et metadonnees.

    Cette classe implemente un magasin vectoriel minimal lorsque ``chromadb``
    n'est pas disponible.  Elle supporte l'ajout, la requete, la recherche
    par similarite cosinus, et le filtrage de metadonnees.

    Attributes
    ----------
    name : str
        Nom de la collection.
    metadata : dict
        Metadonnees de la collection.
    """

    def __init__(
        self,
        name: str,
        embedding_function: Optional[Callable[[list[str]], list[list[float]]]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        self.name: str = name
        self.metadata: dict[str, Any] = metadata or {}
        self._embedding_fn: Callable[[list[str]], list[list[float]]] = embedding_function or self._default_embed
        self._ids: list[str] = []
        self._documents: list[str] = []
        self._metadatas: list[dict[str, Any]] = []
        self._embeddings: list[list[float]] = []
        self._lock = threading.Lock()

    @staticmethod
    def _default_embed(texts: list[str]) -> list[list[float]]:
        """Fonction d'embedding par defaut (hash ou sentence-transformers).

        Parameters
        ----------
        texts : list[str]
            Textes a encoder.

        Returns
        -------
        list[list[float]]
            Vecteurs d'embedding.
        """
        try:
            return _sentence_transformer_embed(texts)
        except ImportError:
            return [_simple_hash_embed(t) for t in texts]

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def add(
        self,
        documents: list[str],
        metadatas: Optional[list[dict[str, Any]]] = None,
        ids: Optional[list[str]] = None,
    ) -> None:
        """Ajouter des documents a la collection.

        Parameters
        ----------
        documents : list[str]
            Textes a indexer.
        metadatas : list[dict] | None
            Metadonnees associees (une par document).
        ids : list[str] | None
            Identifiants uniques. Generes automatiquement si absents.

        Raises
        ------
        ValueError
            Si les longueurs des listes ne correspondent pas.
        """
        if ids is None:
            ids = [uuid.uuid4().hex for _ in documents]
        if metadatas is None:
            metadatas = [{} for _ in documents]
        if len(documents) != len(ids) or len(documents) != len(metadatas):
            raise ValueError("documents, metadatas et ids doivent avoir la meme longueur")

        embeddings = self._embedding_fn(documents)

        with self._lock:
            id_set = set(self._ids)
            for doc_id, doc, meta, emb in zip(ids, documents, metadatas, embeddings):
                if doc_id in id_set:
                    # Mise a jour si l'ID existe deja
                    idx = self._ids.index(doc_id)
                    self._documents[idx] = doc
                    self._metadatas[idx] = meta
                    self._embeddings[idx] = emb
                else:
                    self._ids.append(doc_id)
                    self._documents.append(doc)
                    self._metadatas.append(meta)
                    self._embeddings.append(emb)

        logger.debug("Collection '%s' : %d documents ajoutes", self.name, len(documents))

    def query(
        self,
        query_texts: Optional[list[str]] = None,
        query_embeddings: Optional[list[list[float]]] = None,
        n_results: int = 10,
        where: Optional[dict[str, Any]] = None,
        where_document: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Rechercher les documents les plus similaires.

        Parameters
        ----------
        query_texts : list[str] | None
            Textes de requete (seront embeddes).
        query_embeddings : list[list[float]] | None
            Embeddings de requete pre-calcules.
        n_results : int
            Nombre maximal de resultats par requete.
        where : dict | None
            Filtre de metadonnees.
        where_document : dict | None
            Filtre de contenu textuel.

        Returns
        -------
        dict
            Dictionnaire avec les cles ``ids``, ``documents``, ``metadatas``,
            ``distances`` (listes de listes, une par requete).
        """
        if query_texts is not None:
            query_embeddings = self._embedding_fn(query_texts)
        if query_embeddings is None:
            raise ValueError("query_texts ou query_embeddings doit etre fourni")

        with self._lock:
            all_results: list[dict[str, Any]] = []
            for q_emb in query_embeddings:
                scored: list[tuple[int, float]] = []
                for i, emb in enumerate(self._embeddings):
                    # Filtrage metadata
                    if where and not _matches_where(self._metadatas[i], where):
                        continue
                    # Filtrage contenu
                    if where_document and not _matches_where_document(self._documents[i], where_document):
                        continue
                    sim = _cosine_similarity(q_emb, emb)
                    scored.append((i, sim))
                # Tri par similarite decroissante
                scored.sort(key=lambda x: x[1], reverse=True)
                top = scored[:n_results]
                all_results.append({
                    "ids": [self._ids[idx] for idx, _ in top],
                    "documents": [self._documents[idx] for idx, _ in top],
                    "metadatas": [self._metadatas[idx] for idx, _ in top],
                    "distances": [1.0 - sim for _, sim in top],
                })

        # Fusionner les resultats au format ChromaDB
        return {
            "ids": [r["ids"] for r in all_results],
            "documents": [r["documents"] for r in all_results],
            "metadatas": [r["metadatas"] for r in all_results],
            "distances": [r["distances"] for r in all_results],
        }

    def get(
        self,
        ids: Optional[list[str]] = None,
        where: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Recuperer des documents par ID ou par filtre de metadonnees.

        Parameters
        ----------
        ids : list[str] | None
            Identifiants a recuperer.
        where : dict | None
            Filtre de metadonnees.

        Returns
        -------
        dict
            Dictionnaire avec ``ids``, ``documents``, ``metadatas``.
        """
        with self._lock:
            result_ids: list[str] = []
            result_docs: list[str] = []
            result_metas: list[dict[str, Any]] = []

            for i, doc_id in enumerate(self._ids):
                if ids is not None and doc_id not in ids:
                    continue
                if where is not None and not _matches_where(self._metadatas[i], where):
                    continue
                result_ids.append(doc_id)
                result_docs.append(self._documents[i])
                result_metas.append(self._metadatas[i])

        return {"ids": result_ids, "documents": result_docs, "metadatas": result_metas}

    def delete(
        self,
        ids: Optional[list[str]] = None,
        where: Optional[dict[str, Any]] = None,
    ) -> None:
        """Supprimer des documents par ID ou par filtre de metadonnees.

        Parameters
        ----------
        ids : list[str] | None
            Identifiants a supprimer.
        where : dict | None
            Filtre de metadonnees pour la suppression.
        """
        with self._lock:
            keep_indices: list[int] = []
            for i, doc_id in enumerate(self._ids):
                should_delete = False
                if ids is not None and doc_id in ids:
                    should_delete = True
                if where is not None and _matches_where(self._metadatas[i], where):
                    should_delete = True
                if not should_delete:
                    keep_indices.append(i)

            self._ids = [self._ids[i] for i in keep_indices]
            self._documents = [self._documents[i] for i in keep_indices]
            self._metadatas = [self._metadatas[i] for i in keep_indices]
            self._embeddings = [self._embeddings[i] for i in keep_indices]

        logger.debug("Collection '%s' : %d documents restants", self.name, len(self._ids))

    def count(self) -> int:
        """Retourner le nombre de documents dans la collection.

        Returns
        -------
        int
            Nombre de documents.
        """
        return len(self._ids)

    # ------------------------------------------------------------------
    # Persistance
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialiser la collection en dictionnaire.

        Returns
        -------
        dict
            Representation serialisable.
        """
        return {
            "name": self.name,
            "metadata": self.metadata,
            "ids": self._ids,
            "documents": self._documents,
            "metadatas": self._metadatas,
            "embeddings": self._embeddings,
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        embedding_function: Optional[Callable[[list[str]], list[list[float]]]] = None,
    ) -> "MemoryCollection":
        """Deserialiser une collection a partir d'un dictionnaire.

        Parameters
        ----------
        data : dict
            Dictionnaire produit par :meth:`to_dict`.
        embedding_function : Callable | None
            Fonction d'embedding a utiliser.

        Returns
        -------
        MemoryCollection
            Instance restauree.
        """
        coll = cls(name=data["name"], embedding_function=embedding_function, metadata=data.get("metadata", {}))
        coll._ids = data.get("ids", [])
        coll._documents = data.get("documents", [])
        coll._metadatas = data.get("metadatas", [])
        coll._embeddings = data.get("embeddings", [])
        return coll


# ---------------------------------------------------------------------------
# ChromaCollectionWrapper (mode natif chromadb)
# ---------------------------------------------------------------------------

class ChromaCollectionWrapper:
    """Adaptateur autour d'une collection chromadb native.

    Delauee le stockage, l'embedding et la recherche a ``chromadb`` lorsque
    celui-ci est disponible.

    Attributes
    ----------
    name : str
        Nom de la collection.
    """

    def __init__(self, chroma_collection: Any) -> None:
        self._collection = chroma_collection
        self.name: str = chroma_collection.name
        self.metadata: dict[str, Any] = getattr(chroma_collection, "metadata", {}) or {}

    def add(
        self,
        documents: list[str],
        metadatas: Optional[list[dict[str, Any]]] = None,
        ids: Optional[list[str]] = None,
    ) -> None:
        """Ajouter des documents via chromadb."""
        if ids is None:
            ids = [uuid.uuid4().hex for _ in documents]
        self._collection.add(documents=documents, metadatas=metadatas, ids=ids)

    def query(
        self,
        query_texts: Optional[list[str]] = None,
        query_embeddings: Optional[list[list[float]]] = None,
        n_results: int = 10,
        where: Optional[dict[str, Any]] = None,
        where_document: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Rechercher via chromadb."""
        kwargs: dict[str, Any] = {"n_results": n_results}
        if query_texts is not None:
            kwargs["query_texts"] = query_texts
        if query_embeddings is not None:
            kwargs["query_embeddings"] = query_embeddings
        if where is not None:
            kwargs["where"] = where
        if where_document is not None:
            kwargs["where_document"] = where_document
        return self._collection.query(**kwargs)

    def get(
        self,
        ids: Optional[list[str]] = None,
        where: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Recuperer via chromadb."""
        kwargs: dict[str, Any] = {}
        if ids is not None:
            kwargs["ids"] = ids
        if where is not None:
            kwargs["where"] = where
        return self._collection.get(**kwargs)

    def delete(
        self,
        ids: Optional[list[str]] = None,
        where: Optional[dict[str, Any]] = None,
    ) -> None:
        """Supprimer via chromadb."""
        kwargs: dict[str, Any] = {}
        if ids is not None:
            kwargs["ids"] = ids
        if where is not None:
            kwargs["where"] = where
        self._collection.delete(**kwargs)

    def count(self) -> int:
        """Retourner le nombre de documents."""
        return self._collection.count()


# ---------------------------------------------------------------------------
# ChromaMemoryStore
# ---------------------------------------------------------------------------

class ChromaMemoryStore:
    """Magasin de memoire vectoriel manageant plusieurs collections.

    Supporte deux modes de fonctionnement :

    - **Mode embarque** (par defaut) : in-process, zero configuration,
      utilise soit chromadb soit le fallback numpy.
    - **Mode client-serveur** : se connecte a un serveur ChromaDB distant.

    Attributes
    ----------
    mode : str
        Mode de fonctionnement (``"embedded"`` ou ``"client_server"``).
    """

    def __init__(
        self,
        path: Optional[str] = None,
        host: Optional[str] = None,
        port: int = 8000,
    ) -> None:
        """Initialiser le magasin de memoire.

        Parameters
        ----------
        path : str | None
            Chemin de persistance pour le mode embarque.
        host : str | None
            Hote du serveur ChromaDB (mode client-serveur).
        port : int
            Port du serveur ChromaDB.
        """
        self._collections: dict[str, MemoryCollection | ChromaCollectionWrapper] = {}
        self._path: Optional[str] = path
        self._lock = threading.Lock()

        if host is not None:
            self.mode: str = "client_server"
            self._host = host
            self._port = port
            if _CHROMADB_AVAILABLE:
                self._client = chromadb.HttpClient(host=host, port=port)
                logger.info("ChromaMemoryStore en mode client-serveur (%s:%d)", host, port)
            else:
                raise ImportError("chromadb est requis pour le mode client-serveur")
        else:
            self.mode = "embedded"
            if _CHROMADB_AVAILABLE:
                settings: dict[str, Any] = {}
                if path:
                    settings["path"] = path
                self._client = chromadb.Client(
                    chromadb.Settings(
                        chroma_db_impl="duckdb+parquet",
                        persist_directory=path or "",
                        anonymized_telemetry=False,
                    ) if path else chromadb.Settings(anonymized_telemetry=False)
                )
                logger.info("ChromaMemoryStore en mode embarque (chromadb natif)")
            else:
                self._client = None
                logger.info("ChromaMemoryStore en mode embarque (fallback numpy/hash)")

        # Charger les collections persistees en mode fallback
        if self.mode == "embedded" and self._client is None and path:
            self._load_fallback(path)

    # ------------------------------------------------------------------
    # Gestion des collections
    # ------------------------------------------------------------------

    def get_or_create_collection(
        self,
        name: str,
        embedding_function: Optional[Callable[[list[str]], list[list[float]]]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> MemoryCollection | ChromaCollectionWrapper:
        """Obtenir ou creer une collection nommee.

        Parameters
        ----------
        name : str
            Nom de la collection (par domaine de connaissance).
        embedding_function : Callable | None
            Fonction d'embedding personnalisee.
        metadata : dict | None
            Metadonnees de la collection.

        Returns
        -------
        MemoryCollection | ChromaCollectionWrapper
            La collection obtenue ou creee.
        """
        with self._lock:
            if name in self._collections:
                return self._collections[name]

            if self._client is not None:
                chroma_coll = self._client.get_or_create_collection(
                    name=name,
                    embedding_function=embedding_function,
                    metadata=metadata,
                )
                coll: MemoryCollection | ChromaCollectionWrapper = ChromaCollectionWrapper(chroma_coll)
            else:
                coll = MemoryCollection(
                    name=name,
                    embedding_function=embedding_function,
                    metadata=metadata,
                )

            self._collections[name] = coll
            logger.debug("Collection '%s' creee (mode=%s)", name, self.mode)
            return coll

    def list_collections(self) -> list[str]:
        """Lister les noms de toutes les collections.

        Returns
        -------
        list[str]
            Noms des collections.
        """
        with self._lock:
            if self._client is not None:
                return [c.name for c in self._client.list_collections()]
            return list(self._collections.keys())

    def delete_collection(self, name: str) -> None:
        """Supprimer une collection par son nom.

        Parameters
        ----------
        name : str
            Nom de la collection a supprimer.
        """
        with self._lock:
            if self._client is not None:
                self._client.delete_collection(name)
            self._collections.pop(name, None)
            logger.debug("Collection '%s' supprimee", name)

    # ------------------------------------------------------------------
    # Persistance (mode fallback)
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Sauvegarder toutes les collections sur disque (mode fallback uniquement).

        Les donnees sont ecrites au format JSON dans le repertoire de
        persistance configure.
        """
        if self._path is None:
            logger.warning("Aucun chemin de persistance configure, sauvegarde ignoree")
            return
        if self._client is not None:
            # chromadb gere sa propre persistance
            if hasattr(self._client, "persist"):
                self._client.persist()  # type: ignore[attr-defined]
            return

        os.makedirs(self._path, exist_ok=True)
        data: dict[str, Any] = {}
        for name, coll in self._collections.items():
            if isinstance(coll, MemoryCollection):
                data[name] = coll.to_dict()

        save_path = os.path.join(self._path, "chroma_store.json")
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.debug("Magasin sauvegarde dans %s", save_path)

    def _load_fallback(self, path: str) -> None:
        """Charger les collections depuis le disque (mode fallback).

        Parameters
        ----------
        path : str
            Chemin du repertoire de persistance.
        """
        save_path = os.path.join(path, "chroma_store.json")
        if not os.path.exists(save_path):
            return
        try:
            with open(save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for name, coll_data in data.items():
                coll = MemoryCollection.from_dict(coll_data)
                self._collections[name] = coll
            logger.info("Charge %d collections depuis %s", len(data), save_path)
        except (json.JSONDecodeError, IOError, OSError) as exc:
            logger.error("Erreur lors du chargement du magasin : %s", exc)

    # ------------------------------------------------------------------
    # Domaines de connaissance
    # ------------------------------------------------------------------

    def collection_for_domain(self, domain: str) -> MemoryCollection | ChromaCollectionWrapper:
        """Obtenir la collection associee a un domaine de connaissance.

        Chaque domaine de competence de l'agent (par ex. ``"web_search"``,
        ``"file_ops"``, ``"stock_analysis"``) dispose de sa propre collection.

        Parameters
        ----------
        domain : str
            Nom du domaine.

        Returns
        -------
        MemoryCollection | ChromaCollectionWrapper
            Collection du domaine.
        """
        return self.get_or_create_collection(f"domain_{domain}")


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------

__all__ = [
    "ChromaMemoryStore",
    "ChromaCollectionWrapper",
    "MemoryCollection",
    "_matches_where",
    "_matches_where_document",
    "_cosine_similarity",
    "_simple_hash_embed",
]
