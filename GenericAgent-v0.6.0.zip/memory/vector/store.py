"""memory/vector/store.py — Lightweight vector store with cosine similarity.

Provides a simple but effective vector store that works without external
dependencies.  For larger deployments, this can be replaced with ChromaDB,
FAISS, or Qdrant while keeping the same interface.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("memory.vector.store")


# ══════════════════════════════════════════════════════════════════════════════
#  Document
# ══════════════════════════════════════════════════════════════════════════════


@dataclass
class Document:
    """A single document in the vector store.

    Attributes
    ----------
    id : str
        Unique identifier.
    text : str
        The document text content.
    vector : list[float]
        Embedding vector.
    metadata : dict
        Additional metadata (source, timestamp, category, etc.).
    """

    id: str
    text: str
    vector: list[float] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize to a JSON-compatible dict."""
        return {
            "id": self.id,
            "text": self.text,
            "vector": self.vector,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict) -> Document:
        """Deserialize from a dict."""
        return cls(
            id=d["id"],
            text=d["text"],
            vector=d.get("vector", []),
            metadata=d.get("metadata", {}),
        )


# ══════════════════════════════════════════════════════════════════════════════
#  Similarity functions
# ══════════════════════════════════════════════════════════════════════════════


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors.

    Returns 0.0 if either vector is zero-length or if the dot product
    is negative (indicating opposite directions).
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


# ══════════════════════════════════════════════════════════════════════════════
#  VectorStore
# ══════════════════════════════════════════════════════════════════════════════


class VectorStore:
    """In-memory vector store with JSON persistence.

    Supports:
    * Adding documents with pre-computed embeddings
    * Similarity search (top-k with optional metadata filter)
    * Persistence to JSON file
    * Deletion by ID or metadata filter
    * Document count and statistics

    The store is thread-safe via a simple lock.
    """

    def __init__(self, store_path: Optional[str] = None) -> None:
        """Initialize the vector store.

        Parameters
        ----------
        store_path : str | None
            Path to the JSON file for persistence.  If ``None``, the
            store operates in-memory only.
        """
        self._documents: Dict[str, Document] = {}
        self._lock = threading.Lock()
        self._store_path = store_path

        if store_path and os.path.isfile(store_path):
            self.load(store_path)

    # ── CRUD ──────────────────────────────────────────────────────────────

    def add(self, doc: Document) -> None:
        """Add a document to the store.

        If a document with the same ID exists, it is replaced.
        """
        with self._lock:
            self._documents[doc.id] = doc

    def add_many(self, docs: list[Document]) -> None:
        """Add multiple documents at once."""
        with self._lock:
            for doc in docs:
                self._documents[doc.id] = doc

    def get(self, doc_id: str) -> Optional[Document]:
        """Look up a document by ID."""
        with self._lock:
            return self._documents.get(doc_id)

    def delete(self, doc_id: str) -> bool:
        """Delete a document by ID.

        Returns ``True`` if the document existed and was deleted.
        """
        with self._lock:
            return self._documents.pop(doc_id, None) is not None

    def delete_by_metadata(self, key: str, value: Any) -> int:
        """Delete all documents where ``metadata[key] == value``.

        Returns the number of documents deleted.
        """
        with self._lock:
            to_delete = [
                did for did, doc in self._documents.items()
                if doc.metadata.get(key) == value
            ]
            for did in to_delete:
                del self._documents[did]
        return len(to_delete)

    # ── Search ────────────────────────────────────────────────────────────

    def search(
        self,
        query_vector: list[float],
        top_k: int = 5,
        min_similarity: float = 0.0,
        metadata_filter: Optional[dict] = None,
    ) -> list[Tuple[Document, float]]:
        """Search for documents similar to the query vector.

        Parameters
        ----------
        query_vector : list[float]
            The embedding vector to compare against.
        top_k : int
            Maximum number of results to return.
        min_similarity : float
            Minimum cosine similarity threshold (0.0 to 1.0).
        metadata_filter : dict | None
            If provided, only return documents whose metadata contains
            all the specified key-value pairs.

        Returns
        -------
        list[tuple[Document, float]]
            List of (document, similarity_score) tuples, sorted by
            descending similarity.
        """
        with self._lock:
            candidates = []
            for doc in self._documents.values():
                # Apply metadata filter
                if metadata_filter:
                    match = all(
                        doc.metadata.get(k) == v
                        for k, v in metadata_filter.items()
                    )
                    if not match:
                        continue

                if not doc.vector:
                    continue

                sim = cosine_similarity(query_vector, doc.vector)
                if sim >= min_similarity:
                    candidates.append((doc, sim))

        # Sort by similarity (descending)
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:top_k]

    def search_by_text(
        self,
        query: str,
        embed_fn: Any,
        top_k: int = 5,
        min_similarity: float = 0.3,
        metadata_filter: Optional[dict] = None,
    ) -> list[Tuple[Document, float]]:
        """Search by text query (computes embedding on the fly).

        Parameters
        ----------
        query : str
            The search text.
        embed_fn : Callable
            Function that takes a string and returns an embedding vector.
        top_k : int
            Maximum results.
        min_similarity : float
            Minimum similarity threshold.
        metadata_filter : dict | None
            Optional metadata filter.

        Returns
        -------
        list[tuple[Document, float]]
            Search results.
        """
        query_vector = embed_fn(query)
        return self.search(query_vector, top_k, min_similarity, metadata_filter)

    # ── Persistence ───────────────────────────────────────────────────────

    def save(self, path: Optional[str] = None) -> None:
        """Save the store to a JSON file.

        Parameters
        ----------
        path : str | None
            File path.  Defaults to ``self._store_path``.
        """
        save_path = path or self._store_path
        if not save_path:
            raise ValueError("No save path specified")

        with self._lock:
            data = {
                "version": "1.0",
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "documents": [doc.to_dict() for doc in self._documents.values()],
            }

        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        logger.debug("Saved %d documents to %s", len(self._documents), save_path)

    def load(self, path: Optional[str] = None) -> int:
        """Load documents from a JSON file.

        Parameters
        ----------
        path : str | None
            File path.  Defaults to ``self._store_path``.

        Returns
        -------
        int
            Number of documents loaded.
        """
        load_path = path or self._store_path
        if not load_path or not os.path.isfile(load_path):
            return 0

        try:
            with open(load_path, "r", encoding="utf-8") as f:
                raw = f.read()
            if not raw.strip():
                return 0
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Corrupt store file: %s — starting fresh", load_path)
            return 0

        docs = data.get("documents", [])
        with self._lock:
            for doc_data in docs:
                doc = Document.from_dict(doc_data)
                self._documents[doc.id] = doc

        logger.debug("Loaded %d documents from %s", len(docs), load_path)
        return len(docs)

    # ── Stats ─────────────────────────────────────────────────────────────

    @property
    def count(self) -> int:
        """Number of documents in the store."""
        with self._lock:
            return len(self._documents)

    def stats(self) -> dict[str, Any]:
        """Return statistics about the store."""
        with self._lock:
            total = len(self._documents)
            with_vectors = sum(1 for d in self._documents.values() if d.vector)
            categories = {}
            for doc in self._documents.values():
                cat = doc.metadata.get("category", "uncategorized")
                categories[cat] = categories.get(cat, 0) + 1

        return {
            "total_documents": total,
            "with_vectors": with_vectors,
            "without_vectors": total - with_vectors,
            "categories": categories,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  EmbeddingEngine
# ══════════════════════════════════════════════════════════════════════════════


class EmbeddingEngine:
    """Compute text embeddings using LLM API endpoints.

    Supports OpenAI-compatible embedding endpoints and falls back to
    a simple TF-IDF-based embedding when no API is available.

    The engine caches recent embeddings to avoid redundant API calls.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        model: str = "text-embedding-3-small",
        cache_size: int = 500,
    ) -> None:
        self.api_key = api_key
        self.api_base = api_base or "https://api.openai.com/v1"
        self.model = model
        self._cache: Dict[str, list[float]] = {}
        self._cache_size = cache_size

    def embed(self, text: str) -> list[float]:
        """Compute the embedding for a text string.

        Tries the API first; falls back to sentence-transformers
        (if installed); finally falls back to a TF-IDF-inspired embedding
        if no model is available.

        Parameters
        ----------
        text : str
            Text to embed.

        Returns
        -------
        list[float]
            The embedding vector.
        """
        # Check cache — use full hash to avoid collisions
        cache_key = hashlib.sha256(text.encode()).hexdigest()[:32]
        if cache_key in self._cache:
            return self._cache[cache_key]

        # Try API
        vector = self._embed_api(text)

        # Fallback to sentence-transformers (local, no API needed)
        if not vector:
            vector = self._embed_sentence_transformers(text)

        # Final fallback to simple embedding
        if not vector:
            vector = self._embed_simple(text)

        # Update cache
        if len(self._cache) >= self._cache_size:
            # Remove oldest entry
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
        self._cache[cache_key] = vector

        return vector

    def _embed_api(self, text: str) -> list[float]:
        """Compute embedding via API call."""
        if not self.api_key:
            return []

        try:
            import requests

            response = requests.post(
                f"{self.api_base}/embeddings",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "input": text[:8000],  # Truncate very long texts
                },
                timeout=10,
            )

            if response.status_code == 200:
                data = response.json()
                return data["data"][0]["embedding"]

        except Exception as exc:
            logger.debug("Embedding API call failed: %s", exc)

        return []

    def _embed_sentence_transformers(self, text: str) -> list[float]:
        """Compute embedding using sentence-transformers (local, offline).

        This is the best offline fallback — it provides true semantic
        similarity without requiring an API key.  The model is loaded
        lazily on first use and cached for subsequent calls.

        Requires ``sentence-transformers`` to be installed::
        
            pip install sentence-transformers
        """
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            return []

        try:
            # Use a lightweight model by default
            model_name = "all-MiniLM-L6-v2"
            if not hasattr(self, "_st_model"):
                self._st_model = SentenceTransformer(model_name)
            embedding = self._st_model.encode(text[:8000], show_progress_bar=False)
            return embedding.tolist()
        except Exception as exc:
            logger.debug("sentence-transformers embedding failed: %s", exc)
            return []

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        """Compute embeddings for multiple texts."""
        return [self.embed(text) for text in texts]

    @staticmethod
    def _embed_simple(text: str) -> list[float]:
        """SimHash + n-gram TF embedding for offline fallback.

        This produces a deterministic 128-dimensional vector from the
        text using a **SimHash-inspired** approach that preserves
        sub-word semantic similarity.  Unlike the previous MD5-based
        approach which assigned random-looking vectors per word, this
        uses character n-gram frequency counting so that:

        - Words sharing common n-grams (e.g. "running", "runner",
          "runs") get **similar** vector contributions.
        - Documents with overlapping vocabulary get similar vectors.
        - The position-weighting reflects information architecture.

        The embedding strategy is:

        1. **Character n-gram bag** — extract 3-grams and 4-grams from
           each word; each unique n-gram hashes to a deterministic
           128-dim direction.  Since "run" appears in "running",
           "runner", and "runs", all these words contribute the same
           directional signal.
        2. **TF-IDF weighting** — n-grams that appear more often in the
           text get higher weight (TF component).  A simple inverse
           frequency dampening prevents very common n-grams (like "the")
           from dominating.
        3. **Whole-word SimHash** — each whole word also contributes a
           SimHash-based component for exact-match similarity.
        """
        import hashlib
        from collections import Counter

        dim = 128
        vector = [0.0] * dim
        text_lower = text.lower()
        words = text_lower.split()

        if not words:
            return vector

        # ── Step 1: Build n-gram frequency table ──────────────────────
        ngram_freq: Counter[str] = Counter()
        word_ngrams: dict[str, list[str]] = {}

        for word in words:
            # Pad word to capture boundary n-grams
            padded = f"_{word}_"
            ngrams = []
            for n in (3, 4):
                for i in range(len(padded) - n + 1):
                    ng = padded[i:i + n]
                    ngrams.append(ng)
                    ngram_freq[ng] += 1
            word_ngrams[word] = ngrams

        # ── Step 2: N-gram TF-IDF-inspired weighted embedding ────────
        total_ngrams = sum(ngram_freq.values())
        total_words = len(words)

        for pos, word in enumerate(words):
            # Position weight: earlier words get slightly higher weight
            pos_weight = 1.0 + 0.3 * (1.0 - pos / total_words)

            for ng in word_ngrams.get(word, []):
                # TF: how often this n-gram appears in the text
                tf = ngram_freq[ng] / total_ngrams
                # IDF-inspired: dampen very common n-grams
                idf = 1.0 / (1.0 + ngram_freq[ng] * 0.1)
                weight = tf * idf * pos_weight * 2.0

                # Hash the n-gram to a deterministic 128-dim direction
                h = int(hashlib.sha256(ng.encode()).hexdigest(), 16)
                for i in range(dim):
                    seed = (h + i * 2654435761) & 0xFFFFFFFF
                    # Sign function: +1 or -1 based on bit
                    sign = 1.0 if (seed >> 16) & 1 else -1.0
                    vector[i] += sign * weight * 0.1

        # ── Step 3: Whole-word SimHash component ─────────────────────
        for pos, word in enumerate(words):
            pos_weight = 1.0 + 0.2 * (1.0 - pos / total_words)
            # SimHash: hash word and use bits to vote +1/-1 per dimension
            h = int(hashlib.sha256(word.encode()).hexdigest(), 16)
            for i in range(dim):
                bit = (h >> (i % 64)) & 1
                vector[i] += (1.0 if bit else -1.0) * pos_weight * 0.05

        # ── Normalize ─────────────────────────────────────────────────
        norm = math.sqrt(sum(v * v for v in vector))
        if norm > 0:
            vector = [v / norm for v in vector]

        return vector
