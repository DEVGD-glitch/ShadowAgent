"""memory/vector — Vector store and RAG system for GenericAgent.

Provides embedding-based semantic search over the agent's memory, past
conversations, and documents.  Enables the agent to retrieve relevant
context far more effectively than the current file-based SOP system.

Key Components
--------------
- :class:`VectorStore` — Lightweight vector store with cosine similarity
- :class:`EmbeddingEngine` — Compute embeddings via LLM API
- :class:`RAGEngine` — Retrieval-Augmented Generation pipeline
- :class:`MemoryIndexer` — Index and manage memory documents

Storage
-------
Uses a simple JSON-based persistence format.  Each entry stores:
- ``id`` — unique identifier
- ``text`` — the document text
- ``vector`` — embedding vector (list of floats)
- ``metadata`` — source, timestamp, category, etc.

For production use with larger corpora, swap the JSON backend for
ChromaDB, Qdrant, or FAISS — the interface remains the same.
"""

from __future__ import annotations

from memory.vector.store import VectorStore, EmbeddingEngine
from memory.vector.rag import RAGEngine, MemoryIndexer

__all__ = [
    "VectorStore",
    "EmbeddingEngine",
    "RAGEngine",
    "MemoryIndexer",
]
