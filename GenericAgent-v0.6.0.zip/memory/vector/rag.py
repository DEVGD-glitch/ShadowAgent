"""memory/vector/rag.py — Retrieval-Augmented Generation pipeline.

Provides the :class:`RAGEngine` that integrates vector search with the
agent's memory system, and :class:`MemoryIndexer` for indexing existing
memory files, SOPs, and conversation history.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from memory.vector.store import Document, VectorStore, EmbeddingEngine

logger = logging.getLogger("memory.vector.rag")


# ══════════════════════════════════════════════════════════════════════════════
#  Text chunking utilities
# ══════════════════════════════════════════════════════════════════════════════


def chunk_text(
    text: str,
    chunk_size: int = 500,
    overlap: int = 100,
    separator: str = "\n",
) -> list[str]:
    """Split text into overlapping chunks.

    Parameters
    ----------
    text : str
        The text to chunk.
    chunk_size : int
        Target number of characters per chunk.
    overlap : int
        Number of characters to overlap between chunks.
    separator : str
        Preferred split point.

    Returns
    -------
    list[str]
        List of text chunks.
    """
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size

        # Try to split at separator boundary
        if end < len(text):
            sep_pos = text.rfind(separator, start + chunk_size // 2, end)
            if sep_pos > start:
                end = sep_pos + len(separator)

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        start = end - overlap
        if start <= 0 and end >= len(text):
            break

    return chunks


# ══════════════════════════════════════════════════════════════════════════════
#  RAGEngine
# ══════════════════════════════════════════════════════════════════════════════


class RAGEngine:
    """Retrieval-Augmented Generation engine for GenericAgent.

    The RAG engine combines a vector store with an embedding engine to
    provide semantic search over the agent's accumulated knowledge.  It
    integrates with the agent's memory system to:

    * Retrieve relevant context before each LLM call
    * Index new information as it's learned
    * Search across SOPs, conversation history, and documents
    * Provide source attribution for retrieved context

    Usage
    -----
    ::

        engine = RAGEngine(store_path="memory/vector_store.json")

        # Index a document
        engine.index_text("Important info about the project", category="docs")

        # Search
        results = engine.search("project architecture", top_k=3)
        for doc, score in results:
            print(f"[{score:.2f}] {doc.text[:100]}")

        # Build RAG context for LLM prompt
        context = engine.build_context("How do I configure the agent?")
    """

    def __init__(
        self,
        store_path: Optional[str] = None,
        embedding_engine: Optional[EmbeddingEngine] = None,
        chunk_size: int = 500,
        chunk_overlap: int = 100,
    ) -> None:
        self.store = VectorStore(store_path=store_path)
        self.embedder = embedding_engine or EmbeddingEngine()
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    # ── Indexing ──────────────────────────────────────────────────────────

    def index_text(
        self,
        text: str,
        source: str = "",
        category: str = "general",
        metadata: Optional[dict] = None,
    ) -> int:
        """Index a text document by chunking and embedding it.

        Parameters
        ----------
        text : str
            The text to index.
        source : str
            Source identifier (e.g. file path).
        category : str
            Category for filtering (``"sop"``, ``"conversation"``, ``"doc"``).
        metadata : dict | None
            Additional metadata.

        Returns
        -------
        int
            Number of chunks indexed.
        """
        chunks = chunk_text(text, self.chunk_size, self.chunk_overlap)
        docs = []

        for i, chunk in enumerate(chunks):
            doc_id = hashlib.md5(f"{source}:{i}:{chunk[:50]}".encode()).hexdigest()[:16]
            vector = self.embedder.embed(chunk)
            meta = {
                "source": source,
                "category": category,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "indexed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            }
            if metadata:
                meta.update(metadata)

            doc = Document(id=doc_id, text=chunk, vector=vector, metadata=meta)
            docs.append(doc)

        self.store.add_many(docs)
        logger.debug("Indexed %d chunks from %s", len(chunks), source or "inline text")
        return len(chunks)

    def index_file(self, file_path: str, category: str = "doc") -> int:
        """Index a file by reading and chunking it.

        Parameters
        ----------
        file_path : str
            Path to the file.
        category : str
            Category for the indexed chunks.

        Returns
        -------
        int
            Number of chunks indexed.
        """
        if not os.path.isfile(file_path):
            logger.warning("File not found for indexing: %s", file_path)
            return 0

        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError as exc:
            logger.error("Failed to read file %s: %s", file_path, exc)
            return 0

        return self.index_text(
            text,
            source=os.path.basename(file_path),
            category=category,
            metadata={"file_path": file_path},
        )

    # ── Retrieval ─────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 5,
        min_similarity: float = 0.3,
        category: Optional[str] = None,
    ) -> list[Tuple[Document, float]]:
        """Search for relevant documents.

        Parameters
        ----------
        query : str
            The search query.
        top_k : int
            Maximum number of results.
        min_similarity : float
            Minimum similarity threshold.
        category : str | None
            If set, only return documents from this category.

        Returns
        -------
        list[tuple[Document, float]]
            Search results with similarity scores.
        """
        query_vector = self.embedder.embed(query)
        metadata_filter = {"category": category} if category else None
        return self.store.search(query_vector, top_k, min_similarity, metadata_filter)

    def build_context(
        self,
        query: str,
        top_k: int = 3,
        min_similarity: float = 0.3,
        max_chars: int = 3000,
        category: Optional[str] = None,
    ) -> str:
        """Build a RAG context string for injection into the LLM prompt.

        Parameters
        ----------
        query : str
            The user's query or task.
        top_k : int
            Number of relevant documents to retrieve.
        min_similarity : float
            Minimum similarity threshold.
        max_chars : int
            Maximum characters for the context string.
        category : str | None
            Optional category filter.

        Returns
        -------
        str
            Formatted context string ready for prompt injection.
        """
        results = self.search(query, top_k, min_similarity, category)

        if not results:
            return ""

        context_parts = []
        total_chars = 0

        for doc, score in results:
            source = doc.metadata.get("source", "unknown")
            entry = f"[{source}] (relevance: {score:.1%})\n{doc.text}\n"
            if total_chars + len(entry) > max_chars:
                break
            context_parts.append(entry)
            total_chars += len(entry)

        if not context_parts:
            return ""

        header = "[Retrieved Context — RAG]\n"
        return header + "\n---\n".join(context_parts) + "\n[/End Retrieved Context]\n"

    # ── Persistence ───────────────────────────────────────────────────────

    def save(self) -> None:
        """Persist the vector store to disk."""
        self.store.save()

    def load(self) -> int:
        """Load the vector store from disk.

        Returns
        -------
        int
            Number of documents loaded.
        """
        return self.store.load()


# ══════════════════════════════════════════════════════════════════════════════
#  MemoryIndexer — indexes existing GenericAgent memory files
# ══════════════════════════════════════════════════════════════════════════════


class MemoryIndexer:
    """Indexes GenericAgent's existing memory files into the vector store.

    Scans the ``memory/`` directory for SOPs, conversation logs, and
    other text files, then indexes them for semantic search.

    Usage
    -----
    ::

        from memory.vector.rag import MemoryIndexer

        indexer = MemoryIndexer(rag_engine)
        count = indexer.index_all()
        rag_engine.save()
    """

    # File patterns and their categories
    PATTERNS = {
        r".*_sop\.md$": "sop",
        r".*_sop/.*\.md$": "sop",
        r"global_mem.*\.txt$": "global_memory",
        r"L4_raw_sessions/.*$": "conversation",
        r".*\.py$": "code",
    }

    def __init__(self, rag_engine: RAGEngine, memory_dir: Optional[str] = None) -> None:
        self.rag = rag_engine
        self.memory_dir = memory_dir

    def _classify_file(self, rel_path: str) -> str:
        """Determine the category for a file based on its path."""
        for pattern, category in self.PATTERNS.items():
            if re.search(pattern, rel_path):
                return category
        return "general"

    def index_all(self) -> int:
        """Index all memory files.

        Returns
        -------
        int
            Total number of files indexed.
        """
        if not self.memory_dir or not os.path.isdir(self.memory_dir):
            logger.warning("Memory directory not found: %s", self.memory_dir)
            return 0

        total = 0
        for root, dirs, files in os.walk(self.memory_dir):
            # Skip vector store data
            if "vector" in root:
                continue

            for fname in files:
                fpath = os.path.join(root, fname)
                if not fname.endswith((".md", ".txt", ".py")):
                    continue

                # Skip large binary-like files
                try:
                    size = os.path.getsize(fpath)
                    if size > 500_000:  # 500KB limit
                        continue
                except OSError:
                    continue

                rel_path = os.path.relpath(fpath, self.memory_dir)
                category = self._classify_file(rel_path)
                count = self.rag.index_file(fpath, category=category)
                if count > 0:
                    total += 1

        logger.info("Indexed %d memory files", total)
        return total

    def index_file(self, file_path: str) -> int:
        """Index a single file.

        Returns
        -------
        int
            Number of chunks indexed.
        """
        if self.memory_dir:
            rel_path = os.path.relpath(file_path, self.memory_dir)
            category = self._classify_file(rel_path)
        else:
            category = "general"

        return self.rag.index_file(file_path, category=category)
