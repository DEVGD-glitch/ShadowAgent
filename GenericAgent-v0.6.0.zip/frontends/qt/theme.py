"""
Thème visuel de l'interface Qt — palette de couleurs, styles de barre de défilement et CSS Markdown.
Extrait de qtapp.py pour la refonte modulaire.

Phase 7 : Ajout du support multi-thèmes (dark, light, catppuccin).
"""

# Import conditionnel — les styles CSS restent utilisables sans PySide6
try:
    from PySide6.QtGui import QColor
    HAS_PYSIDE6 = True
except ImportError:
    HAS_PYSIDE6 = False
    # Fallback : utiliser un tuple RGBA au lieu de QColor pour les tests
    def _FakeColor(*args):
        return args

# ══════════════════════════════════════════════════════════════════════════════
# Multi-theme support
# ══════════════════════════════════════════════════════════════════════════════

def _qc(r: int, g: int, b: int, a: int = 255):
    """Create a QColor or tuple depending on PySide6 availability."""
    if HAS_PYSIDE6:
        return QColor(r, g, b, a)
    return (r, g, b, a)

THEMES = {
    "dark": {
        "bg":       _qc(14, 14, 18),
        "panel":    _qc(20, 20, 24, 248),
        "border":   _qc(45, 45, 50),
        "accent":   "#7c3aed",
        "text":     "#e4e4e7",
        "muted":    "#71717a",
        "user_g0":  _qc(79, 70, 229),
        "user_g1":  _qc(124, 58, 237),
        "asst_bg":  _qc(39, 39, 42, 210),
        "asst_bdr": _qc(63, 63, 70),
        "send_g0":  _qc(220, 38, 38),
        "send_g1":  _qc(239, 68, 68),
        "green":    "#22c55e",
    },
    "light": {
        "bg":       _qc(255, 255, 255),
        "panel":    _qc(245, 245, 245, 248),
        "border":   _qc(209, 213, 219),
        "accent":   "#7c3aed",
        "text":     "#18181b",
        "muted":    "#6b7280",
        "user_g0":  _qc(79, 70, 229),
        "user_g1":  _qc(124, 58, 237),
        "asst_bg":  _qc(243, 244, 246, 210),
        "asst_bdr": _qc(209, 213, 219),
        "send_g0":  _qc(220, 38, 38),
        "send_g1":  _qc(239, 68, 68),
        "green":    "#16a34a",
    },
    "catppuccin": {
        "bg":       _qc(30, 30, 46),
        "panel":    _qc(24, 24, 37, 248),
        "border":   _qc(49, 50, 68),
        "accent":   "#cba6f7",
        "text":     "#cdd6f4",
        "muted":    "#6c7086",
        "user_g0":  _qc(137, 180, 250),
        "user_g1":  _qc(203, 166, 247),
        "asst_bg":  _qc(49, 50, 68, 210),
        "asst_bdr": _qc(69, 71, 90),
        "send_g0":  _qc(243, 139, 168),
        "send_g1":  _qc(250, 179, 135),
        "green":    "#a6e3a1",
    },
}

# Current active theme name
_current_theme_name: str = "dark"

# ══════════════════════════════════════════════════════════════════════════════
# Backward-compatible palette C (always reflects the current theme)
# ══════════════════════════════════════════════════════════════════════════════

C = dict(THEMES["dark"])


def get_theme(name: str = "dark") -> dict:
    """Return theme color dict by name.

    Parameters
    ----------
    name : str
        Theme name: 'dark', 'light', or 'catppuccin'.

    Returns
    -------
    dict
        Theme color dictionary.

    Raises
    ------
    KeyError
        If the theme name is not found.
    """
    if name not in THEMES:
        raise KeyError(f"Thème inconnu : {name!r}. Thèmes disponibles : {list(THEMES.keys())}")
    return dict(THEMES[name])


def apply_theme(app, theme_name: str) -> None:
    """Apply a theme to the entire application.

    Updates the global C dict and applies the base stylesheet.

    Parameters
    ----------
    app : QApplication
        The Qt application instance.
    theme_name : str
        Theme name: 'dark', 'light', or 'catppuccin'.
    """
    global _current_theme_name, C

    if theme_name not in THEMES:
        return

    _current_theme_name = theme_name
    # Update global C in-place so all references see the new theme
    C.clear()
    C.update(THEMES[theme_name])


def current_theme_name() -> str:
    """Return the name of the currently active theme."""
    return _current_theme_name


# ══════════════════════════════════════════════════════════════════════════════
# Static CSS (theme-independent)
# ══════════════════════════════════════════════════════════════════════════════

SCROLLBAR_STYLE = """
QScrollBar:vertical { width: 5px; background: transparent; border: none; }
QScrollBar::handle:vertical {
    background: rgba(255,255,255,0.12); border-radius: 2px; min-height: 20px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
"""

_MD_CSS = """
body { color: #e4e4e7; font-family: "Arial", "Microsoft YaHei", sans-serif; font-size: 13px; line-height: 1.6; font-weight: 400; }
h1 { color: #f4f4f5; font-size: 20px; font-weight: 700; border-bottom: 1px solid #3f3f46; padding-bottom: 4px; margin-top: 16px; }
h2 { color: #f4f4f5; font-size: 17px; font-weight: 700; border-bottom: 1px solid #3f3f46; padding-bottom: 3px; margin-top: 14px; }
h3 { color: #f4f4f5; font-size: 15px; font-weight: 600; margin-top: 12px; }
h4,h5,h6 { color: #d4d4d8; font-size: 13px; font-weight: 600; margin-top: 10px; }
code { background: rgba(63,63,70,0.6); color: #c4b5fd; padding: 1px 4px; border-radius: 3px;
       font-family: Consolas, "Courier New", monospace; font-size: 12px; }
pre  { background: rgba(24,24,30,0.95); border: 1px solid #3f3f46; border-radius: 6px;
       padding: 10px 12px; margin: 8px 0; }
pre code { background: transparent; padding: 0; color: #d4d4d8; }
a { color: #818cf8; text-decoration: none; }
a:hover { text-decoration: underline; }
blockquote { border-left: 3px solid #7c3aed; margin: 8px 0 8px 0; padding: 4px 0 4px 12px; color: #a1a1aa; }
table { border-collapse: collapse; margin: 8px 0; }
th, td { border: 1px solid #3f3f46; padding: 5px 10px; }
th { background: rgba(63,63,70,0.35); color: #d4d4d8; font-weight: 700; }
hr { border: none; border-top: 1px solid #3f3f46; margin: 12px 0; }
ul, ol { padding-left: 22px; margin: 4px 0; }
li { margin: 2px 0; }
p { margin: 6px 0; }
"""
