"""
Icône de barre système avec notifications et menu contextuel.

Fonctionnalités :
- Notification de fin de tâche
- Notification d'approbation requise
- Menu contextuel : Ouvrir, Nouvelle conversation, Toggle autonome, Quitter
"""
from __future__ import annotations

from PySide6.QtWidgets import QSystemTrayIcon, QMenu
from PySide6.QtGui import QIcon, QAction
from PySide6.QtCore import QObject, Signal


class TrayManager(QObject):
    """System tray icon with notifications and context menu.

    Signals
    -------
    show_panel : Signal
        Emitted when the user clicks "Ouvrir" or double-clicks the tray icon.
    new_conversation : Signal
        Emitted when the user clicks "Nouvelle conversation".
    toggle_autonomous : Signal
        Emitted when the user clicks "Toggle mode autonome".
    quit_app : Signal
        Emitted when the user clicks "Quitter".
    """

    show_panel = Signal()
    new_conversation = Signal()
    toggle_autonomous = Signal()
    quit_app = Signal()

    def __init__(self, app_icon: QIcon | None = None, parent=None):
        super().__init__(parent)
        self._icon = app_icon
        self._tray = QSystemTrayIcon()
        if app_icon and not app_icon.isNull():
            self._tray.setIcon(app_icon)
        self._tray.setToolTip("GenericAgent")

        self._build_menu()
        self._tray.activated.connect(self._on_activated)

    def _build_menu(self):
        """Build the context menu for the tray icon."""
        menu = QMenu()
        menu.setStyleSheet("""
            QMenu {
                background: #14141a;
                color: #e4e4e7;
                border: 1px solid #2d2d32;
                padding: 4px 0;
            }
            QMenu::item {
                padding: 6px 20px 6px 12px;
                font-size: 12px;
            }
            QMenu::item:selected {
                background: rgba(63,63,70,0.6);
            }
            QMenu::separator {
                height: 1px;
                background: #2d2d32;
                margin: 4px 8px;
            }
        """)

        open_action = QAction("Ouvrir", self)
        open_action.triggered.connect(self.show_panel.emit)
        menu.addAction(open_action)

        new_conv_action = QAction("Nouvelle conversation", self)
        new_conv_action.triggered.connect(self.new_conversation.emit)
        menu.addAction(new_conv_action)

        menu.addSeparator()

        toggle_auto_action = QAction("Toggle mode autonome", self)
        toggle_auto_action.triggered.connect(self.toggle_autonomous.emit)
        menu.addAction(toggle_auto_action)

        menu.addSeparator()

        quit_action = QAction("Quitter", self)
        quit_action.triggered.connect(self.quit_app.emit)
        menu.addAction(quit_action)

        self._tray.setContextMenu(menu)

    def _on_activated(self, reason):
        """Handle tray icon activation (double-click, etc.)."""
        if reason == QSystemTrayIcon.DoubleClick:
            self.show_panel.emit()

    def show(self):
        """Show the tray icon."""
        self._tray.show()

    def hide(self):
        """Hide the tray icon."""
        self._tray.hide()

    def notify_task_complete(self, title: str = "Tâche terminée",
                             message: str = "L'agent a terminé sa tâche."):
        """Show a task completion notification.

        Parameters
        ----------
        title : str
            Notification title.
        message : str
            Notification body text.
        """
        self._tray.showMessage(title, message, QSystemTrayIcon.Information, 3000)

    def notify_approval_needed(self, title: str = "Approbation requise",
                               message: str = "L'agent demande votre approbation."):
        """Show an approval needed notification.

        Parameters
        ----------
        title : str
            Notification title.
        message : str
            Notification body text.
        """
        self._tray.showMessage(title, message, QSystemTrayIcon.Warning, 5000)

    def set_icon(self, icon: QIcon):
        """Update the tray icon."""
        self._icon = icon
        self._tray.setIcon(icon)

    @property
    def is_visible(self) -> bool:
        """Check if the tray icon is visible."""
        return self._tray.isVisible()
