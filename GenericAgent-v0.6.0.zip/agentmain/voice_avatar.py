"""GenericAgent v0.6.0 — Voice & Avatar Pipeline : STT/TTS/VRM + VRoid Hub.

Inspire de AIAvatarKit (uezo/aiavatarkit).
Fournit un pipeline VAD->STT->LLM->TTS->Avatar complet,
provider-agnostic, avec support VRoid Hub pour les avatars anime.
"""
from __future__ import annotations

import io
import json
import logging
import os
import struct
import time
import wave
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Iterator, List, Optional, Protocol, Sequence, Tuple

logger = logging.getLogger("ga.agentmain.voice_avatar")


# ══════════════════════════════════════════════════════════════════════════════
#  Providers STT/TTS
# ══════════════════════════════════════════════════════════════════════════════

class STTProvider(Enum):
    """Fournisseurs de Speech-to-Text."""
    GOOGLE = "google"
    OPENAI = "openai"
    AZURE = "azure"
    LOCAL_WHISPER = "local_whisper"


class TTSProvider(Enum):
    """Fournisseurs de Text-to-Speech."""
    GOOGLE = "google"
    OPENAI = "openai"
    AZURE = "azure"
    VOICEVOX = "voicevox"
    ELEVENLABS = "elevenlabs"


class VoiceProvider(Protocol):
    """Protocol pour les fournisseurs vocaux."""

    def transcribe(self, audio_data: bytes) -> str:
        """Transcrit l'audio en texte."""
        ...

    def synthesize(self, text: str, voice_id: str = "default") -> bytes:
        """Synthetise le texte en audio."""
        ...


# ══════════════════════════════════════════════════════════════════════════════
#  VoicePipeline — Pipeline vocal provider-agnostic
# ══════════════════════════════════════════════════════════════════════════════

class VoicePipeline:
    """Pipeline vocal provider-agnostic pour STT et TTS.

    Permet de changer de fournisseur sans modifier le code.
    Supporte Google, OpenAI, Azure, et local Whisper pour STT.
    Supporte Google, OpenAI, Azure, VOICEVOX, et ElevenLabs pour TTS.
    """

    def __init__(self, stt_provider: STTProvider = STTProvider.GOOGLE,
                 tts_provider: TTSProvider = TTSProvider.GOOGLE,
                 api_key: str = "") -> None:
        self.stt_provider = stt_provider
        self.tts_provider = tts_provider
        self._api_key = api_key
        self._stt_config: Dict[str, Any] = {"language": "fr-FR"}
        self._tts_config: Dict[str, Any] = {"language": "fr-FR", "voice": "default"}
        logger.info("VoicePipeline initialise (STT=%s, TTS=%s)", stt_provider.value, tts_provider.value)

    def transcribe(self, audio_data: bytes) -> str:
        """Transcrit l'audio en texte.

        Args:
            audio_data: Donnees audio (PCM ou WAV)

        Returns:
            Texte transcrit
        """
        logger.debug("Transcription audio (%d bytes)", len(audio_data))

        if self.stt_provider == STTProvider.GOOGLE:
            return self._transcribe_google(audio_data)
        elif self.stt_provider == STTProvider.OPENAI:
            return self._transcribe_openai(audio_data)
        elif self.stt_provider == STTProvider.LOCAL_WHISPER:
            return self._transcribe_whisper(audio_data)
        else:
            return self._transcribe_google(audio_data)

    def synthesize(self, text: str, voice_id: str = "default") -> bytes:
        """Synthetise le texte en audio.

        Args:
            text: Texte a synthetiser
            voice_id: Identifiant de la voix

        Returns:
            Donnees audio (PCM/WAV)
        """
        logger.debug("Synthese TTS (%d caracteres, voix=%s)", len(text), voice_id)

        if self.tts_provider == TTSProvider.GOOGLE:
            return self._synthesize_google(text, voice_id)
        elif self.tts_provider == TTSProvider.OPENAI:
            return self._synthesize_openai(text, voice_id)
        elif self.tts_provider == TTSProvider.VOICEVOX:
            return self._synthesize_voicevox(text, voice_id)
        else:
            return self._synthesize_google(text, voice_id)

    def set_stt_provider(self, provider: STTProvider) -> None:
        """Change le fournisseur STT."""
        self.stt_provider = provider
        logger.info("STT provider change : %s", provider.value)

    def set_tts_provider(self, provider: TTSProvider) -> None:
        """Change le fournisseur TTS."""
        self.tts_provider = provider
        logger.info("TTS provider change : %s", provider.value)

    # ── Implementations STT ──────────────────────────────────────────────

    def _transcribe_google(self, audio_data: bytes) -> str:
        """Transcrit via Google Speech-to-Text REST API."""
        try:
            import requests
            import base64
            audio_b64 = base64.b64encode(audio_data).decode()
            url = f"https://speech.googleapis.com/v1/speech:recognize?key={self._api_key}"
            payload = {
                "config": {
                    "encoding": "LINEAR16",
                    "sampleRateHertz": 16000,
                    "languageCode": self._stt_config.get("language", "fr-FR"),
                },
                "audio": {"content": audio_b64},
            }
            resp = requests.post(url, json=payload, timeout=10)
            if resp.status_code == 200:
                results = resp.json().get("results", [])
                if results:
                    alternatives = results[0].get("alternatives", [])
                    if alternatives:
                        return alternatives[0].get("transcript", "")
            return ""
        except ImportError:
            logger.warning("requests non installe, transcription simulee")
            return "[Transcription simulee - installez requests]"

    def _transcribe_openai(self, audio_data: bytes) -> str:
        """Transcrit via OpenAI Whisper API."""
        try:
            import requests
            url = "https://api.openai.com/v1/audio/transcriptions"
            headers = {"Authorization": f"Bearer {self._api_key}"}
            files = {"file": ("audio.wav", audio_data, "audio/wav")}
            data = {"model": "whisper-1", "language": "fr"}
            resp = requests.post(url, headers=headers, files=files, data=data, timeout=30)
            if resp.status_code == 200:
                return resp.json().get("text", "")
            return ""
        except ImportError:
            return "[Transcription simulee]"

    def _transcribe_whisper(self, audio_data: bytes) -> str:
        """Transcrit via Whisper local (si installe)."""
        try:
            import whisper
            model = whisper.load_model("base")
            result = model.transcribe(audio_data)
            return result.get("text", "")
        except ImportError:
            return "[Whisper non installe - pip install openai-whisper]"

    # ── Implementations TTS ──────────────────────────────────────────────

    def _synthesize_google(self, text: str, voice_id: str = "default") -> bytes:
        """Synthetise via Google Text-to-Speech REST API."""
        try:
            import requests
            url = f"https://texttospeech.googleapis.com/v1/text:synthesize?key={self._api_key}"
            payload = {
                "input": {"text": text[:5000]},
                "voice": {"languageCode": self._tts_config.get("language", "fr-FR"), "name": voice_id if voice_id != "default" else "fr-FR-Standard-A"},
                "audioConfig": {"audioEncoding": "LINEAR16"},
            }
            resp = requests.post(url, json=payload, timeout=10)
            if resp.status_code == 200:
                import base64
                audio_b64 = resp.json().get("audioContent", "")
                if audio_b64:
                    return base64.b64decode(audio_b64)
            return b""
        except ImportError:
            return b""

    def _synthesize_openai(self, text: str, voice_id: str = "default") -> bytes:
        """Synthetise via OpenAI TTS API."""
        try:
            import requests
            url = "https://api.openai.com/v1/audio/speech"
            headers = {"Authorization": f"Bearer {self._api_key}"}
            payload = {"model": "tts-1", "input": text[:4096], "voice": voice_id if voice_id != "default" else "alloy"}
            resp = requests.post(url, headers=headers, json=payload, timeout=30)
            if resp.status_code == 200:
                return resp.content
            return b""
        except ImportError:
            return b""

    def _synthesize_voicevox(self, text: str, voice_id: str = "default") -> bytes:
        """Synthetise via VOICEVOX Engine (local)."""
        try:
            import requests
            speaker_id = 1  # Par defaut
            url = f"http://localhost:50021/audio_query?text={text[:5000]}&speaker={speaker_id}"
            resp = requests.post(url, timeout=10)
            if resp.status_code == 200:
                query = resp.json()
                synth_url = f"http://localhost:50021/synthesis?speaker={speaker_id}"
                synth_resp = requests.post(synth_url, json=query, timeout=30)
                if synth_resp.status_code == 200:
                    return synth_resp.content
            return b""
        except ImportError:
            return b""


# ══════════════════════════════════════════════════════════════════════════════
#  VADProcessor — Voice Activity Detection
# ══════════════════════════════════════════════════════════════════════════════

class VADProcessor:
    """Detecteur d'activite vocale (Voice Activity Detection).

    Detecte les segments de parole dans un flux audio pour
    declencher la transcription uniquement quand l'utilisateur parle.

    Attributes:
        silence_threshold: Seuil d'amplitude pour detecter la parole
        min_speech_duration: Duree minimale de parole (secondes)
    """

    def __init__(self, silence_threshold: float = 0.01,
                 min_speech_duration: float = 0.3) -> None:
        self.silence_threshold = silence_threshold
        self.min_speech_duration = min_speech_duration
        self._is_speaking = False
        self._speech_start_time: Optional[float] = None
        logger.info("VADProcessor initialise (threshold=%.3f, min_duration=%.1fs)",
                     silence_threshold, min_speech_duration)

    def detect_speech(self, audio_chunk: bytes, sample_rate: int = 16000,
                      sample_width: int = 2) -> bool:
        """Detecte si un chunk audio contient de la parole.

        Args:
            audio_chunk: Chunk audio PCM
            sample_rate: Taux d'echantillonnage
            sample_width: Largeur d'echantillon en bytes

        Returns:
            True si de la parole est detectee
        """
        if not audio_chunk:
            return False

        try:
            # Calculer le RMS (Root Mean Square) du chunk
            num_samples = len(audio_chunk) // sample_width
            if num_samples == 0:
                return False

            total = 0
            for i in range(0, min(len(audio_chunk), sample_width * num_samples), sample_width):
                if sample_width == 2:
                    sample = struct.unpack_from("<h", audio_chunk, i)[0]
                    total += sample * sample

            rms = (total / num_samples) ** 0.5 / 32768.0  # Normaliser

            is_speech = rms > self.silence_threshold

            if is_speech and not self._is_speaking:
                self._speech_start_time = time.monotonic()
                self._is_speaking = True
            elif not is_speech and self._is_speaking:
                self._is_speaking = False

            return is_speech
        except Exception as e:
            logger.debug("Erreur VAD : %s", e)
            return False

    def process_stream(self, audio_stream: Iterator[bytes],
                       sample_rate: int = 16000) -> Iterator[bytes]:
        """Traite un flux audio et ne yield que les chunks contenant de la parole.

        Args:
            audio_stream: Flux audio en entree
            sample_rate: Taux d'echantillonnage

        Yields:
            Chunks audio contenant de la parole
        """
        for chunk in audio_stream:
            if self.detect_speech(chunk, sample_rate):
                yield chunk


# ══════════════════════════════════════════════════════════════════════════════
#  AvatarController — Controle d'avatar VRM/VRoid
# ══════════════════════════════════════════════════════════════════════════════

class AvatarController:
    """Controleur d'avatar VRM/VRoid avec lip-sync et expressions.

    Supporte le format VRM pour les avatars 3D anime, avec
    synchronisation labiale et expressions faciales.

    Attributes:
        avatar_path: Chemin vers le fichier VRM de l'avatar
    """

    # Expressions VRM standard (BlendShape)
    EXPRESSIONS = [
        "neutral", "happy", "angry", "sad", "surprised",
        "relaxed", "thinking", "blink", "blink_left", "blink_right",
        "aa", "ih", "ou", "ee", "oh",  # Visemes pour lip-sync
    ]

    def __init__(self, avatar_path: str = "") -> None:
        self.avatar_path = avatar_path
        self._current_expression = "neutral"
        self._available_avatars: List[Dict[str, str]] = []
        self._lip_sync_values: Dict[str, float] = {}
        logger.info("AvatarController initialise (avatar: %s)",
                     avatar_path or "aucun")

    def set_expression(self, expression_name: str) -> None:
        """Definit l'expression faciale de l'avatar.

        Args:
            expression_name: Nom de l'expression (neutral, happy, angry, sad, etc.)
        """
        if expression_name not in self.EXPRESSIONS:
            logger.warning("Expression inconnue : %s", expression_name)
            return
        self._current_expression = expression_name
        logger.debug("Expression changee : %s", expression_name)

    def set_lip_sync(self, viseme_data: Dict[str, float]) -> None:
        """Definit les valeurs de synchronisation labiale.

        Args:
            viseme_data: Dictionnaire viseme -> valeur (0.0 a 1.0)
                         Ex: {"aa": 0.8, "ih": 0.2, "ou": 0.0}
        """
        self._lip_sync_values = viseme_data

    def get_available_expressions(self) -> List[str]:
        """Retourne les expressions disponibles."""
        return list(self.EXPRESSIONS)

    def get_available_avatars(self) -> List[Dict[str, str]]:
        """Retourne les avatars disponibles."""
        return self._available_avatars

    def load_avatar(self, path: str) -> bool:
        """Charge un avatar VRM depuis un fichier.

        Args:
            path: Chemin vers le fichier VRM

        Returns:
            True si le chargement a reussi
        """
        if os.path.exists(path):
            self.avatar_path = path
            logger.info("Avatar charge : %s", path)
            return True
        logger.error("Fichier avatar introuvable : %s", path)
        return False

    def get_state(self) -> Dict[str, Any]:
        """Retourne l'etat actuel de l'avatar."""
        return {
            "avatar_path": self.avatar_path,
            "expression": self._current_expression,
            "lip_sync": self._lip_sync_values,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  VRoidHubClient — Client pour VRoid Hub
# ══════════════════════════════════════════════════════════════════════════════

class VRoidHubClient:
    """Client pour telecharger des avatars anime depuis VRoid Hub.

    VRoid Hub est une plateforme de partage d'avatars 3D au format VRM.
    Permet de donner une identite visuelle anime/waifu a l'agent.
    """

    BASE_URL = "https://hub.vroid.com/api"

    def __init__(self, api_key: str = "") -> None:
        self._api_key = api_key
        self._download_dir = os.path.expanduser("~/GenericAgent/avatars")
        logger.info("VRoidHubClient initialise")

    def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Recherche des avatars sur VRoid Hub.

        Args:
            query: Terme de recherche
            limit: Nombre maximum de resultats

        Returns:
            Liste d'avatars correspondants
        """
        try:
            import requests
            headers = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            params = {"query": query, "limit": limit}
            resp = requests.get(f"{self.BASE_URL}/characters", headers=headers, params=params, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", [])
            return []
        except ImportError:
            logger.warning("requests non installe")
            return []
        except Exception as e:
            logger.error("Erreur recherche VRoid Hub : %s", e)
            return []

    def download(self, avatar_id: str, output_dir: str = "") -> str:
        """Telecharge un avatar VRM depuis VRoid Hub.

        Args:
            avatar_id: Identifiant de l'avatar
            output_dir: Repertoire de destination

        Returns:
            Chemin du fichier telecharge
        """
        output_dir = output_dir or self._download_dir
        os.makedirs(output_dir, exist_ok=True)

        try:
            import requests
            headers = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            url = f"{self.BASE_URL}/characters/{avatar_id}/download"
            resp = requests.get(url, headers=headers, timeout=60)
            if resp.status_code == 200:
                output_path = os.path.join(output_dir, f"{avatar_id}.vrm")
                with open(output_path, "wb") as f:
                    f.write(resp.content)
                logger.info("Avatar telecharge : %s", output_path)
                return output_path
            return ""
        except Exception as e:
            logger.error("Erreur telechargement VRoid Hub : %s", e)
            return ""

    def get_popular(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Recupere les avatars populaires.

        Args:
            limit: Nombre maximum de resultats

        Returns:
            Liste d'avatars populaires
        """
        try:
            import requests
            headers = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            params = {"limit": limit, "sort": "popular"}
            resp = requests.get(f"{self.BASE_URL}/characters", headers=headers, params=params, timeout=10)
            if resp.status_code == 200:
                return resp.json().get("data", [])
            return []
        except Exception:
            return []


# ══════════════════════════════════════════════════════════════════════════════
#  SpeechToSpeechEngine — Pipeline S2S complet
# ══════════════════════════════════════════════════════════════════════════════

class SpeechToSpeechEngine:
    """Pipeline Speech-to-Speech complet : VAD -> STT -> LLM -> TTS -> Avatar.

    Orchestration modulaire du pipeline vocal avec interruption
    et middleware entre les etapes.

    Utilisation ::
        engine = SpeechToSpeechEngine(voice_pipeline, avatar_controller, llm_callback)
        text, audio = engine.process(audio_input)
    """

    def __init__(self, voice_pipeline: VoicePipeline,
                 avatar_controller: Optional[AvatarController] = None,
                 llm_callback: Optional[Callable] = None) -> None:
        """Initialise le moteur S2S.

        Args:
            voice_pipeline: Pipeline vocal (STT/TTS)
            avatar_controller: Controleur d'avatar (optionnel)
            llm_callback: Fonction (prompt) -> str pour les reponses LLM
        """
        self.voice = voice_pipeline
        self.avatar = avatar_controller or AvatarController()
        self.llm_callback = llm_callback
        self._vad = VADProcessor()
        self._middleware: List[Callable[[str, str], str]] = []
        self._is_interrupted = False
        logger.info("SpeechToSpeechEngine initialise")

    def add_middleware(self, middleware: Callable[[str, str], str]) -> None:
        """Ajoute un middleware entre les etapes du pipeline.

        Les middlewares transforment les donnees entre chaque etape.
        Signature : (stage_name, data) -> transformed_data

        Exemples : filtre de securite, conversion de format, logging
        """
        self._middleware.append(middleware)

    def _apply_middleware(self, stage: str, data: str) -> str:
        """Applique les middlewares a une etape."""
        for mw in self._middleware:
            try:
                data = mw(stage, data)
            except Exception as e:
                logger.error("Erreur middleware : %s", e)
        return data

    def process(self, audio_input: bytes) -> Tuple[str, bytes]:
        """Traite l'audio en entree et retourne la reponse.

        Pipeline complet : STT -> Middleware -> LLM -> Middleware -> TTS -> Avatar

        Args:
            audio_input: Donnees audio d'entree

        Returns:
            Tuple (texte_reponse, audio_reponse)
        """
        # Etape 1 : STT
        transcribed = self.voice.transcribe(audio_input)
        transcribed = self._apply_middleware("stt", transcribed)
        logger.info("STT : %s", transcribed[:100])

        # Etape 2 : LLM
        if self.llm_callback:
            llm_response = self.llm_callback(transcribed)
        else:
            llm_response = f"[Reponse simulee pour : {transcribed}]"
        llm_response = self._apply_middleware("llm", llm_response)

        # Mettre a jour l'avatar
        if self.avatar:
            if "?" in transcribed:
                self.avatar.set_expression("thinking")
            elif any(w in transcribed.lower() for w in ("merci", "super", "bravo")):
                self.avatar.set_expression("happy")
            else:
                self.avatar.set_expression("neutral")

        # Etape 3 : TTS
        audio_output = self.voice.synthesize(llm_response)
        logger.info("TTS : %d bytes generes", len(audio_output))

        return llm_response, audio_output

    def interrupt(self) -> None:
        """Interrompt la parole en cours.

        Permet a l'utilisateur de couper l'agent en plein discours,
        essentiel pour une conversation naturelle.
        """
        self._is_interrupted = True
        logger.info("Interruption demandee")
