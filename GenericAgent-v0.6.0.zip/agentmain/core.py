"""
Core GenericAgent class — the main agent runtime.

This module defines :class:`GenericAgent`, the primary orchestrator that
manages LLM sessions, task queues, and the agent execution loop.

Backward compatibility: the legacy name :data:`GeneraticAgent` is retained
as an alias so that existing ``from agentmain import GeneraticAgent``
imports continue to work unchanged.
"""

from __future__ import annotations

import os
import queue
import re
import threading
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

from logging_config import setup_logging, get_logger

setup_logging()
logger = get_logger("agentmain")

# ---------------------------------------------------------------------------
# Project-level imports
# ---------------------------------------------------------------------------

from llmcore import (
    reload_mykeys,
    LLMSession,
    ToolClient,
    ClaudeSession,
    MixinSession,
    NativeToolClient,
    NativeClaudeSession,
    NativeOAISession,
)
from agent_loop import agent_runner_loop
from ga import GenericAgentHandler, smart_format, get_global_memory, format_error, consume_file

from exceptions import AgentError, MaxTurnsExceededError, SessionConfigError
from config import get_agent_config

# ---------------------------------------------------------------------------
# Internal package imports
# ---------------------------------------------------------------------------

from agentmain.prompts import script_dir, TOOLS_SCHEMA, load_tool_schema, get_system_prompt, get_merged_tool_schemas
from agentmain.slash import handle_slash_cmd, _get_resume_prompt


# ---------------------------------------------------------------------------
# GenericAgent
# ---------------------------------------------------------------------------


class GenericAgent:
    """Core agent runtime that orchestrates LLM sessions and task execution.

    A :class:`GenericAgent` instance owns a queue of tasks, a set of LLM
    client backends, and the shared history list.  Call :meth:`put_task` to
    enqueue a user query and receive a :class:`queue.Queue` on which
    incremental and final results will be published.

    Attributes
    ----------
    lock : threading.Lock
        Guard for thread-sensitive state.
    task_dir : str | None
        Working directory for file-based I/O (task mode).
    history : list[str]
        Running conversation history.
    task_queue : queue.Queue
        Input queue for incoming tasks.
    is_running : bool
        Whether the agent loop is currently processing a task.
    stop_sig : bool
        Flag to signal the agent loop to abort.
    llm_no : int
        Index of the currently selected LLM client.
    inc_out : bool
        Whether to emit incremental output (``True`` in interactive mode).
    handler : GenericAgentHandler | None
        The handler for the current / most recent agent run.
    verbose : bool
        Enable verbose debug output.
    """

    def __init__(self) -> None:
        os.makedirs(os.path.join(script_dir, "temp"), exist_ok=True)
        self.lock: threading.Lock = threading.Lock()
        self.task_dir: Optional[str] = None
        self.history: List[str] = []
        self.task_queue: queue.Queue = queue.Queue()
        self.is_running: bool = False
        self.stop_sig: bool = False
        self.llm_no: int = 0
        self.inc_out: bool = False
        self.handler: Optional[GenericAgentHandler] = None
        self.verbose: bool = True
        self.load_llm_sessions()
        self._load_plugins()
        self._connect_mcp_servers()

        # v0.6.0 "Big Tech Monster" module initializations (lazy — set to None)
        self._chroma_store = None           # memory.chroma_store
        self._guardrail_manager = None      # agentmain.guardrails
        self._extension_manager = None      # agentmain.extensions
        self._context_engine = None         # agentmain.extensions
        self._closed_learning = None        # agentmain.closed_learning
        self._agent_handoff = None          # agentmain.handoffs
        self._fastmcp_server = None         # mcp.fastmcp
        self._browser_session = None        # agentmain.browser_intel
        self._voice_pipeline = None         # agentmain.voice_avatar
        self._avatar_controller = None      # agentmain.voice_avatar

    # ── Plugin loading ────────────────────────────────────────────────────

    def _load_plugins(self) -> None:
        """Auto-discover and load tool plugins from the plugins directory."""
        try:
            from tools.registry import get_registry
            registry = get_registry()
            plugin_dir = os.path.join(script_dir, "plugins", "tools")
            count = registry.load_plugins(plugin_dir)
            if count > 0:
                logger.info("Loaded %d tool plugins", count)
        except Exception as exc:
            logger.debug("Plugin loading skipped: %s", exc)

    def _connect_mcp_servers(self) -> None:
        """Auto-connect to MCP servers defined in mcp_config.json."""
        try:
            from mcp.client import load_mcp_config, connect_mcp_server
            config_path = os.path.join(script_dir, "mcp_config.json")
            if os.path.exists(config_path):
                servers = load_mcp_config(config_path)
                connected = 0
                for server_config in servers:
                    try:
                        conn = connect_mcp_server(server_config)
                        if conn and conn.status.value == "connected":
                            connected += 1
                            logger.info(
                                "MCP server '%s' connected (%d tools)",
                                server_config.name,
                                len(conn.tools),
                            )
                    except Exception as exc:
                        logger.warning(
                            "MCP server '%s' connection failed: %s",
                            server_config.name, exc,
                        )
                if connected > 0:
                    logger.info("Connected %d/%d MCP servers", connected, len(servers))
        except Exception as exc:
            logger.debug("MCP auto-connect skipped: %s", exc)

    # ── LLM session management ───────────────────────────────────────────

    def load_llm_sessions(self) -> None:
        """Reload LLM sessions from :mod:`llmcore` if the key file has changed.

        On first call (or when keys have changed) this rebuilds the
        ``self.llmclients`` list and preserves the existing conversation
        history on the active backend.
        """
        mykeys, changed = reload_mykeys()
        if not changed and hasattr(self, "llmclients"):
            return

        # Preserve conversation history across reloads
        old_history: Optional[list] = None
        try:
            old_history = self.llmclient.backend.history
        except Exception:
            old_history = None

        llm_sessions: List[Any] = []
        for k, cfg in mykeys.items():
            if not any(x in k for x in ["api", "config", "cookie"]):
                continue
            try:
                if "native" in k and "claude" in k:
                    llm_sessions.append(NativeToolClient(NativeClaudeSession(cfg=cfg)))
                elif "native" in k and "oai" in k:
                    llm_sessions.append(NativeToolClient(NativeOAISession(cfg=cfg)))
                elif "claude" in k:
                    llm_sessions.append(ToolClient(ClaudeSession(cfg=cfg)))
                elif "oai" in k:
                    llm_sessions.append(ToolClient(LLMSession(cfg=cfg)))
                elif "google" in k:
                    try:
                        from llmcore.google_provider import GoogleAIConfig, GoogleAISession
                        gconfig = GoogleAIConfig(api_key=cfg.get("api_key", cfg if isinstance(cfg, str) else ""))
                        from llmcore.clients import LLMSession as _LS
                        # Wrap GoogleAISession to be compatible with ToolClient
                        ga_session = GoogleAISession(gconfig)
                        llm_sessions.append(ToolClient(_LS(cfg=cfg)))  # fallback to generic
                    except Exception:
                        logger.debug("Google AI session init skipped for %s", k, exc_info=True)
                elif "mixin" in k:
                    llm_sessions.append({"mixin_cfg": cfg})
            except Exception:
                logger.debug("Skipping LLM session config %s due to init error", k, exc_info=True)

        # Resolve mixin placeholders
        for i, s in enumerate(llm_sessions):
            if isinstance(s, dict) and "mixin_cfg" in s:
                try:
                    mixin = MixinSession(llm_sessions, s["mixin_cfg"])
                    if isinstance(mixin._sessions[0], (NativeClaudeSession, NativeOAISession)):
                        llm_sessions[i] = NativeToolClient(mixin)
                    else:
                        llm_sessions[i] = ToolClient(mixin)
                except Exception as exc:
                    logger.error("Failed to init MixinSession with cfg %s: %s", s["mixin_cfg"], exc)

        self.llmclients: List[Any] = llm_sessions
        if not self.llmclients:
            logger.error("No LLM sessions configured — check mykey.py / mykey.json")
            self.llmclient: Any = None
            return
        self.llmclient = self.llmclients[self.llm_no % len(self.llmclients)]
        if old_history:
            import copy
            self.llmclient.backend.history = copy.deepcopy(old_history)

    def next_llm(self, n: int = -1) -> None:
        """Switch to the next (or specified) LLM client.

        Parameters
        ----------
        n : int
            If ``-1``, advance to the next client; otherwise switch to the
            client at index *n* (modulo the number of available clients).
        """
        self.load_llm_sessions()
        self.llm_no = ((self.llm_no + 1) if n < 0 else n) % len(self.llmclients)
        last_client = self.llmclient
        self.llmclient = self.llmclients[self.llm_no]
        try:
            import copy
            self.llmclient.backend.history = copy.deepcopy(last_client.backend.history)
        except Exception:
            raise SessionConfigError("BAD Mixin config: Check your mykey.py")
        self.llmclient.last_tools = ""
        name = self.get_llm_name(model=True)
        if "glm" in name or "minimax" in name or "kimi" in name:
            load_tool_schema("_cn")
        else:
            load_tool_schema()

    def list_llms(self) -> List[Tuple[int, str, bool]]:
        """Return a summary of available LLM backends.

        Returns
        -------
        list[tuple[int, str, bool]]
            Each tuple contains ``(index, display_name, is_currently_active)``.
        """
        self.load_llm_sessions()
        return [
            (i, self.get_llm_name(b), i == self.llm_no)
            for i, b in enumerate(self.llmclients)
        ]

    def get_llm_name(self, b: Any = None, model: bool = False) -> str:
        """Return a human-readable name for an LLM client.

        Parameters
        ----------
        b : Any
            The client object.  Defaults to ``self.llmclient``.
        model : bool
            If ``True``, return the lowercase model name; otherwise return
            ``SessionType/name``.

        Returns
        -------
        str
            The display name for the client.
        """
        b = self.llmclient if b is None else b
        if isinstance(b, dict):
            return "BADCONFIG_MIXIN"
        if model:
            return b.backend.model.lower()
        return f"{type(b.backend).__name__}/{b.backend.name}"

    # ── Task lifecycle ───────────────────────────────────────────────────

    def abort(self) -> None:
        """Signal the running agent loop to stop.

        If the agent is not currently running this is a no-op.
        """
        if not self.is_running:
            return
        logger.info("Abort current task...")
        self.stop_sig = True
        if self.handler is not None:
            self.handler.code_stop_signal.append(1)

    def put_task(
        self,
        query: str,
        source: str = "user",
        images: Optional[List[str]] = None,
    ) -> queue.Queue:
        """Enqueue a task for the agent and return a result queue.

        Parameters
        ----------
        query : str
            The user's input text (may be a slash command).
        source : str
            Origin of the query — ``"user"``, ``"task"``, or ``"reflect"``.
        images : list[str] | None
            Optional list of image paths or URLs.

        Returns
        -------
        queue.Queue
            A queue on which dicts with keys ``"next"`` (incremental) and
            ``"done"`` (final) will be placed.
        """
        display_queue: queue.Queue = queue.Queue()
        self.task_queue.put(
            {
                "query": query,
                "source": source,
                "images": images or [],
                "output": display_queue,
            }
        )
        return display_queue

    # ── Slash command handling ────────────────────────────────────────────

    @staticmethod
    def _build_resume_prompt() -> str:
        """Return the prompt text used by the ``/resume`` command.

        The resume command asks the LLM to scan recent session files,
        summarise each one, and let the user pick which to continue.

        Returns
        -------
        str
            The resume prompt.
        """
        return _get_resume_prompt()

    def _handle_slash_cmd(
        self, raw_query: str, display_queue: queue.Queue
    ) -> Optional[str]:
        """Process slash commands before they reach the LLM.

        Delegates to :func:`~agentmain.slash.handle_slash_cmd`.

        Parameters
        ----------
        raw_query : str
            The raw user input.
        display_queue : queue.Queue
            Queue for sending feedback to the caller.

        Returns
        -------
        str | None
            The rewritten query to send to the LLM, or ``None`` if the
            command was handled entirely within this method.
        """
        return handle_slash_cmd(self, raw_query, display_queue)

    # ── Main run loop ────────────────────────────────────────────────────

    def run(self) -> None:
        """Consume tasks from :attr:`task_queue` and execute them sequentially.

        For each task the method builds a system prompt, creates a fresh
        :class:`GenericAgentHandler`, and runs the
        :func:`~agent_loop.agent_runner_loop` generator.  Incremental and
        final results are pushed onto the task's display queue.

        This method blocks indefinitely and is intended to be run in a
        dedicated thread.
        """
        while True:
            task = self.task_queue.get()
            raw_query: str = task["query"]
            source: str = task["source"]
            images: List[str] = task.get("images") or []
            display_queue: queue.Queue = task["output"]

            raw_query = self._handle_slash_cmd(raw_query, display_queue)
            if raw_query is None:
                self.task_queue.task_done()
                continue

            # v0.6.0: Input guardrail validation
            guardrail_result = self.validate_input(raw_query)
            if not guardrail_result.passed:
                display_queue.put({"done": f"[GUARDRAIL] Input blocked: {guardrail_result.reason}", "source": "system"})
                self.task_queue.task_done()
                continue

            self.is_running = True
            rquery = smart_format(raw_query.replace("\n", " "), max_str_len=200)
            self.history.append(f"[USER]: {rquery}")

            sys_prompt = get_system_prompt() + getattr(
                self.llmclient.backend, "extra_sys_prompt", ""
            )
            handler = GenericAgentHandler(
                self, self.history, os.path.join(script_dir, "temp")
            )

            # Use merged tool schemas (builtin + plugins)
            tools_schema = get_merged_tool_schemas()

            # Carry over working memory from the previous handler
            if self.handler and "key_info" in self.handler.working:
                ki = re.sub(
                    r"\n\[(?:SYSTEM|SYSTÈME)\] (?:此为|Ceci est|This is).*?(?:工作记忆|mémoire de travail|working memory)[。\n]*",
                    "",
                    self.handler.working["key_info"],
                )
                handler.working["key_info"] = ki
                handler.working["passed_sessions"] = ps = (
                    self.handler.working.get("passed_sessions", 0) + 1
                )
                if ps > 0:
                    lang = os.environ.get('GA_LANG', '')
                    if lang == 'zh':
                        msg = f"\n[SYSTEM] 此为 {ps} 个对话前设置的key_info，若已在新任务，先更新或清除工作记忆。\n"
                    elif lang == 'en':
                        msg = f"\n[SYSTEM] This is key_info set {ps} session(s) ago. If starting a new task, update or clear working memory first.\n"
                    else:
                        msg = f"\n[SYSTÈME] Ceci est le key_info défini il y a {ps} session(s). Si nouvelle tâche, mettre à jour ou effacer la mémoire de travail.\n"
                    handler.working["key_info"] += msg
            else:
                # Try to load persisted working checkpoint from disk
                try:
                    from memory.crystallization import load_working_checkpoint
                    checkpoint = load_working_checkpoint()
                    if checkpoint and checkpoint.get("key_info"):
                        handler.working["key_info"] = checkpoint["key_info"]
                        handler.working["related_sop"] = checkpoint.get("related_sop", "")
                        handler.working["passed_sessions"] = 0
                        logger.info("Restored working checkpoint from disk (saved at %s)", checkpoint.get("saved_at", "unknown"))
                except Exception:
                    pass  # Non-critical — best effort

            # ── Auto-activate ReasoningEngine ─────────────────────────────────
            # Select the best reasoning mode based on the task description
            try:
                from agentmain.reasoning import ReasoningEngine, ReasoningMode
                suggested_mode = ReasoningEngine.suggest_mode(raw_query)
                if suggested_mode != ReasoningMode.DEFAULT:
                    handler.reasoning_engine = ReasoningEngine(mode=suggested_mode)
                    logger.info(
                        "ReasoningEngine auto-activated: mode=%s for task: %.60s",
                        suggested_mode.value, raw_query,
                    )
            except Exception as exc:
                logger.debug("ReasoningEngine auto-activation skipped: %s", exc)

            self.handler = handler

            # Phase 7: Wire the handler's event_queue to the display_queue
            # so tool_call/tool_result/thinking events flow to the UI
            handler.event_queue = display_queue

            # Although a new handler is created, the **full** history lives
            # in llmclient, so it is the true full history.
            agent_config = get_agent_config()
            gen = agent_runner_loop(
                self.llmclient,
                sys_prompt,
                raw_query,
                handler,
                tools_schema,
                max_turns=agent_config.max_turns,
                verbose=self.verbose,
            )
            try:
                full_resp: str = ""
                last_pos: int = 0
                for chunk in gen:
                    if consume_file(self.task_dir, "_stop"):
                        self.abort()
                    if self.stop_sig:
                        break
                    full_resp += chunk
                    if len(full_resp) - last_pos > 50 or "LLM Running" in chunk:
                        display_queue.put(
                            {
                                "next": full_resp[last_pos:] if self.inc_out else full_resp,
                                "source": source,
                            }
                        )
                        last_pos = len(full_resp)

                # Flush any remaining incremental output
                if self.inc_out and last_pos < len(full_resp):
                    display_queue.put(
                        {"next": full_resp[last_pos:], "source": source}
                    )

                # Post-processing formatting
                if "</summary>" in full_resp:
                    full_resp = full_resp.replace("</summary>", "</summary>\n\n")
                if "</file_content>" in full_resp:
                    full_resp = re.sub(
                        r"<file_content>\s*(.*?)\s*</file_content>",
                        r"\n````\n<file_content>\n\1\n</file_content>\n````",
                        full_resp,
                        flags=re.DOTALL,
                    )

                # v0.6.0: Output guardrail validation
                output_result = self.validate_output(full_resp)
                if not output_result.passed:
                    full_resp += f"\n\n[GUARDRAIL] Output warning: {output_result.reason}"

                display_queue.put({"done": full_resp, "source": source})
                self.history = handler.history_info

            except Exception as exc:
                logger.error("Backend Error: %s", format_error(exc))
                display_queue.put(
                    {"done": full_resp + f"\n```\n{format_error(exc)}\n```", "source": source}
                )
            finally:
                if self.stop_sig:
                    logger.info("User aborted the task.")
                self.is_running = self.stop_sig = False
                self.task_queue.task_done()
                if self.handler is not None:
                    self.handler.code_stop_signal.append(1)


    # ── v0.6.0 Lazy-initialization properties ───────────────────────────

    @property
    def chroma_store(self):
        """ChromaDB-backed memory store (lazy init)."""
        if self._chroma_store is None:
            from memory.chroma_store import ChromaMemoryStore
            self._chroma_store = ChromaMemoryStore()
        return self._chroma_store

    @property
    def guardrail_manager(self):
        """Centralized input/output guardrail manager."""
        if self._guardrail_manager is None:
            from agentmain.guardrails import GuardrailManager
            self._guardrail_manager = GuardrailManager()
            self._guardrail_manager.setup_defaults()
        return self._guardrail_manager

    @property
    def extension_manager(self):
        """Extension lifecycle manager."""
        if self._extension_manager is None:
            from agentmain.extensions import ExtensionManager
            self._extension_manager = ExtensionManager()
        return self._extension_manager

    @property
    def context_engine(self):
        """Context window manager with compaction."""
        if self._context_engine is None:
            from agentmain.extensions import ContextEngine
            self._context_engine = ContextEngine()
        return self._context_engine

    @property
    def closed_learning(self):
        """Closed Learning Loop (Discover→Execute→Reflect→Codify→Improve)."""
        if self._closed_learning is None:
            from agentmain.closed_learning import ClosedLearningLoop
            self._closed_learning = ClosedLearningLoop(agent=self)
        return self._closed_learning

    @property
    def agent_handoff(self):
        """Multi-agent handoff manager."""
        if self._agent_handoff is None:
            from agentmain.handoffs import AgentHandoff
            self._agent_handoff = AgentHandoff()
        return self._agent_handoff

    @property
    def fastmcp_server(self):
        """FastMCP server for exposing agent capabilities via MCP protocol."""
        if self._fastmcp_server is None:
            from mcp.fastmcp import FastMCP
            self._fastmcp_server = FastMCP("genericagent", version="0.6.0")
        return self._fastmcp_server

    @property
    def browser_session(self):
        """Persistent browser session (lazy init)."""
        if self._browser_session is None:
            from agentmain.browser_intel import BrowserSession
            self._browser_session = BrowserSession()
        return self._browser_session

    @property
    def voice_pipeline(self):
        """Voice STT/TTS pipeline (lazy init)."""
        return self._voice_pipeline

    @property
    def avatar_controller(self):
        """VRM/VRoid avatar controller (lazy init)."""
        return self._avatar_controller

    # ── v0.6.0 Helper methods ─────────────────────────────────────────────

    def enable_voice(self, stt_provider="google", tts_provider="google", api_key=""):
        """Enable the voice pipeline with specified providers."""
        from agentmain.voice_avatar import VoicePipeline, STTProvider, TTSProvider
        self._voice_pipeline = VoicePipeline(
            stt_provider=STTProvider(stt_provider),
            tts_provider=TTSProvider(tts_provider),
            api_key=api_key,
        )
        return self._voice_pipeline

    def enable_avatar(self, avatar_path=""):
        """Enable the avatar controller with a VRM file."""
        from agentmain.voice_avatar import AvatarController
        self._avatar_controller = AvatarController(avatar_path=avatar_path)
        return self._avatar_controller

    def build_state_graph(self, state_schema=None, reducers=None):
        """Build a new StateGraph for structured agent execution."""
        from engine.state_graph import StateGraph, last_value
        if state_schema is None:
            from typing import TypedDict
            class AgentState(TypedDict):
                messages: list
                next_action: str
            state_schema = AgentState
            reducers = reducers or {"messages": last_value, "next_action": last_value}
        return StateGraph(state_schema=state_schema, reducers=reducers)

    def validate_input(self, text):
        """Validate user input through all guardrails."""
        return self.guardrail_manager.validate_input(text)

    def validate_output(self, text):
        """Validate agent output through all guardrails."""
        return self.guardrail_manager.validate_output(text)

    def search_memory(self, query, domain=None, n_results=5):
        """Search the vector memory store."""
        if domain:
            coll = self.chroma_store.collection_for_domain(domain)
        else:
            coll = self.chroma_store.get_or_create_collection("general")
        return coll.query(query_texts=[query], n_results=n_results)

    def register_mcp_tool(self, name=None, description=None):
        """Decorator to register a function as an MCP tool."""
        return self.fastmcp_server.tool(name=name, description=description)

    def create_flow(self, name="untitled", description=""):
        """Create a new agent flow (Langflow-inspired)."""
        from agentmain.flow import Flow
        return Flow(name=name, description=description)


# Backward-compatible alias — other modules import ``GeneraticAgent``
GeneraticAgent = GenericAgent
