"""
Slash command handling for GenericAgent.

This module defines the ``/session.*`` and ``/resume`` slash commands that
are processed *before* user input reaches the LLM.  The core
:class:`~agentmain.core.GenericAgent` class delegates to
:func:`handle_slash_cmd` from its own ``_handle_slash_cmd`` method so that
the public API of the agent remains unchanged.
"""

from __future__ import annotations

import json
import os
import queue
import re
from typing import Any, Optional

from ga import smart_format

from agentmain.prompts import script_dir

# ---------------------------------------------------------------------------
# /resume prompt — extracted from the inline string in the original monolith
# ---------------------------------------------------------------------------

_RESUME_PROMPT_FR: str = (
    r'Parcours temp/model_responses/ pour trouver les 10 fichiers les plus récents (hors ce PID), '
    r'lit le contenu de chaque fichier en remplaçant "\\n"→"\n" et "\\r"→"\r", '
    r'puis utilise re.findall(r"<history>\n\[(?:USER|Agent)\].*?</history>", content, re.DOTALL) '
    r'pour extraire les sessions, prend la dernière correspondance par fichier, trie par mtime décroissant, '
    r'résume chaque session en une phrase pour me laisser choisir ; puis lis la fin du fichier sélectionné comme base de conversation.'
)

_RESUME_PROMPT_ZH: str = (
    r'扫temp/model_responses/下时间最近的10个文件(除本PID)，'
    r'读取每个文件content后先replace("\\n","\n").replace("\\r","\r")统一为真换行，'
    r'再用re.findall(r"<history>\n\[(?:USER|Agent)\].*?</history>", content, re.DOTALL)'
    r'提取，取每文件最后一个匹配作为该会话内容，按mtime倒序，'
    r'每个用一句话总结聊了什么让我选择；选定后再简单读该文件末尾作为聊天基础'
)

_RESUME_PROMPT_EN: str = (
    r'Scan temp/model_responses/ for the 10 most recent files (excluding this PID), '
    r'read each file content after replacing "\\n"→"\n" and "\\r"→"\r", '
    r'then use re.findall(r"<history>\n\[(?:USER|Agent)\].*?</history>", content, re.DOTALL) '
    r'to extract sessions, take the last match per file, sort by mtime descending, '
    r'summarize each session in one sentence for me to choose; then read the end of the selected file as conversation base.'
)

def _get_resume_prompt() -> str:
    """Return the resume prompt in the appropriate language."""
    lang = os.environ.get('GA_LANG', '')
    if lang == 'en':
        return _RESUME_PROMPT_EN
    if lang == 'zh':
        return _RESUME_PROMPT_ZH
    return _RESUME_PROMPT_FR


def handle_slash_cmd(
    agent: Any, raw_query: str, display_queue: queue.Queue
) -> Optional[str]:
    """Process slash commands before they reach the LLM.

    Supported commands:

    * ``/session.<attr>=<value>`` — set a backend attribute on the
      current LLM session.  If *value* is a file path the file contents
      are read; JSON values are parsed automatically.
    * ``/resume`` — inject the session-resume prompt.

    Parameters
    ----------
    agent : GenericAgent
        The agent instance (used to access ``llmclient.backend``).
    raw_query : str
        The raw user input.
    display_queue : queue.Queue
        Queue for sending feedback to the caller.

    Returns
    -------
    str | None
        The rewritten query to send to the LLM, or ``None`` if the
        command was handled entirely within this method (e.g. a session
        attribute was set).
    """
    if not raw_query.startswith("/"):
        return raw_query

    # /session.<attr>=<value>
    if _sm := re.match(r"/session\.(\w+)=(.*)", raw_query.strip()):
        k, v = _sm.group(1), _sm.group(2)
        vfile = os.path.join(script_dir, "temp", v)
        if os.path.isfile(vfile):
            with open(vfile, encoding="utf-8") as fh:
                v = fh.read().strip()
        try:
            v = json.loads(v)  # cover number parsing
        except (json.JSONDecodeError, ValueError):
            pass
        setattr(agent.llmclient.backend, k, v)
        display_queue.put(
            {
                "done": smart_format(f"✅ session.{k} = {repr(v)}", max_str_len=500),
                "source": "system",
            }
        )
        return None

    # /resume
    if raw_query.strip() == "/resume":
        return _get_resume_prompt()

    return raw_query
