"""
GenericAgent — Auto-Update System

Checks for new versions on GitHub and provides one-click updates.
Works both in bundled (PyInstaller) and development mode.

Inspired by ClawX's electron-updater approach, but adapted for
Python/PyInstaller desktop apps.
"""
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile
from pathlib import Path
from typing import Callable, Optional

# GitHub release API
GITHUB_REPO = "genericagent/genericagent"
GITHUB_API = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
GITHUB_DOWNLOAD = f"https://github.com/{GITHUB_REPO}/releases/latest"

# Local state
UPDATE_DIR = Path.home() / "GenericAgent" / "updates"
STATE_FILE = UPDATE_DIR / "update_state.json"


def get_current_version() -> str:
    """Get the current application version."""
    try:
        # Try importing from the package
        from importlib.metadata import version
        return version("genericagent")
    except Exception:
        pass

    # Fallback: read from pyproject.toml
    try:
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        for line in pyproject.read_text().splitlines():
            if line.strip().startswith("version ="):
                return line.split("=")[1].strip().strip("\"'")
    except Exception:
        pass

    return "0.0.0"


def is_bundled() -> bool:
    """Check if running as a bundled PyInstaller app."""
    return getattr(sys, "frozen", False)


def get_install_dir() -> Path:
    """Get the installation directory."""
    if is_bundled():
        return Path(sys.executable).parent
    return Path(__file__).parent.parent


def check_for_update(timeout: float = 10.0) -> Optional[dict]:
    """
    Check GitHub for a new version.

    Returns:
        dict with release info if update available, None if up-to-date.
        {
            "version": "0.5.1",
            "download_url": "https://...",
            "changelog": "...",
            "size": 123456789,
        }
    """
    import requests

    current = get_current_version()
    try:
        resp = requests.get(
            GITHUB_API,
            timeout=timeout,
            headers={"Accept": "application/vnd.github+json"},
        )
        resp.raise_for_status()
        release = resp.json()
    except Exception as e:
        print(f"[auto-update] Check failed: {e}")
        return None

    latest_tag = release.get("tag_name", "").lstrip("v")
    if not latest_tag:
        return None

    # Compare versions (simple semver comparison)
    if _compare_versions(latest_tag, current) <= 0:
        return None  # Already up-to-date

    # Find the right asset for this platform
    assets = release.get("assets", [])
    download_url = None
    asset_size = 0

    # Determine the expected asset name
    system = platform.system().lower()
    arch = "x64" if platform.machine().endswith("64") else "x86"

    for asset in assets:
        name = asset.get("name", "").lower()
        if system == "windows" and ("setup" in name or "installer" in name):
            if arch in name or name.endswith(".exe"):
                download_url = asset.get("browser_download_url")
                asset_size = asset.get("size", 0)
                break
        elif system == "darwin" and (".dmg" in name or "macos" in name):
            download_url = asset.get("browser_download_url")
            asset_size = asset.get("size", 0)
            break
        elif system == "linux" and (".appimage" in name or "linux" in name):
            download_url = asset.get("browser_download_url")
            asset_size = asset.get("size", 0)
            break

    # Fallback to main download page if no direct asset found
    if not download_url:
        download_url = release.get("html_url", GITHUB_DOWNLOAD)

    return {
        "version": latest_tag,
        "download_url": download_url,
        "changelog": release.get("body", ""),
        "size": asset_size,
        "current_version": current,
    }


def download_update(
    update_info: dict,
    progress_callback: Optional[Callable[[float], None]] = None,
) -> Optional[Path]:
    """
    Download the update file.

    Args:
        update_info: Dict from check_for_update()
        progress_callback: Called with download progress (0.0 to 1.0)

    Returns:
        Path to the downloaded file, or None on failure.
    """
    import requests

    UPDATE_DIR.mkdir(parents=True, exist_ok=True)

    url = update_info["download_url"]
    filename = url.split("/")[-1]
    dest = UPDATE_DIR / filename

    if dest.exists():
        # Already downloaded
        if progress_callback:
            progress_callback(1.0)
        return dest

    try:
        resp = requests.get(url, stream=True, timeout=30)
        resp.raise_for_status()
        total = int(resp.headers.get("content-length", 0))
        downloaded = 0

        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0 and progress_callback:
                        progress_callback(downloaded / total)

        return dest
    except Exception as e:
        print(f"[auto-update] Download failed: {e}")
        if dest.exists():
            dest.unlink()
        return None


def apply_update(downloaded_file: Path) -> bool:
    """
    Apply the downloaded update.

    For Windows: Launch the installer and exit the current app.
    For portable: Extract and replace files.
    """
    system = platform.system().lower()

    if system == "windows":
        # Windows: Launch the installer and exit
        if downloaded_file.suffix.lower() == ".exe":
            try:
                subprocess.Popen(
                    [str(downloaded_file), "/SILENT", "--update"],
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW,
                )
                # Give the installer a moment to start
                import time
                time.sleep(2)
                # Exit the current app so the installer can overwrite files
                sys.exit(0)
            except Exception as e:
                print(f"[auto-update] Failed to launch installer: {e}")
                return False
        else:
            # ZIP archive: extract and replace
            return _apply_portable_update(downloaded_file)

    elif system == "darwin":
        # macOS: Open the DMG
        try:
            subprocess.Popen(["open", str(downloaded_file)])
            sys.exit(0)
        except Exception as e:
            print(f"[auto-update] Failed to open DMG: {e}")
            return False

    elif system == "linux":
        # Linux: AppImage — replace the current AppImage
        try:
            current_exe = Path(sys.executable)
            shutil.move(str(downloaded_file), str(current_exe))
            os.chmod(str(current_exe), 0o755)
            # Restart
            os.execv(str(current_exe), [str(current_exe)] + sys.argv[1:])
        except Exception as e:
            print(f"[auto-update] Failed to apply update: {e}")
            return False

    return False


def _apply_portable_update(zip_file: Path) -> bool:
    """Apply an update from a ZIP archive (portable distribution)."""
    install_dir = get_install_dir()
    backup_dir = install_dir.parent / f"{install_dir.name}.backup"

    try:
        # Backup current installation
        if install_dir.exists():
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            shutil.move(str(install_dir), str(backup_dir))

        # Extract new version
        with zipfile.ZipFile(zip_file, "r") as zf:
            zf.extractall(install_dir.parent)

        # Remove backup
        if backup_dir.exists():
            shutil.rmtree(backup_dir)

        # Restart
        new_exe = install_dir / "GenericAgent.exe"
        if new_exe.exists():
            subprocess.Popen([str(new_exe)])
            sys.exit(0)

        return True
    except Exception as e:
        print(f"[auto-update] Portable update failed: {e}")
        # Restore backup
        if backup_dir.exists() and not install_dir.exists():
            shutil.move(str(backup_dir), str(install_dir))
        return False


def _compare_versions(v1: str, v2: str) -> int:
    """Compare two semver version strings. Returns 1 if v1 > v2, -1 if v1 < v2, 0 if equal."""
    def parse(v):
        parts = []
        for p in v.split("."):
            try:
                parts.append(int(p))
            except ValueError:
                parts.append(0)
        return parts

    p1, p2 = parse(v1), parse(v2)
    for a, b in zip(p1, p2):
        if a > b:
            return 1
        if a < b:
            return -1
    if len(p1) > len(p2):
        return 1
    if len(p1) < len(p2):
        return -1
    return 0


def save_update_state(state: dict):
    """Save update state to disk."""
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


def load_update_state() -> dict:
    """Load update state from disk."""
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {}


def check_and_notify_async(
    callback: Optional[Callable[[Optional[dict]], None]] = None,
):
    """
    Check for updates in a background thread.

    Args:
        callback: Called with update info when check completes.
                  None means no update available or check failed.
    """
    def _check():
        result = check_for_update()
        if callback:
            callback(result)

    thread = threading.Thread(target=_check, daemon=True)
    thread.start()


# ═══════════════════════════════════════════════════════════════════════════
#  Qt Integration (for the desktop app)
# ═══════════════════════════════════════════════════════════════════════════

def create_update_dialog(parent=None):
    """
    Create a Qt dialog for checking and applying updates.
    Returns a QWidget that can be shown in the settings page.
    """
    try:
        from PySide6.QtWidgets import (
            QWidget, QVBoxLayout, QLabel, QPushButton,
            QProgressBar, QHBoxLayout, QTextEdit,
        )
        from PySide6.QtCore import Qt, QTimer, Signal, QObject
    except ImportError:
        return None

    class UpdateSignaler(QObject):
        update_found = Signal(dict)
        update_progress = Signal(float)
        update_error = Signal(str)
        check_complete = Signal()

    signaler = UpdateSignaler()

    widget = QWidget()
    layout = QVBoxLayout(widget)

    # Version label
    current_ver = get_current_version()
    ver_label = QLabel(f"Current version: {current_ver}")
    ver_label.setStyleSheet("font-weight: bold; font-size: 14px;")
    layout.addWidget(ver_label)

    # Status label
    status = QLabel("Checking for updates...")
    layout.addWidget(status)

    # Progress bar (hidden initially)
    progress = QProgressBar()
    progress.setVisible(False)
    layout.addWidget(progress)

    # Changelog (hidden initially)
    changelog = QTextEdit()
    changelog.setReadOnly(True)
    changelog.setMaximumHeight(150)
    changelog.setVisible(False)
    changelog.setPlaceholderText("Changelog will appear here when an update is found.")
    layout.addWidget(changelog)

    # Buttons
    btn_layout = QHBoxLayout()
    check_btn = QPushButton("Check for Updates")
    update_btn = QPushButton("Download & Install Update")
    update_btn.setVisible(False)
    update_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 8px 16px;")
    btn_layout.addWidget(check_btn)
    btn_layout.addWidget(update_btn)
    btn_layout.addStretch()
    layout.addLayout(btn_layout)

    # State
    update_info = [None]  # Use list for mutation in closures

    def on_check():
        status.setText("Checking for updates...")
        check_btn.setEnabled(False)

        def on_result(info):
            signaler.update_found.emit(info) if info else signaler.check_complete.emit()

        check_and_notify_async(on_result)

    def on_update_found(info):
        update_info[0] = info
        status.setText(f"Update available: v{info['version']} (current: v{info['current_version']})")
        status.setStyleSheet("color: #4CAF50; font-weight: bold;")
        update_btn.setVisible(True)

        if info.get("changelog"):
            changelog.setVisible(True)
            changelog.setMarkdown(info["changelog"])

        check_btn.setEnabled(True)

    def on_check_complete():
        status.setText("You are running the latest version.")
        status.setStyleSheet("color: #2196F3;")
        check_btn.setEnabled(True)

    def on_download():
        if not update_info[0]:
            return

        update_btn.setEnabled(False)
        status.setText("Downloading update...")
        progress.setVisible(True)
        progress.setValue(0)

        def on_progress(p):
            signaler.update_progress.emit(p)

        def download_thread():
            path = download_update(update_info[0], on_progress)
            if path:
                signaler.update_progress.emit(1.0)
                # Apply after a brief delay
                import time
                time.sleep(1)
                apply_update(path)
            else:
                signaler.update_error.emit("Download failed")

        threading.Thread(target=download_thread, daemon=True).start()

    def on_progress(p):
        progress.setValue(int(p * 100))

    def on_error(msg):
        status.setText(f"Update failed: {msg}")
        status.setStyleSheet("color: #F44336;")
        progress.setVisible(False)
        update_btn.setEnabled(True)

    # Connect signals
    signaler.update_found.connect(on_update_found)
    signaler.check_complete.connect(on_check_complete)
    signaler.update_progress.connect(on_progress)
    signaler.update_error.connect(on_error)
    check_btn.clicked.connect(on_check)
    update_btn.clicked.connect(on_download)

    # Auto-check on creation
    QTimer.singleShot(2000, on_check)

    return widget
