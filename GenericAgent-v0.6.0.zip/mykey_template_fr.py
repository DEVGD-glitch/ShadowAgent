# ══════════════════════════════════════════════════════════════════════════════
#  GenericAgent — Fichier de configuration (copier vers mykey.py et remplir)
#  Version française — Guide pas-à-pas pour les non-développeurs
# ══════════════════════════════════════════════════════════════════════════════
#
#  COMMENT ÇA MARCHE :
#    1. Copiez ce fichier et renommez-le en "mykey.py"
#    2. Décommentez (enlevez le # au début) UNE des configurations ci-dessous
#    3. Remplissez votre clé API à l'endroit indiqué
#    4. Lancez l'application avec start.bat ou python launch.pyw
#
#  QU'EST-CE QU'UNE CLÉ API ?
#    C'est comme un mot de passe qui permet à GenericAgent de parler à l'IA.
#    Vous devez en obtenir une auprès du fournisseur d'IA (OpenAI, Anthropic, etc.)
#    - OpenAI (GPT) : https://platform.openai.com/api-keys
#    - Anthropic (Claude) : https://console.anthropic.com/settings/keys
#    - Autres : voir les liens ci-dessous dans chaque section
#
#  COMMENT GENERICAGENT CHOISIT LA CONNEXION :
#    Le nom de la variable détermine le type de connexion :
#      nom contient 'native' + 'claude' → Connexion native Anthropic (recommandé)
#      nom contient 'native' + 'oai'    → Connexion native OpenAI (recommandé)
#      nom contient 'mixin'             → Basculement automatique entre plusieurs IA
#
# ══════════════════════════════════════════════════════════════════════════════


# ── LANGUE DE L'APPLICATION ──────────────────────────────────────────────────
#  "fr" = Français, "en" = English, "zh" = 中文
GA_LANG = "fr"


# ── 1. Connexion Anthropic Claude (recommandé) ──────────────────────────────
#  Le meilleur rapport qualité/prix pour l'utilisation avec les outils.
#  Obtenez votre clé : https://console.anthropic.com/settings/keys
#  La clé commence par "sk-ant-"
#
#  Modèles disponibles :
#    - claude-opus-4-7    : Le plus puissant, pour les tâches complexes
#    - claude-sonnet-4-6  : Bon équilibre performance/prix
#
#  Ajoutez [1m] après le nom du modèle pour activer le contexte 1 million :
#    'claude-opus-4-7[1m]'

native_claude_config = {
    'name': 'claude',                         # Nom d'affichage (utilisé par mixin)
    'apikey': 'sk-ant-VOTRE-CLE-ICI',         # ← Collez votre clé Anthropic ici
    'apibase': 'https://api.anthropic.com',   # L'adresse du serveur Anthropic
    'model': 'claude-sonnet-4-6',             # Modèle à utiliser
    'thinking_type': 'adaptive',              # 'adaptive' = l'IA réfléchit quand nécessaire
    # 'thinking_budget_tokens': 32768,        # Requis si thinking_type='enabled'
    # 'max_retries': 3,                       # Nombre de tentatives en cas d'erreur
    # 'read_timeout': 180,                    # Délai d'attente max en secondes
}


# ── 2. Connexion OpenAI GPT ─────────────────────────────────────────────────
#  Fonctionne aussi avec tout fournisseur compatible OpenAI.
#  Obtenez votre clé : https://platform.openai.com/api-keys
#  La clé commence par "sk-"

# native_oai_config = {
#     'name': 'gpt',                            # Nom d'affichage
#     'apikey': 'sk-VOTRE-CLE-ICI',             # ← Collez votre clé OpenAI ici
#     'apibase': 'https://api.openai.com/v1',   # Adresse du serveur OpenAI
#     'model': 'gpt-5.4',                        # ou 'o4', 'gpt-5.3-codex', etc.
#     'api_mode': 'chat_completions',            # ou 'responses' pour la nouvelle API
#     # 'reasoning_effort': 'high',              # none|minimal|low|medium|high|xhigh
#     # 'max_retries': 3,
#     # 'read_timeout': 120,
# }


# ── 3. Basculement automatique (Mixin) — optionnel ──────────────────────────
#  Si une IA ne répond pas, l'autre prend le relais automatiquement.
#  Pratique pour éviter les interruptions !
#  Contrainte : toutes les sessions doivent être de type "Native"
#
#  Pour l'activer :
#    1. Décommentez native_claude_config ET native_oai_config ci-dessus
#    2. Remplissez les clés API pour les deux
#    3. Décommentez la section ci-dessous

# mixin_config = {
#     'llm_nos': ['claude', 'gpt'],    # Noms des IA à utiliser (dans l'ordre)
#     'max_retries': 5,                 # Tentatives max avant abandon
#     'base_delay': 0.5,                # Délai initial entre les tentatives (secondes)
# }


# ── 4. Proxy HTTP (optionnel) ────────────────────────────────────────────────
#  Si vous êtes derrière un proxy d'entreprise ou utilisez un VPN.
#  S'applique à toutes les connexions qui n'ont pas leur propre proxy.

# proxy = 'http://127.0.0.1:7890'


# ── 5. Intégrations messageries (optionnel) ──────────────────────────────────
#  Pour utiliser GenericAgent via Telegram, etc.
#  Décommentez et remplissez uniquement si vous en avez besoin.

# tg_bot_token = 'VOTRE-TOKEN-TELEGRAM'
# tg_allowed_users = [123456789]   # Votre ID utilisateur Telegram
