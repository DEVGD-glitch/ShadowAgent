<div align="center">
<img src="assets/images/bar.jpg" width="880"/>

<a href="https://trendshift.io/repositories/25944" target="_blank"><img src="https://trendshift.io/api/badge/repositories/25944" alt="lsdefine%2FGenericAgent | Trendshift" style="width: 250px; height: 55px;" width="250" height="55"/></a>

</div>

<p align="center">
  <a href="#english">English</a> | <a href="#chinese">中文</a> | <a href="#french">Français</a> | 📄 Technical Report:&nbsp;<a href="https://arxiv.org/abs/2604.17091"><img src="https://img.shields.io/badge/arXiv-2604.17091-b31b1b?logo=arxiv&logoColor=white" alt="arXiv" height="18"/></a>&nbsp;<a href="assets/GenericAgent_Technical_Report.pdf"><img src="https://img.shields.io/badge/-PDF-EA4335?logo=adobeacrobatreader&logoColor=white" alt="Technical Report PDF" height="18"/></a>&nbsp;<a href="https://github.com/JinyiHan99/GA-Technical-Report"><img src="https://img.shields.io/badge/-Code%20%26%20Data-181717?logo=github&logoColor=white" alt="Experiments & Reproduction Repo" height="18"/></a> | 📘 <a href="https://datawhalechina.github.io/hello-generic-agent/">教程</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/version-0.6.0-blue" alt="Version 0.6.0"/>
  <img src="https://img.shields.io/badge/tests-1020%20passed-brightgreen" alt="1020 Tests"/>
  <img src="https://img.shields.io/badge/python-3.10%2B-blue" alt="Python 3.10+"/>
  <img src="https://img.shields.io/badge/license-MIT-green" alt="MIT License"/>
</p>

> 📌 **Official channel**: This GitHub repository is the sole official source for GenericAgent. We have no affiliation with any third-party website using the GenericAgent name.

---
<a name="english"></a>
## 🌟 Overview

**GenericAgent** is a minimal, self-evolving autonomous agent framework. Its core is just **~3K lines of code**. Through **9 atomic tools + a ~100-line Agent Loop**, it grants any LLM system-level control over a local computer — covering browser, terminal, filesystem, keyboard/mouse input, screen vision, and mobile devices (ADB).

Its design philosophy: **don't preload skills — evolve them.**

Every time GenericAgent solves a new task, it automatically crystallizes the execution path into a skill for direct reuse later. The longer you use it, the more skills accumulate — forming a skill tree that belongs entirely to you, grown from 3K lines of seed code.

> **🤖 Self-Bootstrap Proof** — Everything in this repository, from installing Git and running `git init` to every commit message, was completed autonomously by GenericAgent. The author never opened a terminal once.

## 📋 Core Features
- **Self-Evolving**: Automatically crystallizes each task into a skill. Capabilities grow with every use, forming your personal skill tree.
- **Minimal Architecture**: ~3K lines of core code. Agent Loop is ~100 lines. No complex dependencies, zero deployment overhead.
- **Strong Execution**: Injects into a real browser (preserving login sessions). 9 atomic tools take direct control of the system.
- **High Compatibility**: Supports Claude / OpenAI / Gemini / DeepSeek / local models (Ollama). Cross-platform (Windows / macOS / Linux).
- **Token Efficient**: <30K context window — a fraction of the 200K–1M other agents consume. Layered memory ensures the right knowledge is always in scope. Less noise, fewer hallucinations, higher success rate — at a fraction of the cost.

## 🧟 Big Tech Monster — v0.6.0

GenericAgent v0.6.0 extracts the best patterns from 12 open-source AI agent frameworks, combining them into a unified, self-evolving agent platform.

### New Capabilities by Wave

| Wave | Feature | Inspired By | Key API |
|------|---------|-------------|---------|
| V1 | StateGraph Engine | LangGraph | `agent.build_state_graph()` |
| V1 | FastMCP Server | MCP Python SDK | `@agent.register_mcp_tool()` |
| V1 | Chroma Memory | ChromaDB | `agent.search_memory()` |
| V1 | Google AI Studio | Gemini API | `GoogleAISession` |
| V2 | Closed Learning Loop | Hermes Agent | `agent.closed_learning.run_full_cycle()` |
| V2 | Progressive Skill Disclosure | Google ADK | `SkillToolset` |
| V2 | Self-Nudge Persistence | Hermes Agent | `SelfNudge` |
| V3 | Agent Handoffs | OpenAI Agents SDK | `agent.agent_handoff` |
| V3 | Agent-as-Tool | OpenAI Agents SDK | `AgentAsTool` |
| V3 | Sandbox Execution | OpenAI Agents SDK | `SandboxExecutor` |
| V3 | Input/Output Guardrails | OpenAI Agents SDK | `agent.validate_input()` |
| V4 | Extension Lifecycle Hooks | pi-mono | `agent.extension_manager` |
| V4 | Context Compaction Engine | pi-mono | `agent.context_engine` |
| V4 | Flow Serialization | Langflow | `agent.create_flow()` |
| V4 | Flow-as-MCP-Server | Langflow | `FlowMCPServer` |
| V5 | DOM Intelligence | Browser-Use | `agent.browser_session` |
| V5 | Browser Agent | Browser-Use | `BrowserAgent` |
| V6 | Voice Pipeline | AIAvatarKit | `agent.enable_voice()` |
| V6 | VRM/VRoid Avatar | AIAvatarKit | `agent.enable_avatar()` |
| V6 | VRoid Hub Client | VRoid Hub | `VRoidHubClient` |
| V6 | Speech-to-Speech | AIAvatarKit | `SpeechToSpeechEngine` |

### Code Examples

```python
# Build a StateGraph workflow
graph = agent.build_state_graph()
graph.add_node("think", think_fn)
graph.add_node("act", act_fn)
graph.add_edge("think", "act")
graph.add_conditional_edges("act", route_fn, {"retry": "think", "done": "__end__"})
compiled = graph.compile(checkpointer=MemoryCheckpointer())

# Register MCP tools
@agent.register_mcp_tool()
def search_web(query: str, num: int = 10) -> str:
    """Search the web."""
    return do_search(query, num)

# Closed Learning Loop
result = agent.closed_learning.run_full_cycle("Analyze quarterly sales")

# Guardrails
agent.validate_input("Hello, help me code")  # GuardrailResult(passed=True)

# Voice pipeline
agent.enable_voice(stt_provider="google", tts_provider="voicevox")
agent.enable_avatar(avatar_path="avatar.vrm")
```

## 🚀 What's New in v0.5.0 — Auto-Crystallization & Production Hardening

Version 0.5.0 builds on the 8 superpowers from v0.4.0 with a **fully automatic skill crystallization engine** and **production-grade hardening** across all modules:

### 🧬 Auto-Crystallization Engine

The centerpiece of v0.5.0: the agent now **automatically crystallizes task execution paths into reusable skills** without any manual intervention. After 15+ conversation turns, the engine injects `start_long_term_update` into the done-hooks, triggering a cascade of memory operations:

| Feature | Description |
|---------|-------------|
| **Auto-Trigger** | After 15+ turns, automatically prompts the agent to crystallize the current execution path into a skill |
| **L1 Auto-Sync** | When a new SOP is written to memory, the L1 insight index updates automatically for fast routing |
| **Working Checkpoint Persistence** | Key information checkpoints are saved to disk and restored on next session start |
| **RAG Auto-Indexing** | New SOPs are automatically indexed in the VectorStore for semantic retrieval |
| **Crystallization Metrics** | Track crystallization events, success rates, and memory growth over time |
| **MemoryWriteObserver** | File-system watcher detects writes to `memory/` and triggers L1 sync + RAG indexing |

```python
# Auto-crystallization is transparent — just use the agent normally
agent = GenericAgent()
agent.put_task("Monitor stocks and alert me when price drops 5%")
# After 15+ turns, the engine automatically:
# 1. Triggers skill crystallization
# 2. Updates the L1 insight index
# 3. Persists working checkpoints
# 4. Indexes the new SOP in VectorStore
# Next time: "one-line invoke" from memory
```

### 🛡️ Production Hardening (Loop 2 + Loop 3 Fixes)

A comprehensive line-by-line code review (Loop 2) identified 52 issues, and all critical and moderate issues were fixed in Loop 3:

| Fix | Impact | Details |
|-----|--------|---------|
| **Empty LLM clients guard** | 🔴 Critical | Prevents `IndexError` crash when no LLM provider is configured |
| **History deep-copy** | 🔴 Critical | History was shared by reference across sessions — caused cross-session data corruption |
| **JSON schema fix** | 🔴 Critical | Missing closing braces in `start_long_term_update` tool definition caused 23 test failures |
| **`_clean_content` bug** | 🔴 Critical | `"\\n" in pattern` always evaluated to `False` — was checking literal backslash-n instead of actual newline |
| **`tryparse` exception safety** | 🟡 Moderate | Final `json.loads` could raise unhandled exception — now returns `{"_raw": text}` fallback |
| **PowerShell→Bash regex** | 🟡 Moderate | Naive `replace("powershell", "bash")` corrupted JSON descriptions — targeted regex only affects enum values |
| **Lambda → def** | 🟡 Moderate | `is_native = lambda s:` replaced with `def _is_native(s):` for PEP 8 compliance |
| **Magic number** | 🟢 Minor | `9000` replaced with named constant `_TOKEN_COST_REFRESH_THRESHOLD` |
| **Retry yield removal** | 🟢 Minor | `yield err` during retry loop removed — partial error messages confused users |

## 🚀 What's New in v0.4.0 — Superpowers

Version 0.4.0 transforms GenericAgent from a well-structured desktop agent into a **platform-grade AI agent system** with 8 major new capabilities:

### 1. 🔌 Dynamic Tool Plugin System
Register new tools at runtime with a simple decorator. No need to modify core code — just drop a Python file into `plugins/tools/` and it's auto-discovered.

```python
from tools import register_tool

@register_tool(
    name="web_search",
    description="Search the web for information",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
        },
        "required": ["query"],
    },
)
def do_web_search(args: dict, response) -> dict:
    # Your implementation here
    return {"status": "success", "results": [...]}
```

### 2. 🔗 MCP Client (Model Context Protocol)
Connect to any MCP-compatible tool server using Anthropic's open standard. Supports stdio, SSE, and HTTP transports.

```json
// mcp_config.json
{
  "servers": {
    "filesystem": {
      "transport": "stdio",
      "command": "npx",
      "args": ["@modelcontextprotocol/server-filesystem", "/tmp"],
      "enabled": false
    }
  }
}
```

### 3. 🧠 Vector Memory / RAG
Semantic search over the agent's memory and documents using embedding-based retrieval. Enables far more accurate context recall than file-based SOPs alone.

```python
from memory.vector import VectorStore, RAGEngine, MemoryIndexer

store = VectorStore(dimension=1536)
engine = RAGEngine(vector_store=store)
results = engine.search("How did I automate stock screening?")
```

### 4. 🤝 Multi-Agent Orchestration
Route complex tasks to specialist agents (Coder, Researcher, Analyst, Writer, System) with automatic handoff and pipeline execution.

```python
from agentmain.orchestrator import Orchestrator

orch = Orchestrator(agent)
result = orch.route("Analyze the stock market data and write a report")
# → Routes to: Analyst → Writer
```

### 5. 🌐 FastAPI Server (REST + SSE + WebSocket)
Expose the agent as an HTTP/WebSocket API for integration with any frontend or service.

```bash
python server.py  # Starts on http://0.0.0.0:8765
```

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/chat` | POST | Streaming SSE chat |
| `/chat/sync` | POST | Synchronous chat |
| `/ws/chat` | WebSocket | Full-duplex chat |
| `/tools` | GET | List available tools |
| `/models` | GET | List LLM models |
| `/memory/search` | POST | Semantic memory search |
| `/mcp/status` | GET | MCP server status |

### 6. 💭 Advanced Reasoning Patterns
Three reasoning modes that the agent can switch between based on task complexity:

| Mode | Description | Best For |
|------|-------------|----------|
| **ReAct** | Reason + Act iteratively | General tasks with uncertainty |
| **Plan-and-Execute** | Plan first, then execute steps | Complex multi-step tasks |
| **Self-Reflection** | Execute, then critique and improve | Tasks requiring quality checks |

### 7. ✅ Tool Argument Validation
JSON Schema validation with type coercion ensures tool arguments are always well-formed before execution.

### 8. 🛠️ Native Tool Plugins
Three built-in plugins ready to use:
- **web_search** — DuckDuckGo / SearXNG web search
- **memory_search / memory_index** — Semantic memory search and document indexing
- **system_info / directory_tree / list_processes** — System introspection tools

### 9. 🎨 Modern Qt Desktop UI
A completely revamped desktop interface with:

| Feature | Description |
|---------|-------------|
| **ToolCallWidget** | Real-time tool call visualization with status badges (pending/success/error) |
| **ThinkingSection** | Collapsible agent reasoning display |
| **AgentStatusBar** | Animated status indicator (6 states: idle, thinking, acting, waiting, error, streaming) |
| **ApprovalDialog** | Security approval for dangerous actions (4 risk levels) |
| **CommandPalette** | VS Code-style Ctrl+K command palette with fuzzy search |
| **Multi-Theme** | Dark, Light, and Catppuccin themes |
| **System Tray** | Background mode with notifications |
| **Drag & Drop** | Drop files directly into the chat |

## 🧬 Self-Evolution Mechanism

This is what fundamentally distinguishes GenericAgent from every other agent framework.

```
[New Task] --> [Autonomous Exploration] (install deps, write scripts, debug & verify) -->
[Crystallize Execution Path into skill] --> [Write to Memory Layer] --> [Direct Recall on Next Similar Task]
```

| What you say | What the agent does the first time | Every time after |
|---|---|---|
| *"Read my WeChat messages"* | Install deps → reverse DB → write read script → save skill | **one-line invoke** |
| *"Monitor stocks and alert me"* | Install mootdx → build selection flow → configure cron → save skill | **one-line start** |
| *"Send this file via Gmail"* | Configure OAuth → write send script → save skill | **ready to use** |

After a few weeks, your agent instance will have a skill tree no one else in the world has — all grown from 3K lines of seed code.


##### 🎯 Demo Showcase

| 🧋 Food Delivery Order | 📈 Quantitative Stock Screening |
|:---:|:---:|
| <img src="assets/demo/order_tea.gif" width="100%" alt="Order Tea"> | <img src="assets/demo/selectstock.gif" width="100%" alt="Stock Selection"> |
| *"Order me a milk tea"* — Navigates the delivery app, selects items, and completes checkout automatically. | *"Find GEM stocks with EXPMA golden cross, turnover > 5%"* — Screens stocks with quantitative conditions. |
| 🌐 Autonomous Web Exploration | 💰 Expense Tracking | 💬 Batch Messaging |
| <img src="assets/demo/autonomous_explore.png" width="100%" alt="Web Exploration"> | <img src="assets/demo/alipay_expense.png" width="100%" alt="Alipay Expense"> | <img src="assets/demo/wechat_batch.png" width="100%" alt="WeChat Batch"> |
| Autonomously browses and periodically summarizes web content. | *"Find expenses over ¥2K in the last 3 months"* — Drives Alipay via ADB. | Sends bulk WeChat messages, fully driving the WeChat client. |

## 📅 Latest News

- **2026-05-04:** 🧟 **v0.6.0 released** — "Big Tech Monster": 21 new features across 6 waves, inspired by 12 open-source frameworks (LangGraph, MCP SDK, ChromaDB, Hermes, OpenAI Agents SDK, pi-mono, Langflow, Browser-Use, AIAvatarKit, VRoid Hub, Google ADK, Gemini API), 1020 tests passing
- **2026-05-03:** 🚀 **v0.5.0 released** — Auto-crystallization engine (6 features), production hardening (10 critical/moderate fixes from line-by-line code review), 952 tests passing
- **2026-05-02:** 🚀 **v0.4.0 released** — 8 superpowers: dynamic tool plugins, MCP client, vector memory/RAG, multi-agent orchestration, FastAPI server, advanced reasoning, tool validation, native plugins + modern Qt UI
- **2026-04-21:** 📄 [Technical Report released on arXiv](https://arxiv.org/abs/2604.17091) — *GenericAgent: A Token-Efficient Self-Evolving LLM Agent via Contextual Information Density Maximization*
- **2026-04-11:** Introduced **L4 session archive memory** and scheduler cron integration
- **2026-03-23:** Support personal WeChat as a bot frontend
- **2026-03-10:** [Released million-scale Skill Library](https://mp.weixin.qq.com/s/q2gQ7YvWoiAcwxzaiwpuiQ?scene=1&click_id=7)
- **2026-03-08:** [Released "Dintal Claw" — a GenericAgent-powered government affairs bot](https://mp.weixin.qq.com/s/eiEhwo-j6S-WpLxgBnNxBg)
- **2026-03-01:** [GenericAgent featured by Jiqizhixin (机器之心)](https://mp.weixin.qq.com/s/uVWpTTF5I1yzAENV_qm7yg)
- **2026-01-16:** GenericAgent V1.0 public release

---

## 🚀 Quick Start

#### Method 1: Standard Installation

```bash
# 1. Clone the repo
git clone https://github.com/lsdefine/GenericAgent.git
cd GenericAgent

# 2. Install minimal dependencies
pip install requests streamlit pywebview

# 3. Configure API Key
cp mykey_template.py mykey.py
# Edit mykey.py and fill in your LLM API Key

# 4. Launch
python launch.pyw
```

#### Method 2: uv (for experienced Python users)

```bash
git clone https://github.com/lsdefine/GenericAgent.git
cd GenericAgent
uv pip install -e ".[qt]"          # Core + Qt desktop UI
cp mykey_template.py mykey.py
python frontends/qtapp.py
```

#### Method 3: Docker (headless / server mode)

```bash
docker build -t genericagent .
docker run -e LLM_API_KEY=sk-... genericagent
```

#### Method 4: API Server mode

```bash
pip install fastapi uvicorn sse-starlette
python server.py   # Starts on http://0.0.0.0:8765
```

> GenericAgent is meant to grow its environment through the Agent itself, not by pre-installing every possible package.

Full guide: [GETTING_STARTED.md](GETTING_STARTED.md)

---

## 🏗️ Architecture

```
GenericAgent/
├── agent_loop.py              # ~100-line core execution loop
├── ga.py                      # 9 atomic tools + GenericAgentHandler
├── server.py                  # FastAPI + SSE + WebSocket API
├── config.py                  # Centralized configuration (3 dataclasses)
├── exceptions.py              # 28-class typed exception hierarchy
├── protocols.py               # 4 Protocol classes + LLMProvider enum
├── circuit_breaker.py         # LLM call circuit breaker (3 states)
├── metrics.py                 # LLM metrics singleton (tokens, latency, errors)
├── logging_config.py          # Centralized logging with ColoredFormatter
├── env_loader.py              # .env file support with manual fallback
├── agentmain/                 # Agent core package (14 modules)
│   ├── core.py                # GenericAgent class, LLM session management
│   ├── cli.py                 # CLI entry point, argparse, modes
│   ├── prompts.py             # Tool schemas, system prompts, memory init
│   ├── slash.py               # Slash command handler
│   ├── orchestrator.py        # Multi-agent orchestration (5 specialists)
│   ├── reasoning.py           # ReAct, Plan-Execute, Self-Reflection
│   ├── handoffs.py            # Agent handoffs + Agent-as-Tool (v0.6.0)
│   ├── guardrails.py          # Input/Output guardrails (v0.6.0)
│   ├── closed_learning.py     # Closed learning loop (v0.6.0)
│   ├── extensions.py          # Extension lifecycle hooks (v0.6.0)
│   ├── flow.py                # Flow serialization + Flow-as-MCP (v0.6.0)
│   ├── browser_intel.py       # DOM intelligence + Browser Agent (v0.6.0)
│   ├── voice_avatar.py        # Voice pipeline + VRM avatar (v0.6.0)
│   └── auto_update.py         # GitHub Releases auto-update system
├── llmcore/                   # LLM abstraction layer (10 modules)
│   ├── clients.py             # Multi-LLM client (Claude, OpenAI, Gemini...)
│   ├── google_provider.py     # Google AI Studio session (v0.6.0)
│   ├── sessions.py            # Session management with failover
│   ├── parsers.py             # SSE/JSON response parsing
│   ├── messages.py            # Message format conversion & compression
│   ├── retry.py               # Retry with exponential backoff + jitter
│   ├── convert.py             # Tool format converters (OpenAI ↔ Claude)
│   ├── config.py              # Config loading (mykeys)
│   └── utils.py               # safeprint, auto_make_url, thinking prompts
├── tools/                     # Dynamic tool plugin system
│   ├── registry.py            # ToolRegistry + @register_tool decorator
│   └── validation.py          # JSON Schema validation with type coercion
├── mcp/                       # Model Context Protocol
│   ├── client.py              # MCP client with stdio/SSE/HTTP transport
│   └── fastmcp.py             # FastMCP server (v0.6.0)
├── engine/                    # StateGraph engine (v0.6.0)
│   └── state_graph.py         # StateGraph, nodes, edges, checkpointer
├── memory/                    # Layered memory system
│   ├── crystallization.py     # Auto-crystallization engine (6 features)
│   ├── vector/                # Vector store + RAG + Chroma (v0.6.0)
│   │   ├── store.py           # VectorStore + EmbeddingEngine
│   │   └── rag.py             # RAGEngine + MemoryIndexer
│   └── (L0-L4 memory layers)  # SOPs, skills, session archives
├── plugins/tools/             # Native tool plugins
│   ├── web_search.py          # DuckDuckGo / SearXNG search
│   ├── memory_search.py       # Semantic memory search + index
│   └── system_tools.py        # System info, directory tree, processes
├── i18n/                      # Internationalization (EN, FR, ZH)
├── frontends/                 # Multiple frontend interfaces
│   ├── qt/                    # Modern Qt desktop UI (modular)
│   │   ├── widgets.py         # ToolCallWidget, ThinkingSection, AgentStatusBar, ApprovalDialog
│   │   ├── command_palette.py # VS Code-style Ctrl+K palette
│   │   ├── theme.py           # Multi-theme (dark/light/catppuccin)
│   │   ├── session_manager.py # Session logic (pure Python)
│   │   ├── stream_handler.py  # Stream logic (pure Python)
│   │   └── pages/             # Chat, History, SOP, Settings pages
│   ├── qtapp.py               # Qt desktop app (thin orchestrator)
│   ├── stapp.py / stapp2.py   # Streamlit web UI
│   ├── tgapp.py               # Telegram bot
│   ├── wechatapp.py           # WeChat bot
│   ├── qqapp.py               # QQ bot
│   ├── fsapp.py               # Feishu (Lark) bot
│   ├── wecomapp.py            # WeCom bot
│   └── dingtalkapp.py         # DingTalk bot
├── stubs/                     # Type stubs (TMWebDriver, simphtml)
├── tests/                     # 1020 tests (17 test files)
└── mcp_config.json            # MCP server configuration
```

---

## 🤖 Bot Interface (Optional)

### Telegram Bot

```python
# mykey.py
tg_bot_token = 'YOUR_BOT_TOKEN'
tg_allowed_users = [YOUR_USER_ID]
```

```bash
python frontends/tgapp.py
```

### Alternative App Frontends

Besides the default Streamlit web UI, you can also try other frontend styles:

```bash
python frontends/qtapp.py                # Qt-based desktop app (recommended)
streamlit run frontends/stapp2.py        # Alternative Streamlit UI
```

### Common Chat Commands

The default Streamlit desktop UI started by `python launch.pyw`, plus the QQ / Telegram / Feishu / WeCom / DingTalk frontends, support these chat commands:

- `/new` - start a fresh conversation and clear the current context
- `/continue` - list recoverable conversation snapshots
- `/continue N` - restore the `N`th recoverable conversation


## 📊 Comparison with Similar Tools

| Feature | GenericAgent | OpenClaw | Claude Code |
|------|:---:|:---:|:---:|
| **Codebase** | ~3K lines core | ~530,000 lines | Open-sourced (large) |
| **Deployment** | `pip install` + API Key | Multi-service orchestration | CLI + subscription |
| **Browser Control** | Real browser (session preserved) | Sandbox / headless browser | Via MCP plugin |
| **OS Control** | Mouse/kbd, vision, ADB | Multi-agent delegation | File + terminal |
| **Self-Evolution** | Autonomous skill growth | Plugin ecosystem | Stateless between sessions |
| **MCP Support** | Built-in client | Partial | Full |
| **Vector Memory / RAG** | Built-in | External | No |
| **Multi-Agent** | 5 specialist profiles | Native | No |
| **API Server** | Built-in (FastAPI + SSE) | External | No |
| **Advanced Reasoning** | ReAct, Plan-Execute, Self-Reflect | No | No |
| **Auto-Crystallization** | Built-in (v0.5.0) | No | No |
| **StateGraph** | Built-in (v0.6.0) | No | No |
| **MCP Server** | Built-in (v0.6.0) | No | No |
| **Chroma Memory** | Built-in (v0.6.0) | No | No |
| **Closed Learning** | Built-in (v0.6.0) | No | No |
| **Agent Handoffs** | Built-in (v0.6.0) | No | No |
| **Guardrails** | Built-in (v0.6.0) | No | No |
| **Extensions / Lifecycle Hooks** | Built-in (v0.6.0) | No | No |
| **Flow Serialization** | Built-in (v0.6.0) | No | No |
| **Browser Agent** | Built-in (v0.6.0) | No | No |
| **Voice Pipeline** | Built-in (v0.6.0) | No | No |
| **Avatar (VRM/VRoid)** | Built-in (v0.6.0) | No | No |
| **Circuit Breaker** | Built-in | No | No |
| **LLM Metrics** | Built-in | No | No |
| **Test Coverage** | 1020 tests | Unknown | Unknown |
| **Out of the Box** | A few core files + starter skills | Hundreds of modules | Rich CLI toolset |


## 🧠 How It Works

GenericAgent accomplishes complex tasks through **Layered Memory × Minimal Toolset × Autonomous Execution Loop**, continuously accumulating experience during execution.

1️⃣ **Layered Memory System**
> _Memory crystallizes throughout task execution, letting the agent build stable, efficient working patterns over time._

- **L0 — Meta Rules**: Core behavioral rules and system constraints of the agent
- **L1 — Insight Index**: Minimal memory index for fast routing and recall
- **L2 — Global Facts**: Stable knowledge accumulated over long-term operation
- **L3 — Task Skills / SOPs**: Reusable workflows for completing specific task types
- **L4 — Session Archive**: Archived task records distilled from finished sessions for long-horizon recall

2️⃣ **Autonomous Execution Loop**

> _Perceive environment state → Task reasoning → Execute tools → Write experience to memory → Loop_

The entire core loop is just **~100 lines of code** (`agent_loop.py`).

3️⃣ **Minimal Toolset**
> _GenericAgent provides only **9 atomic tools**, forming the foundational capabilities for interacting with the outside world._

| Tool | Function |
|------|------|
| `code_run` | Execute arbitrary code |
| `file_read` | Read files |
| `file_write` | Write files |
| `file_patch` | Patch / modify files |
| `web_scan` | Perceive web content |
| `web_execute_js` | Control browser behavior |
| `ask_user` | Human-in-the-loop confirmation |

> Additionally, 2 **memory management tools** (`update_working_checkpoint`, `start_long_term_update`) allow the agent to persist context and accumulate experience across sessions.

4️⃣ **Capability Extension Mechanism**
> _Capable of dynamically creating new tools._

Via `code_run`, GenericAgent can dynamically install Python packages, write new scripts, call external APIs, or control hardware at runtime — crystallizing temporary abilities into permanent tools.

<div align="center">
  <img src="assets/images/workflow.jpg" alt="GenericAgent Workflow" width="400"/>
  <br><em>GenericAgent Workflow Diagram</em>
</div>


## ⭐ Support

If this project helped you, please consider leaving a **Star!** 🙏

You're also welcome to join our **GenericAgent Community Group** for discussion, feedback, and co-building 👏

<div align="center">
  <table>
    <tr>
      <td align="center"><strong>WeChat Group 13</strong><br><img src="assets/images/wechat_group13.jpg" alt="WeChat Group 13 QR Code" width="250"/></td>
    </tr>
  </table>
</div>

## 🚩 Friendly Links

Thanks for the support from the LinuxDo community!

[![LinuxDo](https://img.shields.io/badge/社区-LinuxDo-blue?style=for-the-badge)](https://linux.do/)

## 📄 License

MIT License — see [LICENSE](LICENSE)

*Disclaimer: This project does not build or operate any commercial website. Apart from DintalClaw, no institution, organization, or individual is currently officially authorized to conduct commercial activities under the GenericAgent name.*


---
<a name="chinese"></a>
## 🌟 项目简介

**GenericAgent** 是一个极简、可自我进化的自主 Agent 框架。核心仅 **~3K 行代码**，通过 **9 个原子工具 + ~100 行 Agent Loop**，赋予任意 LLM 对本地计算机的系统级控制能力，覆盖浏览器、终端、文件系统、键鼠输入、屏幕视觉及移动设备。

它的设计哲学是：**不预设技能，靠进化获得能力。**

每解决一个新任务，GenericAgent 就将执行路径自动固化为 Skill，供后续直接调用。使用时间越长，沉淀的技能越多，形成一棵完全属于你、从 3K 行种子代码生长出来的专属技能树。

> **🤖 自举实证** — 本仓库的一切，从安装 Git、`git init` 到每一条 commit message，均由 GenericAgent 自主完成。作者全程未打开过一次终端。

## 📋 核心特性
- **自我进化**: 每次任务自动沉淀 Skill，能力随使用持续增长，形成专属技能树
- **极简架构**: ~3K 行核心代码，Agent Loop 约百行，无复杂依赖，部署零负担
- **强执行力**: 注入真实浏览器（保留登录态），9 个原子工具直接接管系统
- **高兼容性**: 支持 Claude / OpenAI / Gemini / DeepSeek / 本地模型（Ollama），跨平台运行
- **极致省 Token**: 上下文窗口不到 30K，是其他 Agent（200K–1M）的零头。分层记忆让关键信息始终在场——噪声更少，幻觉更低，成功率反而更高，而成本低一个数量级。

## 🧟 大厂怪兽 — v0.6.0

GenericAgent v0.6.0 从 12 个开源 AI Agent 框架中提取最佳模式，融合为统一的自我进化 Agent 平台。

### 按波次划分的新能力

| 波次 | 功能 | 灵感来源 | 关键 API |
|------|------|----------|----------|
| V1 | StateGraph 引擎 | LangGraph | `agent.build_state_graph()` |
| V1 | FastMCP 服务器 | MCP Python SDK | `@agent.register_mcp_tool()` |
| V1 | Chroma 记忆 | ChromaDB | `agent.search_memory()` |
| V1 | Google AI Studio | Gemini API | `GoogleAISession` |
| V2 | 闭环学习 | Hermes Agent | `agent.closed_learning.run_full_cycle()` |
| V2 | 渐进式技能披露 | Google ADK | `SkillToolset` |
| V2 | 自我驱动持久化 | Hermes Agent | `SelfNudge` |
| V3 | Agent 移交 | OpenAI Agents SDK | `agent.agent_handoff` |
| V3 | Agent 作为工具 | OpenAI Agents SDK | `AgentAsTool` |
| V3 | 沙箱执行 | OpenAI Agents SDK | `SandboxExecutor` |
| V3 | 输入/输出护栏 | OpenAI Agents SDK | `agent.validate_input()` |
| V4 | 扩展生命周期钩子 | pi-mono | `agent.extension_manager` |
| V4 | 上下文压缩引擎 | pi-mono | `agent.context_engine` |
| V4 | Flow 序列化 | Langflow | `agent.create_flow()` |
| V4 | Flow 即 MCP 服务器 | Langflow | `FlowMCPServer` |
| V5 | DOM 智能 | Browser-Use | `agent.browser_session` |
| V5 | 浏览器 Agent | Browser-Use | `BrowserAgent` |
| V6 | 语音管线 | AIAvatarKit | `agent.enable_voice()` |
| V6 | VRM/VRoid 虚拟形象 | AIAvatarKit | `agent.enable_avatar()` |
| V6 | VRoid Hub 客户端 | VRoid Hub | `VRoidHubClient` |
| V6 | 语音对语音 | AIAvatarKit | `SpeechToSpeechEngine` |

### 代码示例

```python
# 构建 StateGraph 工作流
graph = agent.build_state_graph()
graph.add_node("think", think_fn)
graph.add_node("act", act_fn)
graph.add_edge("think", "act")
graph.add_conditional_edges("act", route_fn, {"retry": "think", "done": "__end__"})
compiled = graph.compile(checkpointer=MemoryCheckpointer())

# 注册 MCP 工具
@agent.register_mcp_tool()
def search_web(query: str, num: int = 10) -> str:
    """搜索网页。"""
    return do_search(query, num)

# 闭环学习
result = agent.closed_learning.run_full_cycle("分析季度销售数据")

# 护栏
agent.validate_input("你好，帮我写代码")  # GuardrailResult(passed=True)

# 语音管线
agent.enable_voice(stt_provider="google", tts_provider="voicevox")
agent.enable_avatar(avatar_path="avatar.vrm")
```

## 🚀 v0.5.0 新特性 — 自动结晶引擎 & 生产级加固

v0.5.0 在 v0.4.0 的 8 大超能力基础上，新增**全自动技能结晶引擎**和**全模块生产级加固**：

### 🧬 自动结晶引擎

v0.5.0 的核心：Agent 现在**自动将任务执行路径结晶为可复用技能**，无需任何手动干预。15+ 轮对话后，引擎自动注入 `start_long_term_update`，触发一系列记忆操作：

| 特性 | 说明 |
|------|------|
| **自动触发** | 15+ 轮后自动提示 Agent 结晶当前执行路径为技能 |
| **L1 自动同步** | 写入新 SOP 时，L1 索引自动更新 |
| **检查点持久化** | 关键信息检查点保存到磁盘，下次启动自动恢复 |
| **RAG 自动索引** | 新 SOP 自动索引到 VectorStore |
| **结晶指标** | 追踪结晶事件、成功率和记忆增长 |
| **文件监控** | 检测 `memory/` 写入，触发 L1 同步 + RAG 索引 |

### 🛡️ 生产级加固（代码审查 + 修复）

逐行代码审查发现 52 个问题，所有关键和中度问题均已修复：

| 修复 | 影响 | 详情 |
|------|------|------|
| **空 LLM 客户端防护** | 🔴 关键 | 防止无 LLM 提供者时的 `IndexError` 崩溃 |
| **历史记录深拷贝** | 🔴 关键 | 历史记录按引用共享导致跨会话数据污染 |
| **JSON Schema 修复** | 🔴 关键 | `start_long_term_update` 缺少闭合括号 |
| **`_clean_content` 修复** | 🔴 关键 | `"\\n" in pattern` 始终为 `False` |
| **`tryparse` 异常安全** | 🟡 中度 | 最终 `json.loads` 可抛出未处理异常 |
| **PowerShell→Bash 正则** | 🟡 中度 | 简单替换损坏 JSON 描述 → 精确正则仅替换枚举值 |

## 🚀 v0.4.0 新特性 — 超能力

v0.4.0 将 GenericAgent 从一个结构良好的桌面 Agent 转变为**平台级 AI Agent 系统**，新增 8 大核心能力：

1. **🔌 动态工具插件系统** — `@register_tool` 装饰器，运行时注册，自动发现 `plugins/tools/` 下的工具
2. **🔗 MCP 客户端** — 支持 Anthropic Model Context Protocol，可连接任何 MCP 工具服务器
3. **🧠 向量记忆 / RAG** — 基于嵌入的语义搜索，比文件式 SOP 更精准的上下文召回
4. **🤝 多 Agent 编排** — 5 个专家角色（编码者/研究员/分析师/写作者/系统），自动任务路由
5. **🌐 FastAPI 服务器** — REST + SSE + WebSocket API，轻松集成任何前端或服务
6. **💭 高级推理模式** — ReAct（推理+行动）、Plan-Execute（规划执行）、Self-Reflection（自我反思）
7. **✅ 工具参数校验** — JSON Schema 校验 + 类型自动转换
8. **🛠️ 原生工具插件** — 网页搜索、语义记忆搜索/索引、系统信息工具
9. **🎨 现代 Qt 桌面 UI** — 工具调用可视化、思维展示、状态栏、审批对话框、命令面板、多主题、系统托盘、拖放文件

## 🧬 自我进化机制

这是 GenericAgent 区别于其他 Agent 框架的根本所在。

```
[遇到新任务]-->[自主摸索](安装依赖、编写脚本、调试验证)-->
[将执行路径固化为 Skill]-->[写入记忆层]-->[下次同类任务直接调用]
```

| 你说的一句话 | Agent 第一次做了什么 | 之后每次 |
|---|---|---|
| *"监控股票并提醒我"* | 安装 mootdx → 构建选股流程 → 配置定时任务 → 保存 Skill | **一句话启动** |
| *"用 Gmail 发这个文件"* | 配置 OAuth → 编写发送脚本 → 保存 Skill | **直接可用** |

用几周后，你的 Agent 实例将拥有一套任何人都没有的专属技能树，全部从 3K 行种子代码中生长而来。

#### 🎯 实例展示

| 🧋 外卖下单 | 📈 量化选股 |
|:---:|:---:|
| <img src="assets/demo/order_tea.gif" width="100%" alt="Order Tea"> | <img src="assets/demo/selectstock.gif" width="100%" alt="Stock Selection"> |
| *"Order me a milk tea"* — 自动导航外卖 App，选品并完成结账 | *"Find GEM stocks with EXPMA golden cross, turnover > 5%"* — 量化条件筛股 |
| 🌐 自主网页探索 | 💰 支出追踪 | 💬 批量消息 |
| <img src="assets/demo/autonomous_explore.png" width="100%" alt="Web Exploration"> | <img src="assets/demo/alipay_expense.png" width="100%" alt="Alipay Expense"> | <img src="assets/demo/wechat_batch.png" width="100%" alt="WeChat Batch"> |
| 自主浏览并定时汇总网页信息 | *"查找近 3 个月超 ¥2K 的支出"* — 通过 ADB 驱动支付宝 | 批量发送微信消息，完整驱动微信客户端 |



## 📅 最新动态

- **2026-05-04:** 🧟 **v0.6.0 发布** — "大厂怪兽"：6 个波次 21 项新特性，灵感来自 12 个开源框架（LangGraph、MCP SDK、ChromaDB、Hermes、OpenAI Agents SDK、pi-mono、Langflow、Browser-Use、AIAvatarKit、VRoid Hub、Google ADK、Gemini API），1020 测试通过
- **2026-05-03:** 🚀 **v0.5.0 发布** — 自动结晶引擎（6 项特性）、生产级加固（10 项关键/中度修复）、952 测试通过
- **2026-05-02:** 🚀 **v0.4.0 发布** — 8 大超能力：动态工具插件、MCP 客户端、向量记忆/RAG、多 Agent 编排、FastAPI 服务器、高级推理、工具校验、原生插件 + 现代 Qt UI
- **2026-04-21:** 📄 [技术报告已发布至 arXiv](https://arxiv.org/abs/2604.17091) — *GenericAgent: A Token-Efficient Self-Evolving LLM Agent via Contextual Information Density Maximization*
- **2026-04-11:** 引入 **L4 会话归档记忆**，并接入 scheduler cron 调度
- **2026-03-23:** 支持个人微信接入作为 Bot 前端
- **2026-03-10:** [发布百万级 Skill 库](https://mp.weixin.qq.com/s/q2gQ7YvWoiAcwxzaiwpuiQ?scene=1&click_id=7)
- **2026-03-08:** [发布以 GenericAgent 为核心的"政务龙虾" Dintal Claw](https://mp.weixin.qq.com/s/eiEhwo-j6S-WpLxgBnNxBg)
- **2026-03-01:** [GenericAgent 被机器之心报道](https://mp.weixin.qq.com/s/uVWpTTF5I1yzAENV_qm7yg)
- **2026-01-16:** GenericAgent V1.0 公开版本发布

---

## 🚀 快速开始

#### 方法一：标准安装

```bash
# 1. 克隆仓库
git clone https://github.com/lsdefine/GenericAgent.git
cd GenericAgent

# 2. 安装最小依赖
pip install requests streamlit pywebview

# 3. 配置 API Key
cp mykey_template.py mykey.py
# 编辑 mykey.py，填入你的 LLM API Key

# 4. 启动
python launch.pyw
```

#### 方法二：uv 快速安装（熟悉 Python 的用户）

```bash
git clone https://github.com/lsdefine/GenericAgent.git
cd GenericAgent
uv pip install -e ".[qt]"          # 核心 + Qt 桌面 UI
cp mykey_template.py mykey.py
python frontends/qtapp.py
```

#### 方法三：Docker（无头/服务器模式）

```bash
docker build -t genericagent .
docker run -e LLM_API_KEY=sk-... genericagent
```

#### 方法四：API 服务器模式

```bash
pip install fastapi uvicorn sse-starlette
python server.py   # 启动于 http://0.0.0.0:8765
```

> GenericAgent 更推荐由 Agent 在使用中自举环境，而不是预先手动装完整依赖。

完整引导流程见 [GETTING_STARTED.md](GETTING_STARTED.md)。

📖 新手使用指南（图文版）：[飞书文档](https://my.feishu.cn/wiki/CGrDw0T76iNFuskmwxdcWrpinPb)

📘 完整入门教程（Datawhale 出品）：[Hello GenericAgent](https://datawhalechina.github.io/hello-generic-agent/) · [GitHub](https://github.com/datawhalechina/hello-generic-agent)

---

## 🤖 Bot 接口（可选）

### 微信 Bot（个人微信）

无需额外配置，扫码登录即可：

```bash
pip install pycryptodome qrcode requests
python frontends/wechatapp.py
```

> 首次启动会弹出二维码，用微信扫码完成绑定。之后通过微信消息与 Agent 交互。

### QQ Bot

使用 `qq-botpy` WebSocket 长连接，**无需公网 webhook**：

```bash
pip install qq-botpy
```

在 `mykey.py` 中补充：

```python
qq_app_id = "YOUR_APP_ID"
qq_app_secret = "YOUR_APP_SECRET"
qq_allowed_users = ["YOUR_USER_OPENID"]  # 或 ['*'] 公开访问
```

```bash
python frontends/qqapp.py
```

> 在 [QQ 开放平台](https://q.qq.com) 创建机器人获取 AppID / AppSecret。首次消息后，用户 openid 记录于 `temp/qqapp.log`。

### 飞书（Lark）

```bash
pip install lark-oapi
python frontends/fsapp.py
```

```python
fs_app_id = "cli_xxx"
fs_app_secret = "xxx"
fs_allowed_users = ["ou_xxx"]  # 或 ['*']
```

详细配置见 [assets/SETUP_FEISHU.md](assets/SETUP_FEISHU.md)


### 企业微信（WeCom）

```bash
pip install wecom_aibot_sdk
python frontends/wecomapp.py
```

```python
wecom_bot_id = "your_bot_id"
wecom_secret = "your_bot_secret"
wecom_allowed_users = ["your_user_id"]
wecom_welcome_message = "你好，我在线上。"
```

### 钉钉（DingTalk）

```bash
pip install dingtalk-stream
python frontends/dingtalkapp.py
```

```python
dingtalk_client_id = "your_app_key"
dingtalk_client_secret = "your_app_secret"
dingtalk_allowed_users = ["your_staff_id"]  # 或 ['*']
```

### 其他 App 前端

除默认的 Streamlit Web UI 外，还可以尝试不同风格的前端：

```bash
python frontends/qtapp.py                # 基于 Qt 的桌面应用（推荐）
streamlit run frontends/stapp2.py        # 另一种 Streamlit 风格 UI
```

### 通用聊天命令

默认通过 `python launch.pyw` 启动的 Streamlit 桌面 UI，以及 QQ / Telegram / 飞书 / 企业微信 / 钉钉前端，都支持以下命令：

- `/new` - 开启新对话并清空当前上下文
- `/continue` - 列出可恢复会话快照
- `/continue N` - 恢复第 `N` 个可恢复会话


## 📊 与同类产品对比

| 特性 | GenericAgent | OpenClaw | Claude Code |
|------|:---:|:---:|:---:|
| **代码量** | ~3K 行核心 | ~530,000 行 | 已开源（体量大） |
| **部署方式** | `pip install` + API Key | 多服务编排 | CLI + 订阅 |
| **浏览器控制** | 注入真实浏览器（保留登录态） | 沙箱 / 无头浏览器 | 通过 MCP 插件 |
| **OS 控制** | 键鼠、视觉、ADB | 多 Agent 委派 | 文件 + 终端 |
| **自我进化** | 自主生长 Skill 和工具 | 插件生态 | 会话间无状态 |
| **MCP 支持** | 内置客户端 | 部分 | 完整 |
| **向量记忆 / RAG** | 内置 | 外部 | 无 |
| **多 Agent** | 5 个专家角色 | 原生 | 无 |
| **API 服务器** | 内置（FastAPI + SSE） | 外部 | 无 |
| **高级推理** | ReAct、Plan-Execute、Self-Reflect | 无 | 无 |
| **自动结晶** | 内置（v0.5.0） | 无 | 无 |
| **StateGraph 引擎** | 内置（v0.6.0） | 无 | 无 |
| **MCP 服务器** | 内置（v0.6.0） | 无 | 无 |
| **Chroma 记忆** | 内置（v0.6.0） | 无 | 无 |
| **闭环学习** | 内置（v0.6.0） | 无 | 无 |
| **Agent 移交** | 内置（v0.6.0） | 无 | 无 |
| **护栏** | 内置（v0.6.0） | 无 | 无 |
| **扩展 / 生命周期钩子** | 内置（v0.6.0） | 无 | 无 |
| **Flow 序列化** | 内置（v0.6.0） | 无 | 无 |
| **浏览器 Agent** | 内置（v0.6.0） | 无 | 无 |
| **语音管线** | 内置（v0.6.0） | 无 | 无 |
| **虚拟形象（VRM/VRoid）** | 内置（v0.6.0） | 无 | 无 |
| **熔断器** | 内置 | 无 | 无 |
| **LLM 指标** | 内置 | 无 | 无 |
| **测试覆盖** | 1020 测试 | 未知 | 未知 |


## 🧠 工作机制

GenericAgent 通过**分层记忆 × 最小工具集 × 自主执行循环**完成复杂任务，并在执行过程中持续积累经验。

1️⃣ **分层记忆系统**
> 记忆在任务执行过程中持续沉淀，使 Agent 逐步形成稳定且高效的工作方式


- **L0 — 元规则（Meta Rules）**：Agent 的基础行为规则和系统约束
- **L1 — 记忆索引（Insight Index）**：极简索引层，用于快速路由与召回
- **L2 — 全局事实（Global Facts）**：在长期运行过程中积累的稳定知识
- **L3 — 任务 Skills / SOPs**：完成特定任务类型的可复用流程
- **L4 — 会话归档（Session Archive）**：从已完成任务中提炼出的归档记录，用于长程召回

2️⃣ **自主执行循环**

> 感知环境状态  →  任务推理  →  调用工具执行  →  经验写入记忆  →  循环

整个核心循环仅 **约百行代码**（`agent_loop.py`）。

3️⃣ **最小工具集**
>GenericAgent 仅提供 **9 个原子工具**，构成与外部世界交互的基础能力

| 工具 | 功能 |
|------|------|
| `code_run` | 执行任意代码 |
| `file_read` | 读取文件 |
| `file_write` | 写入文件 |
| `file_patch` | 修改文件 |
| `web_scan` | 感知网页内容 |
| `web_execute_js` | 控制浏览器行为 |
| `ask_user` | 人机协作确认 |

> 此外，还有 2 个**记忆管理工具**（`update_working_checkpoint`、`start_long_term_update`），使 Agent 能够跨会话积累经验、维持持久上下文。

4️⃣ **能力扩展机制**
> 具备动态创建新的工具能力
>
通过 `code_run`，GenericAgent 可在运行时动态安装 Python 包、编写新脚本、调用外部 API 或控制硬件，将临时能力固化为永久工具。

<div align="center">
  <img src="assets/images/workflow.jpg" alt="GenericAgent 工作流程" width="400"/>
  <br><em>GenericAgent 工作流程图</em>
</div>

## ⭐ 支持
如果这个项目对您有帮助，欢迎点一个 **Star!** 🙏

同时也欢迎加入我们的**GenericAgent体验交流群**，一起交流、反馈和共建 👏
<div align="center">
  <table>
    <tr>
      <td align="center"><strong>微信群 13</strong><br><img src="assets/images/wechat_group13.jpg" alt="微信群 13 二维码" width="250"/></td>
    </tr>
  </table>
</div>

## 🚩 友情链接

感谢 **LinuxDo** 社区的支持！

[![LinuxDo](https://img.shields.io/badge/社区-LinuxDo-blue?style=for-the-badge)](https://linux.do/)


## 📄 许可
MIT License — 详见 [LICENSE](LICENSE)

*声明：本项目未构建任何商业站点；除 DintalClaw 外，目前未官方授权任何机构、组织或个人以 GenericAgent 名义从事商业活动。*

## 📈 Star History

<a href="https://star-history.com/#lsdefine/GenericAgent&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=lsdefine/GenericAgent&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=lsdefine/GenericAgent&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=lsdefine/GenericAgent&type=Date" />
 </picture>
</a>


---
<a name="french"></a>
## 🌟 Apercu

**GenericAgent** est un framework d'agent autonome minimal et auto-evolutif. Son coeur ne fait que **~3K lignes de code**. Via **9 outils atomiques + une boucle d'agent de ~100 lignes**, il confere a n'importe quel LLM un controle systeme sur un ordinateur local — couvrant le navigateur, le terminal, le systeme de fichiers, le clavier/souris, la vision ecran et les appareils mobiles (ADB).

Sa philosophie de conception : **ne pas precharger les competences — les faire evoluer.**

Chaque fois que GenericAgent resout une nouvelle tache, il cristallise automatiquement le chemin d'execution en une competence pour une reutilisation directe ulterieure. Plus vous l'utilisez longtemps, plus les competences s'accumulent — formant un arbre de competences qui vous appartient entierement, cultive a partir de 3K lignes de code source.

## 📋 Caracteristiques Principales
- **Auto-evolutif** : Cristallise automatiquement chaque tache en competence. Les capacites croissent a chaque utilisation.
- **Architecture minimale** : ~3K lignes de code coeur. Boucle d'agent de ~100 lignes. Zero dependance complexe.
- **Execution puissante** : S'injecte dans un vrai navigateur (en preservant les sessions). 9 outils atomiques prennent le controle du systeme.
- **Haute compatibilite** : Supporte Claude / OpenAI / Gemini / DeepSeek / modeles locaux (Ollama). Multi-plateforme.
- **Efficace en tokens** : Fenetre de contexte <30K — une fraction des 200K-1M que consomment les autres agents.

## 🧟 Big Tech Monster — v0.6.0

GenericAgent v0.6.0 extrait les meilleurs patterns de 12 frameworks d'agents IA open-source, les combinant en une plateforme d'agent auto-evolutive unifiee.

### Nouvelles capacites par vague

| Vague | Fonctionnalite | Inspire par | API cles |
|-------|---------------|-------------|----------|
| V1 | Moteur StateGraph | LangGraph | `agent.build_state_graph()` |
| V1 | Serveur FastMCP | MCP Python SDK | `@agent.register_mcp_tool()` |
| V1 | Memoire Chroma | ChromaDB | `agent.search_memory()` |
| V1 | Google AI Studio | Gemini API | `GoogleAISession` |
| V2 | Boucle d'apprentissage fermee | Hermes Agent | `agent.closed_learning.run_full_cycle()` |
| V2 | Divulgation progressive des competences | Google ADK | `SkillToolset` |
| V2 | Persistence Self-Nudge | Hermes Agent | `SelfNudge` |
| V3 | Transferts d'agents | OpenAI Agents SDK | `agent.agent_handoff` |
| V3 | Agent-comme-outil | OpenAI Agents SDK | `AgentAsTool` |
| V3 | Execution en sandbox | OpenAI Agents SDK | `SandboxExecutor` |
| V3 | Guardrails entree/sortie | OpenAI Agents SDK | `agent.validate_input()` |
| V4 | Hooks de cycle de vie des extensions | pi-mono | `agent.extension_manager` |
| V4 | Moteur de compaction de contexte | pi-mono | `agent.context_engine` |
| V4 | Serialisation de flux | Langflow | `agent.create_flow()` |
| V4 | Flux-comme-serveur-MCP | Langflow | `FlowMCPServer` |
| V5 | Intelligence DOM | Browser-Use | `agent.browser_session` |
| V5 | Agent navigateur | Browser-Use | `BrowserAgent` |
| V6 | Pipeline vocal | AIAvatarKit | `agent.enable_voice()` |
| V6 | Avatar VRM/VRoid | AIAvatarKit | `agent.enable_avatar()` |
| V6 | Client VRoid Hub | VRoid Hub | `VRoidHubClient` |
| V6 | Speech-to-Speech | AIAvatarKit | `SpeechToSpeechEngine` |

### Exemples de code

```python
# Construire un workflow StateGraph
graph = agent.build_state_graph()
graph.add_node("think", think_fn)
graph.add_node("act", act_fn)
graph.add_edge("think", "act")
graph.add_conditional_edges("act", route_fn, {"retry": "think", "done": "__end__"})
compiled = graph.compile(checkpointer=MemoryCheckpointer())

# Enregistrer des outils MCP
@agent.register_mcp_tool()
def search_web(query: str, num: int = 10) -> str:
    """Rechercher sur le web."""
    return do_search(query, num)

# Boucle d'apprentissage fermee
result = agent.closed_learning.run_full_cycle("Analyser les ventes trimestrielles")

# Guardrails
agent.validate_input("Bonjour, aide-moi a coder")  # GuardrailResult(passed=True)

# Pipeline vocal
agent.enable_voice(stt_provider="google", tts_provider="voicevox")
agent.enable_avatar(avatar_path="avatar.vrm")
```

## 🚀 v0.5.0 — Moteur de cristallisation automatique & Renforcement production

La v0.5.0 enrichit les 8 super-pouvoirs de la v0.4.0 avec un **moteur de cristallisation automatique complet** et un **renforcement production-grade** sur tous les modules :

### 🧬 Moteur de cristallisation automatique

La piece maitresse de la v0.5.0 : l'agent **cristallise automatiquement les chemins d'execution en competences reutilisables** sans aucune intervention manuelle. Apres 15+ tours de conversation, le moteur injecte `start_long_term_update` dans les hooks de fin, declenchant une cascade d'operations memoire :

| Fonctionnalite | Description |
|---------------|-------------|
| **Declenchement automatique** | Apres 15+ tours, invite automatiquement l'agent a cristalliser le chemin d'execution |
| **Synchronisation L1 automatique** | Lors de l'ecriture d'un nouveau SOP, l'index L1 se met a jour automatiquement |
| **Persistance des checkpoints** | Les points de controle sont sauvegardes sur disque et restaures au demarrage |
| **Indexation RAG automatique** | Les nouveaux SOP sont automatiquement indexes dans le VectorStore |
| **Metriques de cristallisation** | Suivi des evenements, taux de succes et croissance de la memoire |
| **Observateur d'ecriture memoire** | Detecte les ecritures dans `memory/` et declenche la sync L1 + l'indexation RAG |

### 🛡️ Renforcement production (Revue de code + Corrections)

Une revue de code ligne par ligne a identifie 52 problemes, tous les problemes critiques et moderes ont ete corriges :

| Correction | Impact | Details |
|-----------|--------|---------|
| **Protection clients LLM vides** | 🔴 Critique | Prevent le crash `IndexError` quand aucun fournisseur LLM n'est configure |
| **Copie profonde de l'historique** | 🔴 Critique | L'historique partage par reference causait une corruption de donnees entre sessions |
| **Correction JSON Schema** | 🔴 Critique | Accolades manquantes dans la definition de l'outil `start_long_term_update` |
| **Bug `_clean_content`** | 🔴 Critique | `"\\n" in pattern` evaluait toujours a `False` |
| **Securite exception `tryparse`** | 🟡 Modere | Le `json.loads` final pouvait lever une exception non geree |
| **Regex PowerShell→Bash** | 🟡 Modere | Le remplacement naif corrompait les descriptions JSON → regex ciblee |

## 🚀 v0.4.0 — Super-pouvoirs

La v0.4.0 transforme GenericAgent en un **systeme d'agent IA de niveau plateforme** avec 8 nouvelles capacites majeures :

1. **🔌 Systeme de plugins d'outils dynamiques** — Decorateur `@register_tool`, enregistrement runtime, auto-decouverte
2. **🔗 Client MCP** — Protocol Model Context d'Anthropic, transport stdio/SSE/HTTP
3. **🧠 Memoire vectorielle / RAG** — Recherche semantique par embeddings sur la memoire et les documents
4. **🤝 Orchestration multi-agents** — 5 profils specialistes (Codeur, Chercheur, Analyste, Redacteur, Systeme)
5. **🌐 Serveur FastAPI** — API REST + SSE + WebSocket pour integration avec n'importe quel frontend
6. **💭 Raisonnement avance** — ReAct, Plan-and-Execute, Self-Reflection
7. **✅ Validation des arguments d'outils** — Validation JSON Schema avec coercion de type
8. **🛠️ Plugins d'outils natifs** — Recherche web, recherche/indexation memoire, outils systeme
9. **🎨 UI Qt Desktop moderne** — Visualisation des appels d'outils, section de reflexion, barre de statut animee, dialogue d'approbation, palette de commandes Ctrl+K, multi-theme, icone systeme, glisser-deposer

## 🚀 Demarrage Rapide

```bash
# 1. Cloner le depot
git clone https://github.com/lsdefine/GenericAgent.git
cd GenericAgent

# 2. Installer les dependances minimales
pip install requests streamlit pywebview

# 3. Configurer la cle API
cp mykey_template.py mykey.py
# Editer mykey.py avec votre cle API LLM

# 4. Lancer
python launch.pyw
```

Ou avec Qt Desktop (recommande) :

```bash
uv pip install -e ".[qt]"
cp mykey_template.py mykey.py
python frontends/qtapp.py
```

Ou en mode serveur API :

```bash
pip install fastapi uvicorn sse-starlette
python server.py   # Demarre sur http://0.0.0.0:8765
```

Guide complet : [GETTING_STARTED.md](GETTING_STARTED.md)

## 📄 Licence

MIT License — voir [LICENSE](LICENSE)
